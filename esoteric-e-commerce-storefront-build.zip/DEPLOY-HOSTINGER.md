# Subir Perla & Pluma a Hostinger (hPanel · Node.js)

La tienda está preparada para compilar **con o sin base de datos**. Si Hostinger
no tiene PostgreSQL, el catálogo demo incluido se sirve automáticamente y el
checkout sigue funcionando en modo demostración.

## 1. Qué subir (¡muy importante!)

Sube **solo el código fuente**. Si el ZIP incluye `node_modules/` o `.next/`,
Hostinger reutiliza binarios compilados para otra arquitectura (por ejemplo
`@tailwindcss/oxide`) y la compilación falla.

Excluye siempre:

```
node_modules/
.next/
out/
.env
.env.local
```

Puedes crear el ZIP con:

```bash
zip -r perlapluma-src.zip . \
  -x "node_modules/*" ".next/*" "out/*" ".env" ".env.local" "*.tsbuildinfo"
```

### ZIP listo para subir

Hay un ZIP limpio generado desde este mismo proyecto (solo código fuente, 355 KB):

```
perla-pluma-src.zip   →   https://<tu-preview>/perla-pluma-src.zip
```

Descárgalo, súbelo a Hostinger y extráelo. No contiene `node_modules`, `.next` ni
variables de entorno, así que no puede fallar por binarios de otra máquina.

## 2. Configuración en hPanel

| Ajuste            | Valor                       |
| ----------------- | --------------------------- |
| Framework         | Next.js                     |
| Versión de Node   | 22.x                        |
| Directorio raíz   | `/`                         |
| Comando de build  | `npm run build` (usa webpack) |
| Comando de inicio | `npm run start`             |
| Puerto            | el que inyecta Hostinger (`PORT`) |

`npm run start` ejecuta `next start`, que ya lee `process.env.PORT`.

## 3. Variables de entorno

Todas son opcionales (ver `.env.example`):

- `DATABASE_URL` — PostgreSQL para persistir pedidos y suscripciones.
  Si no la defines, la tienda usa el catálogo demo y valida los pedidos en
  memoria. **No subas `.env` con credenciales al repositorio.**
- `NEXT_PUBLIC_SITE_URL` — URL pública del dominio.

Si añades `DATABASE_URL`, crea las tablas una vez desde tu equipo:

```bash
npx drizzle-kit push
```

(La app también siembra automáticamente los 17 productos y las reseñas la
primera vez que consulta una base de datos vacía.)

## 4. Checklist si la compilación sigue fallando

1. **Borra la caché de compilación** en hPanel antes de redesplegar.
2. Confirma que el ZIP **no** contiene `node_modules` ni `.next`.
3. Confirma Node 22.x y que existen `package.json` + `package-lock.json` en la raíz.
4. Revisa el log de compilación: si aparece `Cannot find module '@tailwindcss/oxide-linux-x64-gnu'`, es el ZIP con `node_modules` de otra máquina (punto 1).
4-bis. Si aparece `FATAL: An unexpected Turbopack error` / `Failed to write app endpoint` / `creating new process`: es Turbopack bloqueado por el sandbox del hosting. Esta versión ya compila con **webpack** (`next build --webpack`), que no necesita abrir puertos locales. Verifica que `npm run build` sea exactamente ese comando y borra `.next` antes de desplegar.
5. Si aparece `DATABASE_URL is required`, actualiza a esta versión: la conexión ya es perezosa y opcional.
6. Si aparece un error de red en `next/font/google`, esta versión ya no descarga fuentes externas (usa la pila tipográfica del sistema).
