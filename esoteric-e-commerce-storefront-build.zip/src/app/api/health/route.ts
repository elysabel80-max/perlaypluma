import { db, hasDatabaseUrl } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!hasDatabaseUrl()) {
    return Response.json({ ok: true, database: "demo-catalogue" });
  }
  try {
    await db.execute(sql`select 1`);
    return Response.json({ ok: true, database: "connected" });
  } catch {
    // The storefront keeps serving the curated demo catalogue without a database.
    return Response.json({ ok: true, database: "unavailable" });
  }
}
