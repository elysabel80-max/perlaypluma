import { NextResponse } from "next/server";
import { db, hasDatabaseUrl } from "@/db";
import { newsletter } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const { email } = await request.json();
    if (!email || !email.includes("@")) {
      return NextResponse.json(
        { success: false, message: "Por favor, introduce un correo electrónico válido" },
        { status: 400 }
      );
    }

    if (hasDatabaseUrl()) {
      try {
        await db.insert(newsletter).values({ email }).onConflictDoNothing();
      } catch (dbError) {
        console.warn("Newsletter subscription not persisted:", dbError);
      }
    }

    return NextResponse.json({
      success: true,
      message:
        "¡Bienvenida al Círculo de Luz! Has recibido tu bendición y un 10% de bienvenida en tu bandeja.",
    });
  } catch (error) {
    console.error("POST /api/newsletter error:", error);
    return NextResponse.json(
      { success: false, message: "Error al registrar suscripción" },
      { status: 500 }
    );
  }
}
