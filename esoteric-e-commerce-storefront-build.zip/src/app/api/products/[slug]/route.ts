import { NextResponse } from "next/server";
import { getProductBySlug } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const { product, productReviews, related } = await getProductBySlug(slug);

    if (!product) {
      return NextResponse.json(
        { success: false, message: "Producto no encontrado" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      product,
      reviews: productReviews,
      related,
    });
  } catch (error) {
    console.error("GET /api/products/[slug] error:", error);
    return NextResponse.json(
      { success: false, message: "Error al obtener el producto" },
      { status: 500 }
    );
  }
}
