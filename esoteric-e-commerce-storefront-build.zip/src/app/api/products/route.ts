import { NextResponse } from "next/server";
import { getAllProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const intention = searchParams.get("intention");
    const search = searchParams.get("q");
    const subcategory = searchParams.get("subcategory");

    let results = await getAllProducts();

    if (category) {
      results = results.filter((p) => p.category === category);
    }
    if (intention) {
      results = results.filter((p) => p.intention === intention);
    }
    if (subcategory) {
      results = results.filter((p) => p.subcategory === subcategory);
    }
    if (search) {
      const q = search.toLowerCase();
      results = results.filter((p) =>
        [p.name, p.subtitle, p.shortDescription, p.categoryName, p.subcategory]
          .filter(Boolean)
          .some((field) => field!.toLowerCase().includes(q))
      );
    }

    return NextResponse.json({
      success: true,
      products: results,
      total: results.length,
    });
  } catch (error) {
    console.error("GET /api/products error:", error);
    return NextResponse.json(
      { success: false, message: "Error al obtener los productos", products: [] },
      { status: 500 }
    );
  }
}
