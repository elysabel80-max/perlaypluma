import { NextResponse } from "next/server";
import { db, hasDatabaseUrl } from "@/db";
import { subscriptions } from "@/db/schema";

export const dynamic = "force-dynamic";

const PLAN_DATA = {
  plata: { name: "Círculo Plata", price: "4.99", discount: "5%" },
  oro: { name: "Círculo Oro VIP", price: "12.99", discount: "10%" },
} as const;

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { email, name, plan } = body ?? {};

    if (!email || typeof email !== "string" || !email.includes("@")) {
      return NextResponse.json(
        { success: false, message: "Introduce un correo electrónico válido" },
        { status: 400 }
      );
    }
    if (plan !== "plata" && plan !== "oro") {
      return NextResponse.json(
        { success: false, message: "Plan de suscripción no válido" },
        { status: 400 }
      );
    }

    const selected = PLAN_DATA[plan as "plata" | "oro"];
    const reference = `CLUB-${plan.toUpperCase()}-${Date.now().toString().slice(-6)}`;

    const payload = {
      reference,
      customerName: name || "Miembro del Círculo de Luz",
      customerEmail: email,
      plan,
      planName: selected.name,
      price: selected.price,
      discount: selected.discount,
      status: "activa",
    };

    if (hasDatabaseUrl()) {
      try {
        const [row] = await db.insert(subscriptions).values(payload).returning();
        return NextResponse.json({ success: true, subscription: row, persisted: true });
      } catch (dbError) {
        console.warn("Suscripción no persistida, se confirma en modo demostración:", dbError);
      }
    }

    return NextResponse.json({ success: true, subscription: payload, persisted: false });
  } catch (error) {
    console.error("POST /api/subscriptions error:", error);
    return NextResponse.json(
      { success: false, message: "Error al procesar la suscripción" },
      { status: 500 }
    );
  }
}
