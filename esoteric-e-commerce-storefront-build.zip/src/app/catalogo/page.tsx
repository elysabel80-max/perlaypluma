import React, { Suspense } from "react";
import { CatalogClient } from "@/components/CatalogClient";
import { getAllProducts } from "@/lib/catalog";
import { Sparkles } from "lucide-react";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Catálogo Sagrado | Perla & Pluma",
  description:
    "Velas de cera pura de abeja, minerales auténticos, inciensos naturales, kits de rituales y herramientas místicas seleccionadas con rigor y mimo.",
};

function firstValue(value: string | string[] | undefined): string | undefined {
  return Array.isArray(value) ? value[0] : value;
}

export default async function CatalogPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  // Served from PostgreSQL when available, otherwise from the built-in catalogue.
  const products = await getAllProducts();
  const params = await searchParams;
  const initialFilters = {
    category: firstValue(params.category),
    intention: firstValue(params.intention),
    q: firstValue(params.q),
    subcategory: firstValue(params.subcategory),
  };
  const filterKey = [
    initialFilters.category,
    initialFilters.intention,
    initialFilters.q,
    initialFilters.subcategory,
  ].join("|");

  return (
    <Suspense
      fallback={
        <div className="py-24 text-center">
          <Sparkles className="w-8 h-8 text-[#D4AF37] animate-spin mx-auto" />
          <p className="mt-3 text-xs text-stone-500">Armonizando el catálogo sagrado...</p>
        </div>
      }
    >
      <CatalogClient
        key={filterKey}
        initialProducts={products}
        initialFilters={initialFilters}
      />
    </Suspense>
  );
}
