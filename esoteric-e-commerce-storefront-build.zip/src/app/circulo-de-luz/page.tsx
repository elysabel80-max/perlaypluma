import React from "react";
import Link from "next/link";
import Image from "next/image";
import {
  Sparkles,
  ArrowRight,
  BookOpen,
  Percent,
  Moon,
  Gift,
  HeartHandshake,
  CalendarDays,
  Users,
} from "lucide-react";
import {
  ClubProvider,
  ClubStatus,
  ClubPlans,
  ClubComparison,
  ClubGuides,
  ClubFaq,
  ClubClosing,
} from "@/components/club/ClubInteractive";
import {
  Mandala,
  FlowerOfLife,
  StarDivider,
  SectionOrnament,
  Sigil,
  MoonPhaseStrip,
} from "@/components/decor/Ornaments";

export const metadata = {
  title: "Círculo de Luz | Club místico por suscripción",
  description:
    "Únete al Círculo de Luz: guías exclusivas, rituales lunares, descuentos permanentes del 5% y 10% y regalos de alta vibración. Membresías desde 4,99 €/mes sin permanencia.",
};

const MANIFESTO_POINTS = [
  {
    icon: BookOpen,
    title: "Aprender con orden",
    text: "Guías claras, sin dogmas ni información dispersa, para que sepas qué hacer con cada pieza.",
  },
  {
    icon: Percent,
    title: "Ahorro permanente",
    text: "5% u 10% de descuento automático en toda la tienda mientras tu membresía esté activa.",
  },
  {
    icon: CalendarDays,
    title: "Ritmo lunar",
    text: "Un cuaderno digital al inicio de cada ciclo con el paso a paso de Luna Nueva y Luna Llena.",
  },
  {
    icon: Gift,
    title: "Detalles de alta vibración",
    text: "En el Círculo Oro, cada pedido viaja con un obsequio físico preparado en el altar.",
  },
];

export default function CirculoDeLuzPage() {
  return (
    <ClubProvider>
      {/* Franja de anuncios superior */}
      <div className="bg-[#4A5D4E] text-[#FDFBF7] text-[11px] sm:text-xs px-4 py-2.5 text-center">
        <div className="max-w-6xl mx-auto flex items-center justify-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
          <span>
            Únete al Círculo de Luz: guías exclusivas, descuentos permanentes en la tienda y
            acompañamiento para tu ritual diario.
          </span>
        </div>
      </div>

      <ClubStatus />

      {/* Hero */}
      <section className="relative overflow-hidden bg-[#FAF7F0] border-b border-[#E8E2D9]">
        <Mandala size={900} opacity={0.16} className="pointer-events-none absolute -right-72 -top-64 animate-spin-slower" />
        <FlowerOfLife size={520} opacity={0.14} color="#8C9A8F" className="pointer-events-none absolute -left-56 bottom-0 animate-spin-slower-rev" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
            <div className="lg:col-span-7 space-y-5 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EAE3D6] border border-[#D8C79E]/70 text-[10px] sm:text-xs uppercase tracking-[0.2em] text-[#4A5D4E] font-semibold">
                <Sigil name="flor" size={14} color="#B08A2E" />
                <span>Club privado de Perla &amp; Pluma</span>
              </div>

              <h1 className="font-serif text-3xl sm:text-5xl lg:text-[3.25rem] leading-[1.12] text-[#242B26] font-normal">
                Un refugio de luz, aprendizaje y magia para acompañar tu camino diario.
              </h1>

              <MoonPhaseStrip size={16} color="#B08A2E" className="mx-auto lg:mx-0" />

              <h2 className="text-sm sm:text-base text-[#5B675E] leading-relaxed max-w-2xl mx-auto lg:mx-0">
                El Círculo de Luz es nuestro club privado donde la sabiduría ancestral se convierte
                en prácticas sencillas para tu vida moderna. Accede a guías exclusivas, descuentos
                permanentes en todo nuestro catálogo y una experiencia mística hecha a tu medida.
              </h2>

              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-2">
                <a
                  href="#planes"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#D4AF37] hover:bg-[#C29D2D] text-[#242B26] px-7 py-3.5 rounded-xl text-[11px] uppercase tracking-[0.15em] font-semibold transition-colors shadow-sm"
                >
                  <span>Ver planes de suscripción</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
                <a
                  href="#guias"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-transparent border border-[#4A5D4E]/40 hover:border-[#4A5D4E] text-[#4A5D4E] px-7 py-3.5 rounded-xl text-[11px] uppercase tracking-[0.15em] font-semibold transition-colors"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Descubrir las guías exclusivas</span>
                </a>
              </div>

              <div className="grid grid-cols-3 gap-3 pt-5 border-t border-[#E8E2D9] max-w-md mx-auto lg:mx-0">
                <div>
                  <p className="font-serif text-lg text-[#242B26]">4,99 €</p>
                  <p className="text-[10px] text-[#7A877E] uppercase tracking-wider">Plata / mes</p>
                </div>
                <div>
                  <p className="font-serif text-lg text-[#242B26]">12,99 €</p>
                  <p className="text-[10px] text-[#7A877E] uppercase tracking-wider">Oro / mes</p>
                </div>
                <div>
                  <p className="font-serif text-lg text-[#242B26]">1 clic</p>
                  <p className="text-[10px] text-[#7A877E] uppercase tracking-wider">Para cancelar</p>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="relative mx-auto max-w-md aspect-4/5 rounded-3xl overflow-hidden border-4 border-[#FDFBF7] shadow-2xl bg-[#EAE3D6]">
                <Image
                  src="https://images.pexels.com/photos/38684710/pexels-photo-38684710.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
                  alt="Bodegón de cuarzos, palo santo y selenita sobre lino: bienvenida al Círculo de Luz"
                  fill
                  priority
                  sizes="(max-width: 1024px) 100vw, 40vw"
                  className="object-cover"
                />
                <div className="absolute inset-x-4 bottom-4 rounded-2xl bg-[#FDFBF7]/92 backdrop-blur-md border border-white/60 p-4">
                  <p className="text-[10px] uppercase tracking-[0.2em] text-[#8A968D] mb-1">
                    Incluido desde el primer día
                  </p>
                  <p className="font-serif text-sm text-[#242B26] leading-snug">
                    Biblioteca digital, ritual lunar y tu descuento activo en la tienda.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Manifiesto */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-5 space-y-4">
            <SectionOrnament label="El rincón sagrado" align="left" />
            <h2 className="font-serif text-2xl sm:text-4xl text-[#242B26] leading-tight">
              ¿Por qué creamos el Círculo de Luz?
            </h2>
            <p className="text-sm text-[#5B675E] leading-relaxed">
              Sabemos que iniciar o profundizar en el camino de la magia, la gemoterapia y la
              aromaterapia puede resultar abrumador entre tanta información dispersa. Queremos
              ofrecerte un espacio ordenado, sereno y lleno de intención.
            </p>
            <p className="text-sm text-[#5B675E] leading-relaxed">
              Aquí no solo adquieres productos de alta vibración: aprendes a limpiarlos,
              intencionarlos y convertirlos en aliados para tu bienestar emocional y energético.
            </p>
            <Link
              href="/nosotros"
              className="inline-flex items-center gap-1.5 text-[11px] uppercase tracking-[0.15em] font-semibold text-[#4A5D4E] hover:text-[#242B26] transition-colors"
            >
              Conoce nuestro compromiso
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {MANIFESTO_POINTS.map(({ icon: Icon, title, text }) => (
              <div
                key={title}
                className="rounded-2xl border border-[#E0D7C8] bg-[#FDFBF7] p-5 space-y-2"
              >
                <span className="w-9 h-9 rounded-full bg-[#EFE9DD] text-[#4A5D4E] flex items-center justify-center">
                  <Icon className="w-4 h-4" />
                </span>
                <h3 className="font-serif text-base font-semibold text-[#242B26]">{title}</h3>
                <p className="text-[11px] text-[#5B675E] leading-relaxed">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Planes */}
      <section id="planes" className="bg-[#F4EFE6] border-y border-[#E8E2D9] py-14 sm:py-20 px-4 sm:px-6 lg:px-8 scroll-mt-24">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <SectionOrnament label="Dos formas de acompañarte" />
            <h2 className="font-serif text-2xl sm:text-4xl text-[#242B26]">
              Elige tu nivel de membresía
            </h2>
            <p className="text-xs sm:text-sm text-[#5B675E] mt-3 leading-relaxed">
              Sin permanencia y con cancelación en un clic. El descuento se aplica automáticamente
              en el carrito en cuanto activas tu plan.
            </p>
          </div>

          <ClubPlans />
        </div>
      </section>

      {/* Comparativa */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <SectionOrnament label="Comparativa" tone="gold" />
          <h2 className="font-serif text-2xl sm:text-4xl text-[#242B26]">
            Tabla comparativa de beneficios
          </h2>
          <StarDivider className="mt-5" />
          <p className="text-xs sm:text-sm text-[#5B675E] mt-3">
            Todo lo que incluye cada nivel, frente a una cuenta registrada gratuita.
          </p>
        </div>
        <ClubComparison />
      </section>

      {/* Guías */}
      <section id="guias" className="bg-[#FAF7F0] border-y border-[#E8E2D9] py-14 sm:py-20 px-4 sm:px-6 lg:px-8 scroll-mt-24">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-9">
            <div className="max-w-2xl">
              <SectionOrnament label="Muestrario de valor" align="left" />
              <h2 className="font-serif text-2xl sm:text-4xl text-[#242B26]">
                Guías exclusivas del club
              </h2>
              <p className="text-xs sm:text-sm text-[#5B675E] mt-2.5 leading-relaxed">
                Formato PDF ilustrado, con checklists y materiales complementarios. Incluidas sin
                coste en Plata y Oro VIP, o comprables por separado.
              </p>
            </div>
            <p className="text-[11px] text-[#8A968D] flex items-center gap-1.5">
              <Moon className="w-3.5 h-3.5" />
              Contenido actualizado cada ciclo lunar
            </p>
          </div>

          <ClubGuides />
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <SectionOrnament label="Dudas frecuentes" tone="gold" />
          <h2 className="font-serif text-2xl sm:text-4xl text-[#242B26]">Preguntas frecuentes</h2>
        </div>
        <ClubFaq />
      </section>

      {/* CTA final */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 sm:pb-24">
        <ClubClosing />
      </section>
    </ClubProvider>
  );
}
