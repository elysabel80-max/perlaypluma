import React from "react";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { BLOG_POSTS } from "@/data/blogData";
import { Sparkles, ArrowLeft, Clock, Calendar, BookmarkCheck } from "lucide-react";

export default async function BlogPostDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = BLOG_POSTS.find((p) => p.slug === slug);

  if (!post) {
    notFound();
  }

  return (
    <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      <Link
        href="/guias"
        className="inline-flex items-center gap-1.5 text-xs text-stone-500 hover:text-stone-800 transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Volver al índice de guías</span>
      </Link>

      <div className="space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EAE3D6] text-xs uppercase tracking-widest text-[#4A5D4E] font-medium">
          <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>{post.category}</span>
        </div>

        <h1 className="font-serif text-3xl sm:text-5xl text-[#242B26] font-normal leading-tight">
          {post.title}
        </h1>

        <div className="flex items-center gap-4 text-xs text-stone-500 pt-2 border-b border-[#E8E2D9] pb-4">
          <span className="flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5" />
            <span>{post.date}</span>
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            <span>{post.readTime}</span>
          </span>
          <span>•</span>
          <span>Por el Taller Perla & Pluma</span>
        </div>
      </div>

      <div className="relative aspect-16/9 rounded-3xl overflow-hidden bg-stone-200 border border-[#E8E2D9] shadow-sm">
        <Image
          src={post.image}
          alt={post.title}
          fill
          priority
          sizes="(max-width: 1024px) 100vw, 800px"
          className="object-cover"
        />
      </div>

      <div className="prose prose-stone max-w-none text-[#3E4A41] space-y-5 leading-relaxed font-serif text-base sm:text-lg">
        {post.content.map((p, idx) => (
          <p key={idx} className="leading-relaxed">
            {p}
          </p>
        ))}
      </div>

      <div className="p-8 bg-[#FAF7F0] rounded-3xl border border-[#E8E2D9] space-y-4 mt-12 text-center">
        <BookmarkCheck className="w-8 h-8 text-[#D4AF37] mx-auto" />
        <h3 className="font-serif text-xl text-[#242B26]">
          ¿Quieres poner en práctica este ritual?
        </h3>
        <p className="text-xs sm:text-sm text-[#5B675E] max-w-lg mx-auto">
          En nuestra tienda encontrarás las piezas purificadas y el kit completo con instrucciones impresas para tu hogar.
        </p>
        <Link
          href="/catalogo"
          className="inline-block bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] px-6 py-3 rounded-xl text-xs uppercase tracking-wider font-medium transition-colors"
        >
          Explorar Elementos del Ritual
        </Link>
      </div>
    </article>
  );
}
