import React from "react";
import Link from "next/link";
import Image from "next/image";
import { BLOG_POSTS } from "@/data/blogData";
import { Sparkles, ArrowRight, BookOpen } from "lucide-react";

export default function BlogIndexPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAE3D6] text-xs uppercase tracking-widest text-[#4A5D4E] font-medium">
          <BookOpen className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>Sabiduría Sagrada & Práctica Cotidiana</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-5xl text-[#242B26] font-normal">
          Guías & Blog Místico
        </h1>
        <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
          Explicaciones claras sin dogmas ni oscurantismos: cómo sahumar tu casa, elegir tu primer cuarzo sin dudar y leer los secretos del fuego y el humo.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {BLOG_POSTS.map((post) => (
          <article
            key={post.slug}
            className="group bg-[#FDFBF7] rounded-3xl overflow-hidden border border-[#E8E2D9] hover:border-[#D4AF37]/50 shadow-xs hover:shadow-xl transition-all flex flex-col"
          >
            <div className="relative aspect-16/10 bg-stone-200 overflow-hidden">
              <Image
                src={post.image}
                alt={post.title}
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <span className="absolute top-4 left-4 bg-white/90 backdrop-blur-xs text-[10px] font-sans font-semibold uppercase tracking-wider text-[#4A5D4E] px-3 py-1 rounded-full shadow-xs">
                {post.category}
              </span>
            </div>

            <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between space-y-4">
              <div>
                <div className="text-[11px] text-[#7A877E] mb-2">
                  {post.date} • {post.readTime}
                </div>
                <h2 className="font-serif text-lg font-semibold text-[#242B26] group-hover:text-[#4A5D4E] transition-colors leading-snug">
                  {post.title}
                </h2>
                <p className="text-xs text-[#5B675E] mt-2.5 leading-relaxed line-clamp-3">
                  {post.excerpt}
                </p>
              </div>

              <Link
                href={`/guias/${post.slug}`}
                className="pt-4 border-t border-[#E8E2D9] inline-flex items-center gap-1 text-xs font-semibold text-[#4A5D4E] group-hover:text-[#242B26]"
              >
                <span>Leer artículo completo</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
