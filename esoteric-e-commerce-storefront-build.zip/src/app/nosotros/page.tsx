import React from "react";
import Image from "next/image";
import Link from "next/link";
import { Sparkles, ShieldCheck, Feather, HeartHandshake, Flame, Sun } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 space-y-16 sm:space-y-24">
      {/* Hero Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAE3D6] text-xs uppercase tracking-widest text-[#4A5D4E] font-medium">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Nuestra Razón de Ser</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl text-[#242B26] font-normal leading-tight">
            Nacimos para desmitificar lo esotérico y devolverle su <span className="italic text-[#4A5D4E]">luz natural</span>.
          </h1>

          <p className="text-sm sm:text-base text-[#5B675E] leading-relaxed">
            Durante décadas, las tiendas esotéricas estuvieron asociadas a escaparates saturados de oscuridad, figuras intimidantes y supersticiones que infundían miedo antes que paz.
          </p>

          <p className="text-sm sm:text-base text-[#5B675E] leading-relaxed">
            <strong>Perla & Pluma</strong> surge como un soplo de aire limpio: una propuesta contemporánea, serena y transparente donde cada persona —sin importar su credo o experiencia previa— puede acercarse a encender una vela de miel pura, sahumarse con palo santo ético o reposar su mirada en una amatista viva.
          </p>

          <div className="pt-2">
            <Link
              href="/catalogo"
              className="inline-block bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] px-7 py-3.5 rounded-xl text-xs uppercase tracking-wider font-medium transition-colors shadow-sm"
            >
              Explorar Nuestras Piezas
            </Link>
          </div>
        </div>

        <div className="lg:col-span-5 relative">
          <div className="relative aspect-4/5 rounded-3xl overflow-hidden shadow-xl border-4 border-[#FDFBF7] bg-stone-200">
            <Image
              src="https://images.pexels.com/photos/6806473/pexels-photo-6806473.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="Altar de trabajo en Perla & Pluma"
              fill
              className="object-cover"
              sizes="(max-width: 1024px) 100vw, 45vw"
            />
          </div>
        </div>
      </div>

      {/* Los 4 Pilares Inquebrantables */}
      <div className="bg-[#FAF7F0] rounded-3xl p-8 sm:p-14 border border-[#E8E2D9] space-y-10">
        <div className="text-center max-w-xl mx-auto">
          <span className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold">
            Código Deontológico
          </span>
          <h2 className="font-serif text-3xl text-[#242B26] mt-1">
            Los 4 Pilares de Perla & Pluma
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-[#4A5D4E]">
              <Flame className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <h3 className="font-serif text-base font-semibold text-[#242B26]">
              1. Cera Virgen & Botánica Real
            </h3>
            <p className="text-xs text-[#5B675E] leading-relaxed">
              Renunciamos al humo tóxico de parafinas derivadas del petróleo. Nuestras velas son de cera pura de abeja o soja vegetal con mechas de algodón sin plomo.
            </p>
          </div>

          <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-[#4A5D4E]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-base font-semibold text-[#242B26]">
              2. Rigor Técnico Mineral
            </h3>
            <p className="text-xs text-[#5B675E] leading-relaxed">
              Explicamos honestamente qué es cada piedra. Sin nombres inventados ni vidrios coloreados vendidos como gemas.
            </p>
          </div>

          <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-[#4A5D4E]">
              <Feather className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-base font-semibold text-[#242B26]">
              3. Recolección Ética
            </h3>
            <p className="text-xs text-[#5B675E] leading-relaxed">
              El Palo Santo proviene exclusivamente de madera caída de forma natural tras años en el bosque seco peruano, apoyando a comunidades indígenas.
            </p>
          </div>

          <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-[#4A5D4E]">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-base font-semibold text-[#242B26]">
              4. Cuidado en Cada Paquete
            </h3>
            <p className="text-xs text-[#5B675E] leading-relaxed">
              Cada pedido sale sahumado de nuestro altar, en caja kraft libre de plásticos, con ramita de lavanda silvestre y lacre auténtico.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
