import Link from "next/link";
import { Sparkles, ArrowLeft, Moon } from "lucide-react";

export default function NotFound() {
  return (
    <section className="min-h-[70vh] flex items-center justify-center px-4 py-20 bg-[#FAF7F0]">
      <div className="max-w-xl text-center space-y-6">
        <div className="w-16 h-16 rounded-full bg-[#EFE9DD] flex items-center justify-center mx-auto shadow-inner">
          <Moon className="w-7 h-7 text-[#4A5D4E]" />
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAE3D6] text-xs uppercase tracking-widest text-[#4A5D4E] font-medium">
          <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>Ruta fuera del altar</span>
        </div>

        <h1 className="font-serif text-4xl sm:text-5xl text-[#242B26] font-normal">
          Esta página se ha desvanecido como el humo
        </h1>

        <p className="text-sm text-[#5B675E] leading-relaxed">
          No encontramos lo que buscabas. Puede que la pieza haya cambiado de nombre o que el enlace esté incompleto. Vuelve al catálogo y deja que tu intuición elija el camino.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <Link
            href="/catalogo"
            className="w-full sm:w-auto bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] px-7 py-3.5 rounded-xl text-xs uppercase tracking-wider font-medium transition-colors shadow-sm"
          >
            Explorar el catálogo
          </Link>
          <Link
            href="/"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 bg-[#FDFBF7] hover:bg-[#F2ECE1] text-[#242B26] border border-[#DDD3C3] px-6 py-3.5 rounded-xl text-xs uppercase tracking-wider font-medium transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Volver al inicio</span>
          </Link>
        </div>
      </div>
    </section>
  );
}
