import React from "react";
import Link from "next/link";
import { Sparkles, ArrowRight, ShieldCheck, Flame, HeartHandshake } from "lucide-react";
import { ProductCard } from "@/components/ProductCard";
import { IntentionSelector } from "@/components/IntentionSelector";
import { CategoryCardsSection } from "@/components/CategoryCardsSection";
import { HeroRetreat } from "@/components/HeroRetreat";
import { CelestialBand } from "@/components/decor/CelestialBand";
import {
  Mandala,
  FlowerOfLife,
  StarDivider,
  SectionOrnament,
  SacredBackdrop,
} from "@/components/decor/Ornaments";
import { BLOG_POSTS } from "@/data/blogData";
import { getAllProducts, getLatestReviews } from "@/lib/catalog";
import Image from "next/image";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  // Works with PostgreSQL when available and falls back to the curated demo catalogue.
  const allProducts = await getAllProducts();
  const featured = allProducts.filter((p) => p.isFeatured).slice(0, 4);
  const ritualKits = allProducts.filter((p) => p.category === "kits-rituales").slice(0, 3);
  const recentReviews = await getLatestReviews(3);

  return (
    <div className="space-y-16 sm:space-y-24">
      {/* 1. PORTADA: LA FOTOGRAFÍA MANDA (salvia blanca, perla y concha sobre lino) */}
      <HeroRetreat />

      {/* 2. FILTRO EMOCIONAL / BUSCADOR POR INTENCIÓN (Bloque B) */}
      <IntentionSelector />

      {/* 3. CARROUSEL / BLOQUE DE CATEGORÍAS PRINCIPALES (Bloque A) */}
      <CategoryCardsSection />

      {/* 4. BLOQUE DE NOVEDADES Y PIEZAS DESTACADAS */}
      <section className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Mandala
          size={520}
          opacity={0.12}
          className="pointer-events-none absolute -right-40 -top-32 hidden lg:block animate-spin-slower"
        />
        <div className="relative flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
          <div>
            <SectionOrnament label="Selección esencial" align="left" />
            <h2 className="font-serif text-3xl sm:text-4xl text-[#242B26] font-normal">
              Piezas Estrella para tu Altar
            </h2>
            <div className="flex items-center gap-2 mt-3">
              <span className="h-px w-10 bg-[#D8C79E]" />
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="h-px w-24 bg-linear-to-r from-[#D8C79E] to-transparent" />
            </div>
          </div>
          <Link
            href="/catalogo"
            className="text-xs sm:text-sm font-medium text-[#4A5D4E] hover:underline flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Ver todo el catálogo ({allProducts.length} piezas)</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featured.map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </section>

      {/* 4-bis. GEOMETRÍA SAGRADA Y CICLO LUNAR */}
      <CelestialBand />

      {/* 5. SECCIÓN ESPECIAL: KITS DE RITUALES (Completos, empaquetados con mimo para regalar) */}
      <section className="bg-[#FAF7F0] py-16 px-4 sm:px-6 lg:px-8 border-y border-[#E8E2D9]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <SectionOrnament label="Soluciones integrales" tone="gold" />
            <h2 className="font-serif text-3xl sm:text-4xl text-[#242B26]">
              Kits de Rituales: Listos para Regalar
            </h2>
            <StarDivider className="mt-5" />
            <p className="text-xs sm:text-sm text-[#5B675E] mt-3">
              Incluyen todos los elementos armonizados, listas numeradas desglosadas y guía física explicada paso a paso para realizar el ritual sin dudas.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {ritualKits.map((kit) => (
              <ProductCard key={kit.id} product={kit} />
            ))}
          </div>
        </div>
      </section>

      {/* 6. SECCIÓN INFORMATIVA: POR QUÉ COMPRAR CON NOSOTROS (Zonas de Información y Generación de Confianza) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden bg-[#F4EFE6] rounded-3xl p-8 sm:p-12 border border-[#E0D7C8]">
          <SacredBackdrop variant="mandala" opacity={0.12} />
          <div className="relative text-center max-w-2xl mx-auto mb-12">
            <SectionOrnament label="El manifiesto" />
            <span className="sr-only">El Manifiesto de Perla & Pluma</span>
            <h2 className="font-serif text-2xl sm:text-3xl text-[#242B26]">
              La Diferencia de un Misticismo Transparente
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Value 1 */}
            <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3 text-center md:text-left">
              <div className="w-12 h-12 rounded-xl bg-[#EFE9DD] flex items-center justify-center text-[#4A5D4E] mx-auto md:mx-0">
                <Sparkles className="w-6 h-6 text-[#D4AF37]" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-[#242B26]">
                Ritualización previa al envío
              </h3>
              <p className="text-xs text-[#5B675E] leading-relaxed">
                Ninguna pieza viaja como un objeto inerte de almacén. Cada cuarzo, velón o baraja pasa por sahúmo y bendición de luz en nuestro altar físico antes del empaquetado para llegar listo y receptivo.
              </p>
            </div>

            {/* Value 2 */}
            <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3 text-center md:text-left">
              <div className="w-12 h-12 rounded-xl bg-[#EFE9DD] flex items-center justify-center text-[#4A5D4E] mx-auto md:mx-0">
                <ShieldCheck className="w-6 h-6 text-[#4A5D4E]" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-[#242B26]">
                Rigor Técnico & Transparencia Mineral
              </h3>
              <p className="text-xs text-[#5B675E] leading-relaxed">
                Garantía estricta de que son minerales 100% naturales seleccionados. Indicamos con claridad qué gemas no deben mojarse (pirita, selenita) y cuáles admiten agua, evitando mitos perjudiciales.
              </p>
            </div>

            {/* Value 3 */}
            <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3 text-center md:text-left">
              <div className="w-12 h-12 rounded-xl bg-[#EFE9DD] flex items-center justify-center text-[#4A5D4E] mx-auto md:mx-0">
                <HeartHandshake className="w-6 h-6 text-rose-600" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-[#242B26]">
                Empaquetado Cuidadoso & Obsequios
              </h3>
              <p className="text-xs text-[#5B675E] leading-relaxed">
                Cada paquete llega con mimo, viruta natural reciclable, ramillete botánico de lavanda seca, tarjeta de consejos y un pequeño mineral de regalo para darte la bienvenida a nuestra comunidad.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 7. TESTIMONIOS Y RESEÑAS DE CLIENTES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-10">
          <SectionOrnament label="Comunidad de almas afines" tone="gold" />
          <h2 className="font-serif text-3xl text-[#242B26]">
            Voces del Círculo de Perla & Pluma
          </h2>
          <StarDivider className="mt-5" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {recentReviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9] shadow-xs flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center gap-1 text-[#D4AF37]">
                  {Array.from({ length: rev.rating }).map((_, i) => (
                    <Sparkles key={i} className="w-3.5 h-3.5 fill-[#D4AF37]" />
                  ))}
                </div>
                <h4 className="font-serif text-base font-semibold text-[#242B26]">
                  &quot;{rev.title}&quot;
                </h4>
                <p className="text-xs text-[#5B675E] leading-relaxed">
                  {rev.comment}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-[#E8E2D9]/60 flex items-center justify-between text-xs text-[#7A877E]">
                <div>
                  <span className="font-semibold text-[#242B26] block">{rev.author}</span>
                  <span className="text-[11px]">{rev.city}</span>
                </div>
                {rev.verifiedPurchase && (
                  <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    Compra Verificada
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8. ÚLTIMOS ARTÍCULOS DEL BLOG / GUÍAS ESPIRITUALES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
          <div>
            <SectionOrnament label="Aprender y crecer" align="left" />
            <h2 className="font-serif text-3xl text-[#242B26]">
              Guías & Artículos del Blog Místico
            </h2>
          </div>
          <Link
            href="/guias"
            className="text-xs sm:text-sm font-medium text-[#4A5D4E] hover:underline flex items-center gap-1"
          >
            <span>Leer todas las guías</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {BLOG_POSTS.map((post) => (
            <Link
              key={post.slug}
              href={`/guias/${post.slug}`}
              className="group bg-[#FDFBF7] rounded-2xl overflow-hidden border border-[#E8E2D9] hover:border-[#D4AF37]/50 shadow-xs hover:shadow-lg transition-all flex flex-col"
            >
              <div className="relative aspect-16/10 bg-stone-200 overflow-hidden">
                <Image
                  src={post.image}
                  alt={post.title}
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <span className="absolute top-3 left-3 bg-[#FDFBF7]/90 backdrop-blur-xs text-[10px] font-semibold uppercase tracking-wider text-[#4A5D4E] px-2.5 py-1 rounded-full shadow-xs">
                  {post.category}
                </span>
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-[11px] text-[#8A968D] mb-1.5">{post.date} • {post.readTime}</div>
                  <h3 className="font-serif text-base font-semibold text-[#242B26] group-hover:text-[#4A5D4E] transition-colors leading-snug">
                    {post.title}
                  </h3>
                  <p className="text-xs text-[#5B675E] mt-2 line-clamp-2 leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#E8E2D9]/60 flex items-center text-xs font-semibold text-[#4A5D4E]">
                  <span>Leer guía completa →</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
