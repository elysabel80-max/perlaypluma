interface BrandLogoProps {
  className?: string;
  /** Height in px. Width follows the 1220 x 380 viewBox. */
  height?: number;
  tone?: "dark" | "light";
  withWordmark?: boolean;
}

/**
 * Alas del logotipo: plumas largas y afiladas con barrido ascendente,
 * como en el dibujo original (no plumas redondeadas tipo gallina).
 * El hombro del ala nace en (0,0) y las plumas apuntan hacia la izquierda.
 */
function Wing({ gold, shine }: { gold: string; shine: string }) {
  // Plumas largas de punta redondeada: longitud (L), punta vertical (tipY), grosor (W).
  const feathers = [
    { L: 302, tipY: -44, W: 15 },
    { L: 300, tipY: -12, W: 16 },
    { L: 276, tipY: 18, W: 16 },
    { L: 240, tipY: 48, W: 15 },
    { L: 198, tipY: 76, W: 13 },
    { L: 152, tipY: 100, W: 11 },
    { L: 104, tipY: 118, W: 9 },
  ];

  const featherPath = (L: number, tipY: number, W: number) =>
    `M0,${-W} C${-L * 0.3},${tipY - 34} ${-L * 0.72},${tipY - 26} ${-L},${tipY} ` +
    `C${-L * 0.74},${tipY + 16} ${-L * 0.36},${W * 0.6} 0,${W} Z`;

  return (
    <g>
      {/* Plumas: la más larga al fondo, las coberteras encima */}
      {feathers.map((f, i) => (
        <g key={i}>
          <path
            d={featherPath(f.L, f.tipY, f.W)}
            fill={`url(#${gold})`}
            stroke="#8A6520"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          {/* Reflejo superior de la pluma */}
          <path
            d={`M-8,${-f.W * 0.5} C${-f.L * 0.3},${f.tipY - 26} ${-f.L * 0.68},${f.tipY - 18} ${-f.L * 0.94},${f.tipY - 2}`}
            fill="none"
            stroke={shine}
            strokeWidth="4"
            strokeLinecap="round"
            opacity="0.5"
          />
          {/* Cañón central */}
          <path
            d={`M-6,${f.W * 0.25} C${-f.L * 0.32},${f.tipY * 0.55 + 4} ${-f.L * 0.66},${f.tipY * 0.85} ${-f.L * 0.92},${f.tipY}`}
            fill="none"
            stroke="#8A6520"
            strokeWidth="1"
            opacity="0.3"
          />
        </g>
      ))}

      {/* Hombro / cobertera: placa curva que une el ala al pergamino */}
      <path
        d="M8,-62 C-58,-70 -132,-40 -172,2 C-112,-18 -42,-4 8,26 C24,-2 24,-38 8,-62 Z"
        fill={`url(#${gold})`}
        stroke="#8A6520"
        strokeWidth="2.2"
        strokeLinejoin="round"
      />
      <path
        d="M0,-52 C-52,-58 -114,-34 -148,-2"
        fill="none"
        stroke={shine}
        strokeWidth="5"
        strokeLinecap="round"
        opacity="0.7"
      />
      <path
        d="M-14,-16 C-46,-8 -78,10 -98,30"
        fill="none"
        stroke="#8A6520"
        strokeWidth="1.1"
        opacity="0.28"
      />
    </g>
  );
}

/**
 * Logotipo de Perla & Pluma: alas doradas, banda de pergamino, orla
 * filigranada, huella y lettering script. Vectorial para máxima nitidez.
 */
export function BrandLogo({
  className = "",
  height = 56,
  tone = "dark",
  withWordmark = true,
}: BrandLogoProps) {
  const uid = tone === "light" ? "brandLight" : "brandDark";

  return (
    <svg
      viewBox="0 0 1220 380"
      height={height}
      role="img"
      aria-label="Perla & Pluma"
      className={`w-auto ${className}`}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id={`${uid}-gold`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FCEBB4" />
          <stop offset="30%" stopColor="#E9CB84" />
          <stop offset="62%" stopColor="#C9A24A" />
          <stop offset="100%" stopColor="#9E7626" />
        </linearGradient>
        <linearGradient id={`${uid}-goldDeep`} x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#9E7626" />
          <stop offset="50%" stopColor="#D4AF62" />
          <stop offset="100%" stopColor="#FBE7A9" />
        </linearGradient>
        <linearGradient id={`${uid}-banner`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FEFAF0" />
          <stop offset="55%" stopColor="#FBF2D9" />
          <stop offset="100%" stopColor="#F4E6C1" />
        </linearGradient>
        <linearGradient id={`${uid}-text`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#E4C170" />
          <stop offset="52%" stopColor="#C69F46" />
          <stop offset="100%" stopColor="#9E7626" />
        </linearGradient>
        <linearGradient id={`${uid}-paw`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#CDB078" />
          <stop offset="100%" stopColor="#9C7B45" />
        </linearGradient>
      </defs>

      {/* ALA IZQUIERDA (hombro en el borde del pergamino) */}
      <g transform="translate(352 178)">
        <Wing gold={`${uid}-gold`} shine="#FFF6D8" />
      </g>

      {/* ALA DERECHA (espejo exacto) */}
      <g transform="translate(868 178) scale(-1 1)">
        <Wing gold={`${uid}-gold`} shine="#FFF6D8" />
      </g>

      {/* ORLA SUPERIOR */}
      <g stroke={`url(#${uid}-goldDeep)`} fill="none" strokeWidth="3" strokeLinecap="round">
        <path d="M470 120C452 102 432 108 426 94C418 110 400 106 392 118" />
        <path d="M446 112C452 100 466 98 472 108" />
        <path d="M530 118C540 104 556 104 562 114" />
        <g transform="translate(1220 0) scale(-1 1)">
          <path d="M470 120C452 102 432 108 426 94C418 110 400 106 392 118" />
          <path d="M446 112C452 100 466 98 472 108" />
          <path d="M530 118C540 104 556 104 562 114" />
        </g>
      </g>

      {/* HUELLA */}
      <g fill={`url(#${uid}-paw)`}>
        <ellipse cx="610" cy="96" rx="27" ry="21" />
        <ellipse cx="578" cy="62" rx="12" ry="15" transform="rotate(-18 578 62)" />
        <ellipse cx="602" cy="50" rx="11" ry="15" transform="rotate(-6 602 50)" />
        <ellipse cx="627" cy="53" rx="11" ry="14" transform="rotate(10 627 53)" />
        <ellipse cx="649" cy="69" rx="10" ry="13" transform="rotate(24 649 69)" />
        <circle cx="561" cy="88" r="3.4" />
        <circle cx="655" cy="92" r="3" />
        <circle cx="572" cy="44" r="2.4" />
        <circle cx="639" cy="36" r="2.2" />
        <circle cx="654" cy="52" r="1.9" />
      </g>

      {/* BANDA / PERGAMINO */}
      <rect x="356" y="120" width="508" height="112" rx="10" fill={`url(#${uid}-banner)`} stroke="#C9A24A" strokeWidth="2.5" />
      <rect x="366" y="129" width="488" height="94" rx="6" fill="none" stroke="#E0C382" strokeWidth="1.2" />
      <path d="M356 132C356 124 364 120 372 120H848C856 120 864 124 864 132" fill="#FFF8E2" opacity="0.7" />

      {/* WORDMARK */}
      {withWordmark && (
        <text
          x="610"
          y="196"
          textAnchor="middle"
          fill={`url(#${uid}-text)`}
          fontFamily="'Great Vibes', 'Parisienne', 'Brush Script MT', 'Segoe Script', 'Lucida Handwriting', cursive"
          fontSize="68"
          fontStyle="italic"
          letterSpacing="0.5"
        >
          Perla &amp; Pluma
        </text>
      )}

      {/* ORLA INFERIOR */}
      <g stroke={`url(#${uid}-goldDeep)`} fill="none" strokeWidth="3" strokeLinecap="round">
        <path d="M610 232C596 252 574 258 558 246C542 264 514 264 498 248" />
        <path d="M610 232C624 252 646 258 662 246C678 264 706 264 722 248" />
        <path d="M610 240C606 262 610 280 610 292" />
        <path d="M610 292C602 284 596 282 590 280C598 292 602 300 604 308C608 300 612 296 616 292C614 300 618 306 622 310" />
        <path d="M560 246C548 252 540 262 542 274" />
        <path d="M660 246C672 252 680 262 678 274" />
        <g transform="translate(1220 0) scale(-1 1)">
          <path d="M560 246C548 252 540 262 542 274" />
        </g>
      </g>
    </svg>
  );
}
