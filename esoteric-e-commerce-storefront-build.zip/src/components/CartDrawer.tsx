"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useCart } from "@/context/CartContext";
import { X, Trash2, Plus, Minus, Sparkles, Gift, CheckCircle, ArrowRight, ShoppingBag } from "lucide-react";
import { FREE_SHIPPING_THRESHOLD, GIFT_PACKAGING_COST } from "@/lib/shipping";
import confetti from "canvas-confetti";

export function CartDrawer() {
  const {
    items,
    isOpen,
    closeCart,
    removeItem,
    updateQuantity,
    clearCart,
    subtotal,
    memberDiscount,
    memberPlanLabel,
    shipping,
    total,
    giftPackaging,
    setGiftPackaging,
    intentionNote,
    setIntentionNote,
  } = useCart();

  const [checkoutStep, setCheckoutStep] = useState<"cart" | "form" | "confirmed">("cart");
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<any>(null);

  if (!isOpen) return null;

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail || !address) return;

    setIsSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName,
          customerEmail,
          customerPhone,
          address,
          city,
          postalCode,
          intentionNote,
          giftPackaging,
          items,
          subtotal: subtotal.toFixed(2),
          shipping: shipping.toFixed(2),
          total: total.toFixed(2),
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setCompletedOrder(data.order);
        setCheckoutStep("confirmed");
        clearCart();
        try {
          confetti({
            particleCount: 70,
            spread: 60,
            origin: { y: 0.6 },
            colors: ["#D4AF37", "#4A5D4E", "#FDFBF7"],
          });
        } catch {}
      }
    } catch (err) {
      console.error("Checkout error:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCloseAndReset = () => {
    closeCart();
    if (checkoutStep === "confirmed") {
      setCheckoutStep("cart");
      setCompletedOrder(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm transition-opacity"
        onClick={handleCloseAndReset}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FDFBF7] text-[#2B352E] shadow-2xl flex flex-col border-l border-[#E8E2D9]">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-[#E8E2D9] flex items-center justify-between bg-[#F8F5EE]">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#4A5D4E]" />
              <h2 className="font-serif text-lg font-semibold text-[#242B26]">
                {checkoutStep === "cart" && "Tu Altar de Compras"}
                {checkoutStep === "form" && "Consagración de Envío"}
                {checkoutStep === "confirmed" && "¡Bendición Confirmada!"}
              </h2>
            </div>
            <button
              onClick={handleCloseAndReset}
              className="p-1.5 rounded-full hover:bg-[#ECE5D8] text-stone-500 hover:text-stone-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {checkoutStep === "confirmed" && completedOrder ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 bg-emerald-100 text-[#4A5D4E] rounded-full flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle className="w-10 h-10" />
                </div>
                <h3 className="font-serif text-xl text-[#242B26]">
                  Pedido #{completedOrder.orderNumber}
                </h3>
                <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
                  Gracias, <span className="font-semibold">{completedOrder.customerName}</span>. Tus piezas sagradas están siendo preparadas con sahumado previo y llegarán a:
                </p>
                <div className="p-3 bg-[#F2ECE1] rounded-lg text-xs text-stone-700 text-left border border-[#E0D7C8]">
                  <p><strong>Dirección:</strong> {completedOrder.address}, {completedOrder.city} ({completedOrder.postalCode})</p>
                  <p className="mt-1"><strong>Total abonado:</strong> {Number(completedOrder.total).toFixed(2)} €</p>
                  {completedOrder.intentionNote && (
                    <p className="mt-1 italic text-stone-600">
                      <strong>Intención:</strong> &quot;{completedOrder.intentionNote}&quot;
                    </p>
                  )}
                </div>
                <div className="p-3 bg-amber-50 rounded-lg text-xs text-amber-900 border border-amber-200 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Te hemos enviado la confirmación y guía mística a <strong>{completedOrder.customerEmail}</strong>.</span>
                </div>
                <button
                  onClick={handleCloseAndReset}
                  className="w-full mt-4 bg-[#4A5D4E] text-[#FDFBF7] py-2.5 rounded-lg text-sm font-medium hover:bg-[#3B4B3F] transition-colors"
                >
                  Continuar explorando el catálogo
                </button>
              </div>
            ) : checkoutStep === "form" ? (
              <form onSubmit={handleCheckoutSubmit} className="space-y-3.5">
                <div className="text-xs text-[#5B675E] pb-2 border-b border-[#E8E2D9]">
                  Indícanos a dónde dirigir la vibración y el envío físico de tu paquete.
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Nombre completo *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Elena Gómez Soler"
                    className="w-full bg-[#F5EFE6] border border-[#D9D1C5] rounded-md px-3 py-2 text-xs focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Correo electrónico *
                  </label>
                  <input
                    type="email"
                    required
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="elena@ejemplo.com"
                    className="w-full bg-[#F5EFE6] border border-[#D9D1C5] rounded-md px-3 py-2 text-xs focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Teléfono (para transportista)
                  </label>
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="+34 600 000 000"
                    className="w-full bg-[#F5EFE6] border border-[#D9D1C5] rounded-md px-3 py-2 text-xs focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Dirección de entrega *
                  </label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Calle Almirante 14, 3º Izq"
                    className="w-full bg-[#F5EFE6] border border-[#D9D1C5] rounded-md px-3 py-2 text-xs focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Ciudad *
                    </label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="Madrid"
                      className="w-full bg-[#F5EFE6] border border-[#D9D1C5] rounded-md px-3 py-2 text-xs focus:outline-none focus:border-[#4A5D4E]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Código Postal *
                    </label>
                    <input
                      type="text"
                      required
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value)}
                      placeholder="28004"
                      className="w-full bg-[#F5EFE6] border border-[#D9D1C5] rounded-md px-3 py-2 text-xs focus:outline-none focus:border-[#4A5D4E]"
                    />
                  </div>
                </div>

                {/* Intention note */}
                <div className="pt-2">
                  <label className="block text-xs font-semibold text-[#4A5D4E] mb-1 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Intención o Petición especial para el altar (opcional):</span>
                  </label>
                  <textarea
                    value={intentionNote}
                    onChange={(e) => setIntentionNote(e.target.value)}
                    rows={2}
                    placeholder="Ej: Bendición para mudanza a nuevo piso, o consagración para exámenes..."
                    className="w-full bg-[#F5EFE6] border border-[#D9D1C5] rounded-md p-2 text-xs focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>

                <div className="flex gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setCheckoutStep("cart")}
                    className="flex-1 border border-stone-300 py-2.5 rounded-lg text-xs font-medium hover:bg-stone-100 text-stone-700"
                  >
                    Volver a la cesta
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] py-2.5 rounded-lg text-xs font-medium transition-colors shadow-sm"
                  >
                    {isSubmitting ? "Consagrando..." : `Pagar ${total.toFixed(2)} €`}
                  </button>
                </div>
              </form>
            ) : items.length === 0 ? (
              <div className="text-center py-12 space-y-4">
                <div className="p-4 bg-[#F2ECE1] rounded-full w-16 h-16 mx-auto flex items-center justify-center text-stone-400">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <p className="font-serif text-base text-[#242B26]">Tu cesta sagrada está vacía</p>
                <p className="text-xs text-[#6B786E] max-w-xs mx-auto">
                  Explora nuestras colecciones de velas de miel, cuarzos y atados sagrados para comenzar.
                </p>
                <Link
                  href="/catalogo"
                  onClick={closeCart}
                  className="inline-block mt-2 bg-[#4A5D4E] text-[#FDFBF7] text-xs font-medium py-2.5 px-5 rounded-lg hover:bg-[#3B4B3F] transition-colors"
                >
                  Ver Catálogo Sagrado
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="flex gap-3 p-3 bg-white rounded-xl border border-[#E8E2D9] shadow-xs"
                  >
                    <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-stone-100 shrink-0">
                      <Image
                        src={item.image}
                        alt={item.name}
                        fill
                        className="object-cover"
                        sizes="64px"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <Link
                        href={`/producto/${item.slug}`}
                        onClick={closeCart}
                        className="text-xs font-serif font-medium text-[#242B26] hover:text-[#4A5D4E] line-clamp-1"
                      >
                        {item.name}
                      </Link>
                      <p className="text-[11px] text-[#7A877E] line-clamp-1">{item.subtitle}</p>
                      <div className="mt-2 flex items-center justify-between">
                        <div className="flex items-center border border-stone-200 rounded-md bg-[#FDFBF7]">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="p-1 text-stone-500 hover:text-stone-800"
                            aria-label="Disminuir"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 text-xs font-medium">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-1 text-stone-500 hover:text-stone-800"
                            aria-label="Aumentar"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold text-[#242B26]">
                            {(item.price * item.quantity).toFixed(2)} €
                          </span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => removeItem(item.id)}
                      className="text-stone-400 hover:text-rose-600 transition-colors p-1 self-start"
                      aria-label="Eliminar"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}

                {/* Gift packaging option */}
                <div className="p-3 bg-[#F5EFE6] rounded-xl border border-[#DFD6C6] space-y-2 mt-4">
                  <label className="flex items-center justify-between cursor-pointer">
                    <div className="flex items-center gap-2">
                      <Gift className="w-4 h-4 text-[#D4AF37]" />
                      <span className="text-xs font-medium text-stone-800">
                        Preparar para Regalo Especial (+{GIFT_PACKAGING_COST.toFixed(2).replace(".", ",")} €)
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={giftPackaging}
                      onChange={(e) => setGiftPackaging(e.target.checked)}
                      className="rounded text-[#4A5D4E] focus:ring-[#4A5D4E] h-4 w-4"
                    />
                  </label>
                  <p className="text-[11px] text-[#6E7B71]">
                    Caja rígida kraft, ramita de lavanda natural, sellado con lacre perla y dedicatoria manuscrita.
                  </p>
                </div>

                {/* Free shipping banner */}
                <div className="p-2.5 bg-emerald-50 rounded-lg border border-emerald-200 text-xs text-emerald-900 flex items-center justify-between">
                  <span>
                    {subtotal - memberDiscount >= FREE_SHIPPING_THRESHOLD
                      ? "✨ ¡Enhorabuena! Tienes Envío Gratis incluido."
                      : `Añade ${(FREE_SHIPPING_THRESHOLD - (subtotal - memberDiscount)).toFixed(2)} € más para Envío Gratis`}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Footer of the Drawer */}
          {checkoutStep === "cart" && items.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-[#E8E2D9] bg-[#F8F5EE] space-y-3">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-[#68756B]">
                  <span>Subtotal</span>
                  <span>{subtotal.toFixed(2)} €</span>
                </div>
                {giftPackaging && (
                  <div className="flex justify-between text-[#68756B]">
                    <span>Empaquetado Regalo</span>
                    <span>{GIFT_PACKAGING_COST.toFixed(2).replace(".", ",")} €</span>
                  </div>
                )}
                {memberDiscount > 0 && (
                  <div className="flex justify-between text-emerald-800 font-medium">
                    <span>{memberPlanLabel} · descuento</span>
                    <span>-{memberDiscount.toFixed(2)} €</span>
                  </div>
                )}
                <div className="flex justify-between text-[#68756B]">
                  <span>Envío (Península 24-48h)</span>
                  <span>{shipping === 0 ? "GRATIS" : `${shipping.toFixed(2)} €`}</span>
                </div>
                <div className="flex justify-between text-sm font-serif font-bold text-[#242B26] pt-1.5 border-t border-[#E8E2D9]">
                  <span>Total a pagar</span>
                  <span>{total.toFixed(2)} €</span>
                </div>
              </div>

              <button
                onClick={() => setCheckoutStep("form")}
                className="w-full bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] py-3 rounded-xl font-medium text-xs tracking-wider uppercase transition-colors shadow-sm flex items-center justify-center gap-2"
              >
                <span>Finalizar Pedido Consagrado</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
