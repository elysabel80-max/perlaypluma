"use client";

import React, { useState, useMemo } from "react";
import { ProductCard } from "@/components/ProductCard";
import { CATEGORIES, INTENTIONS } from "@/data/categories";
import type { ProductRecord } from "@/lib/catalog";
import {
  Sparkles,
  X,
  Shield,
  Feather,
  Sun,
  Heart,
  Moon,
  Search,
  SlidersHorizontal,
} from "lucide-react";

interface CatalogClientProps {
  initialProducts: ProductRecord[];
  initialFilters?: {
    category?: string;
    intention?: string;
    q?: string;
    subcategory?: string;
  };
}

export function CatalogClient({ initialProducts, initialFilters }: CatalogClientProps) {
  const initialCategory = initialFilters?.category || "all";
  const initialIntention = initialFilters?.intention || "all";
  const initialSearch = initialFilters?.q || "";
  const initialSubcategory = initialFilters?.subcategory || "all";

  const [productsList] = useState<ProductRecord[]>(initialProducts);
  const loading = false;
  const [categoryFilter, setCategoryFilter] = useState(initialCategory);
  const [intentionFilter, setIntentionFilter] = useState(initialIntention);
  const [subcategoryFilter, setSubcategoryFilter] = useState(initialSubcategory);
  const [searchFilter, setSearchFilter] = useState(initialSearch);
  const [sortBy, setSortBy] = useState<"featured" | "price-asc" | "price-desc" | "rating">("featured");
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const activeCategory = CATEGORIES.find((c) => c.id === categoryFilter);

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    return productsList
      .filter((p) => {
        if (categoryFilter !== "all" && p.category !== categoryFilter) return false;
        if (intentionFilter !== "all" && p.intention !== intentionFilter) return false;
        if (subcategoryFilter !== "all" && p.subcategory !== subcategoryFilter) return false;
        if (searchFilter.trim() !== "") {
          const q = searchFilter.toLowerCase();
          const match =
            p.name.toLowerCase().includes(q) ||
            p.subtitle.toLowerCase().includes(q) ||
            p.shortDescription.toLowerCase().includes(q) ||
            p.subcategory.toLowerCase().includes(q);
          if (!match) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === "price-asc") return parseFloat(a.price) - parseFloat(b.price);
        if (sortBy === "price-desc") return parseFloat(b.price) - parseFloat(a.price);
        if (sortBy === "rating") return parseFloat(b.rating || "0") - parseFloat(a.rating || "0");
        return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
      });
  }, [productsList, categoryFilter, intentionFilter, subcategoryFilter, searchFilter, sortBy]);

  const clearAllFilters = () => {
    setCategoryFilter("all");
    setIntentionFilter("all");
    setSubcategoryFilter("all");
    setSearchFilter("");
    setSortBy("featured");
  };

  const getIntentionIcon = (id: string) => {
    switch (id) {
      case "proteccion":
        return <Shield className="w-3.5 h-3.5" />;
      case "calma":
        return <Feather className="w-3.5 h-3.5" />;
      case "abundancia":
        return <Sun className="w-3.5 h-3.5" />;
      case "amor":
        return <Heart className="w-3.5 h-3.5" />;
      case "intuicion":
        return <Moon className="w-3.5 h-3.5" />;
      default:
        return <Sparkles className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      {/* Header Banner */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAE3D6] text-xs uppercase tracking-widest text-[#4A5D4E] font-medium">
          <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>Misticismo Contemporáneo & Curaduría Serena</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-5xl text-[#242B26] font-normal">
          {activeCategory ? activeCategory.name : "Catálogo Sagrado Completo"}
        </h1>
        <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
          {activeCategory
            ? activeCategory.description
            : "Explora nuestra selección completa de velas de cera de abeja, minerales con rigor geológico, sahumerios éticos y cajas ritualizadas con amor."}
        </p>
      </div>

      {/* Bloque B: Navegación Rápida por Intención (Pills Superiores) */}
      <div className="bg-[#FAF7F0] p-4 sm:p-5 rounded-2xl border border-[#E8E2D9] space-y-3">
        <div className="flex items-center justify-between text-xs text-[#6A786E] font-sans font-semibold uppercase tracking-wider">
          <span className="flex items-center gap-1 text-[#4A5D4E]">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Filtro Emocional / Propósito:</span>
          </span>
          {intentionFilter !== "all" && (
            <button
              onClick={() => setIntentionFilter("all")}
              className="text-stone-500 hover:text-stone-800 text-[11px] underline"
            >
              Mostrar todas las intenciones
            </button>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setIntentionFilter("all")}
            className={`px-3 py-1.5 rounded-full text-xs font-serif transition-colors ${
              intentionFilter === "all"
                ? "bg-[#4A5D4E] text-[#FDFBF7] shadow-xs"
                : "bg-[#FDFBF7] text-[#2B352E] hover:bg-[#EAE3D6] border border-[#DDD3C3]"
            }`}
          >
            Todas las energías ({productsList.length})
          </button>
          {Object.values(INTENTIONS).map((item) => (
            <button
              key={item.id}
              onClick={() => setIntentionFilter(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-serif transition-colors ${
                intentionFilter === item.id
                  ? "bg-[#4A5D4E] text-[#FDFBF7] shadow-xs"
                  : "bg-[#FDFBF7] text-[#2B352E] hover:bg-[#EAE3D6] border border-[#DDD3C3]"
              }`}
            >
              <span className={intentionFilter === item.id ? "text-[#D4AF37]" : "text-[#4A5D4E]"}>
                {getIntentionIcon(item.id)}
              </span>
              <span>{item.name.split("&")[0]}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Sidebar (Bloque A Categorías & Subcategorías) + Products */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:block space-y-6 sticky top-28 bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9]">
          <div>
            <h3 className="font-serif text-sm font-semibold text-[#242B26] pb-2 border-b border-[#E8E2D9] mb-3 flex items-center justify-between">
              <span>Colecciones Sagradas</span>
              {categoryFilter !== "all" && (
                <button
                  onClick={() => {
                    setCategoryFilter("all");
                    setSubcategoryFilter("all");
                  }}
                  className="text-[11px] text-[#4A5D4E] hover:underline"
                >
                  Ver todas
                </button>
              )}
            </h3>
            <ul className="space-y-1 text-xs">
              <li>
                <button
                  onClick={() => {
                    setCategoryFilter("all");
                    setSubcategoryFilter("all");
                  }}
                  className={`w-full text-left py-1.5 px-2 rounded-lg transition-colors ${
                    categoryFilter === "all"
                      ? "bg-[#4A5D4E] text-[#FDFBF7] font-semibold"
                      : "text-stone-700 hover:bg-[#F2ECE1]"
                  }`}
                >
                  Todas las categorías
                </button>
              </li>
              {CATEGORIES.map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => {
                      setCategoryFilter(cat.id);
                      setSubcategoryFilter("all");
                    }}
                    className={`w-full text-left py-1.5 px-2 rounded-lg transition-colors flex items-center justify-between ${
                      categoryFilter === cat.id
                        ? "bg-[#4A5D4E] text-[#FDFBF7] font-semibold"
                        : "text-stone-700 hover:bg-[#F2ECE1]"
                    }`}
                  >
                    <span>{cat.name}</span>
                  </button>

                  {/* Subcategories list if category is active */}
                  {categoryFilter === cat.id && (
                    <div className="pl-3 py-1 space-y-1 border-l-2 border-[#D4AF37] my-1 ml-2">
                      <button
                        onClick={() => setSubcategoryFilter("all")}
                        className={`block text-[11px] text-left w-full py-0.5 ${
                          subcategoryFilter === "all"
                            ? "text-[#4A5D4E] font-bold"
                            : "text-stone-500 hover:text-stone-800"
                        }`}
                      >
                        • Todas las subcategorías
                      </button>
                      {cat.subcategories.map((sub, sIdx) => (
                        <button
                          key={sIdx}
                          onClick={() => setSubcategoryFilter(sub)}
                          className={`block text-[11px] text-left w-full py-0.5 ${
                            subcategoryFilter === sub
                              ? "text-[#4A5D4E] font-bold underline"
                              : "text-stone-500 hover:text-stone-800"
                          }`}
                        >
                          • {sub}
                        </button>
                      ))}
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Quick reset */}
          {(categoryFilter !== "all" ||
            intentionFilter !== "all" ||
            subcategoryFilter !== "all" ||
            searchFilter !== "") && (
            <button
              onClick={clearAllFilters}
              className="w-full text-center text-xs text-rose-700 hover:text-rose-900 py-2 border border-rose-200 rounded-lg bg-rose-50/50 flex items-center justify-center gap-1"
            >
              <X className="w-3.5 h-3.5" />
              <span>Limpiar todos los filtros</span>
            </button>
          )}

          {/* Info Trust Card */}
          <div className="p-4 bg-[#FAF7F0] rounded-xl border border-[#E8E2D9] text-xs text-stone-600 space-y-2">
            <div className="flex items-center gap-1.5 text-[#4A5D4E] font-semibold">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>Compromiso Perla & Pluma</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Cada pedido se envía con empaquetado en caja de regalo, ramitas de lavanda seca y una piedra consagrada de bienvenida.
            </p>
          </div>
        </aside>

        {/* Product listing & controls */}
        <div className="lg:col-span-3 space-y-6">
          {/* Top Bar Controls: Count, Search, Sort & Mobile Filter */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-[#FDFBF7] rounded-2xl border border-[#E8E2D9]">
            {/* Search Input */}
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Buscar por nombre, cristal, ingrediente..."
                className="w-full bg-[#FAF7F0] border border-[#DDD3C3] rounded-lg pl-9 pr-8 py-2 text-xs focus:outline-none focus:border-[#4A5D4E]"
              />
              {searchFilter && (
                <button
                  onClick={() => setSearchFilter("")}
                  className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center justify-between sm:justify-end gap-3">
              {/* Mobile filter toggle */}
              <button
                onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
                className="lg:hidden flex items-center gap-1.5 px-3 py-2 rounded-lg border border-[#DDD3C3] text-xs font-medium text-stone-700 bg-[#FAF7F0]"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Filtros</span>
              </button>

              {/* Sort by dropdown */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-stone-500 hidden sm:inline">Ordenar:</span>
                <select
                  value={sortBy}
                  onChange={(e: any) => setSortBy(e.target.value)}
                  className="bg-[#FAF7F0] border border-[#DDD3C3] rounded-lg px-2.5 py-2 text-xs text-stone-700 focus:outline-none"
                >
                  <option value="featured">Destacados del Altar</option>
                  <option value="price-asc">Precio: de menor a mayor</option>
                  <option value="price-desc">Precio: de mayor a menor</option>
                  <option value="rating">Mejor valorados ★</option>
                </select>
              </div>
            </div>
          </div>

          {/* Mobile Filter Sheet */}
          {mobileFilterOpen && (
            <div className="lg:hidden p-4 bg-[#FDFBF7] rounded-2xl border border-[#E8E2D9] space-y-4">
              <div className="flex items-center justify-between border-b pb-2">
                <span className="font-serif text-sm font-semibold">Filtros por Colección</span>
                <button onClick={() => setMobileFilterOpen(false)}>
                  <X className="w-4 h-4 text-stone-500" />
                </button>
              </div>

              <div className="space-y-1">
                <button
                  onClick={() => {
                    setCategoryFilter("all");
                    setSubcategoryFilter("all");
                    setMobileFilterOpen(false);
                  }}
                  className={`w-full text-left p-2 rounded-md text-xs ${
                    categoryFilter === "all" ? "bg-[#4A5D4E] text-white" : "hover:bg-stone-100"
                  }`}
                >
                  Todas las categorías
                </button>
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setCategoryFilter(cat.id);
                      setSubcategoryFilter("all");
                      setMobileFilterOpen(false);
                    }}
                    className={`w-full text-left p-2 rounded-md text-xs ${
                      categoryFilter === cat.id ? "bg-[#4A5D4E] text-white" : "hover:bg-stone-100"
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Results count & active tags */}
          <div className="flex items-center justify-between text-xs text-stone-500 px-1">
            <span>Mostrando {filteredProducts.length} piezas sagradas</span>
            {subcategoryFilter !== "all" && (
              <span className="bg-[#EAE3D6] text-[#4A5D4E] px-2 py-0.5 rounded-md font-medium">
                {subcategoryFilter}
              </span>
            )}
          </div>

          {/* Products Grid */}
          {loading ? (
            <div className="py-20 text-center space-y-3">
              <Sparkles className="w-8 h-8 text-[#D4AF37] animate-spin mx-auto" />
              <p className="text-xs text-stone-500 font-serif">Armonizando el catálogo sagrado...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="py-16 text-center space-y-4 bg-[#FAF7F0] rounded-2xl border border-[#E8E2D9] p-8">
              <Sparkles className="w-10 h-10 text-stone-400 mx-auto" />
              <h3 className="font-serif text-lg text-stone-800">
                No hemos encontrado piezas con estos filtros
              </h3>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                Prueba a seleccionar &quot;Todas las categorías&quot; o limpiar la búsqueda para ver todo lo disponible.
              </p>
              <button
                onClick={clearAllFilters}
                className="bg-[#4A5D4E] text-[#FDFBF7] text-xs font-medium px-4 py-2 rounded-lg hover:bg-[#3B4B3F]"
              >
                Restablecer filtros
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
