import Link from "next/link";
import Image from "next/image";
import { Sparkles, ArrowRight } from "lucide-react";
import { CATEGORIES } from "@/data/categories";
import { SectionOrnament, StarDivider, Sigil, type SigilName } from "@/components/decor/Ornaments";

const CATEGORY_SIGILS: SigilName[] = ["pentagrama", "triquetra", "flor", "estrella", "ojo"];

export function CategoryCardsSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
        <div>
          <SectionOrnament label="Colecciones sagradas" align="left" />
          <h2 className="font-serif text-3xl sm:text-4xl text-[#242B26] font-normal">
            Explora por Categoría
          </h2>
          <div className="flex items-center gap-2 mt-3">
            <span className="h-px w-10 bg-[#D8C79E]" />
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="h-px w-24 bg-linear-to-r from-[#D8C79E] to-transparent" />
          </div>
        </div>
        <p className="text-xs sm:text-sm text-[#5B675E] max-w-md">
          Cada elemento es seleccionado a mano por su pureza mineral, respeto a la botánica tradicional y vibración armónica.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {CATEGORIES.map((cat, index) => (
          <Link
            key={cat.id}
            href={`/catalogo?category=${cat.id}`}
            className={`group relative rounded-2xl overflow-hidden border border-[#E8E2D9] bg-[#FDFBF7] shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col ${
              index === 0 ? "lg:col-span-2 lg:flex-row" : ""
            }`}
          >
            <div
              className={`relative overflow-hidden bg-stone-200 ${
                index === 0 ? "lg:w-1/2 aspect-video lg:aspect-auto" : "aspect-4/3"
              }`}
            >
              <Image
                src={cat.bannerImage}
                alt={cat.name}
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-stone-900/10 group-hover:bg-transparent transition-colors" />
              <span className="absolute bottom-3 right-3 w-9 h-9 rounded-full bg-[#FDFBF7]/85 backdrop-blur-xs border border-white/60 flex items-center justify-center">
                <Sigil name={CATEGORY_SIGILS[index] ?? "flor"} size={20} />
              </span>
            </div>

            <div className={`p-6 flex flex-col justify-between ${index === 0 ? "lg:w-1/2 p-8" : ""}`}>
              <div>
                <span className="inline-flex items-center gap-1.5 text-[11px] font-sans font-semibold tracking-widest uppercase text-[#B08A2E] mb-2">
                  <span className="w-1 h-1 rounded-full bg-[#C9A24A]" />
                  Colección 0{index + 1}
                </span>
                <h3 className="font-serif text-xl sm:text-2xl text-[#242B26] group-hover:text-[#4A5D4E] transition-colors">
                  {cat.name}
                </h3>
                <p className="text-xs sm:text-sm text-[#5B675E] mt-2.5 leading-relaxed">
                  {cat.description}
                </p>

                <div className="mt-4 pt-3 border-t border-[#E8E2D9]/60">
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-stone-500 block mb-1">
                    Subcategorías destacadas:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {cat.subcategories.slice(0, 3).map((sub, sIdx) => (
                      <span
                        key={sIdx}
                        className="text-[11px] bg-[#F2ECE1] text-[#4A5D4E] px-2 py-0.5 rounded-md"
                      >
                        {sub}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-6 flex items-center gap-1.5 text-xs font-semibold text-[#4A5D4E] group-hover:text-[#242B26] transition-colors">
                <span>Explorar piezas</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
