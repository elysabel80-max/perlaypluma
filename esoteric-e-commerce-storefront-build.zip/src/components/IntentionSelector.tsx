"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Sparkles, Shield, Feather, Sun, Heart, Moon, ArrowRight, Check } from "lucide-react";
import { INTENTIONS } from "@/data/categories";
import { Mandala, SectionOrnament, Sigil, StarDivider, type SigilName } from "@/components/decor/Ornaments";

/**
 * Sección del deck: "¿Qué necesitas transformar o atraer hoy?" (Bloque B).
 * Cinco propósitos con iconografía serena + manifiesto en verde botánico.
 */
export function IntentionSelector() {
  const [selectedIntention, setSelectedIntention] = useState<string>("proteccion");
  const current = INTENTIONS[selectedIntention] || INTENTIONS.proteccion;

  const getIcon = (id: string) => {
    switch (id) {
      case "proteccion":
        return <Shield className="w-5 h-5" />;
      case "calma":
        return <Feather className="w-5 h-5" />;
      case "abundancia":
        return <Sun className="w-5 h-5" />;
      case "amor":
        return <Heart className="w-5 h-5" />;
      case "intuicion":
        return <Moon className="w-5 h-5" />;
      default:
        return <Sparkles className="w-5 h-5" />;
    }
  };

  return (
    <section id="intenciones" className="relative py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-[#F4EFE6] border-y border-[#E8E2D9] overflow-hidden">
      <Mandala size={780} opacity={0.13} className="pointer-events-none absolute -left-64 top-1/2 -translate-y-1/2 hidden md:block animate-spin-slower-rev" />
      <div className="relative max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <SectionOrnament label="Navegación por intención · Bloque B" />
          <h2 className="font-serif text-2xl sm:text-4xl lg:text-[2.6rem] text-[#242B26] font-normal leading-tight">
            ¿Qué necesitas transformar o atraer hoy?
          </h2>
          <StarDivider className="mt-5" />
          <p className="text-xs sm:text-sm text-[#5B675E] mt-3 leading-relaxed">
            No busques por categorías infinitas: elige cómo te sientes y te acompañamos hacia la
            herramienta sagrada afín a tu momento vital.
          </p>
        </div>

        {/* Five purpose cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4 mb-8">
          {Object.values(INTENTIONS).map((item) => {
            const isSelected = selectedIntention === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setSelectedIntention(item.id)}
                className={`group text-left rounded-2xl p-4 sm:p-5 border transition-all duration-300 flex flex-col gap-3 ${
                  isSelected
                    ? "bg-[#FDFBF7] border-[#4A5D4E] shadow-md -translate-y-0.5"
                    : "bg-[#FDFBF7]/80 border-[#E0D7C8] hover:border-[#C9BFAE] hover:shadow-sm"
                }`}
                aria-pressed={isSelected}
              >
                <div className="flex items-center justify-between">
                  <span className="relative flex items-center justify-center w-11 h-11">
                    <svg viewBox="0 0 44 44" className="absolute inset-0 w-full h-full" fill="none" aria-hidden="true">
                      <circle cx="22" cy="22" r="21" stroke="#C9A24A" strokeWidth="0.7" strokeDasharray="1 3" opacity="0.75" />
                      <circle cx="22" cy="22" r="17.5" stroke="#C9A24A" strokeWidth="0.6" opacity="0.5" />
                    </svg>
                    <span
                      className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                        isSelected ? "bg-[#4A5D4E] text-[#D4AF37]" : "bg-[#EFE9DD] text-[#4A5D4E]"
                      }`}
                    >
                      {getIcon(item.id)}
                    </span>
                  </span>
                  {isSelected && (
                    <span className="w-5 h-5 rounded-full bg-[#D4AF37] text-[#242B26] flex items-center justify-center">
                      <Check className="w-3 h-3" />
                    </span>
                  )}
                </div>

                <div>
                  <div className="font-serif text-sm font-semibold text-[#242B26] leading-snug">
                    {item.name.split("&")[0].trim()}
                  </div>
                  <div className="text-[10px] uppercase tracking-wider text-[#8A968D] mt-1 leading-snug">
                    {item.badge}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected intention detail */}
        <div className="bg-[#FDFBF7] rounded-3xl overflow-hidden border border-[#E0D7C8] shadow-sm grid grid-cols-1 md:grid-cols-12 items-stretch">
          <div className="md:col-span-5 relative aspect-4/3 md:aspect-auto min-h-[200px] bg-stone-200">
            <Image
              src={current.image}
              alt={current.name}
              fill
              sizes="(max-width: 768px) 100vw, 420px"
              className="object-cover"
            />
            <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-full text-[11px] font-serif font-semibold text-[#4A5D4E] flex items-center gap-1.5 shadow-xs">
              {getIcon(current.id)}
              <span>{current.badge}</span>
            </div>
          </div>

          <div className="md:col-span-7 p-6 sm:p-8 flex flex-col justify-center gap-3">
            <h3 className="font-serif text-xl sm:text-2xl text-[#242B26]">{current.name}</h3>
            <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">{current.description}</p>
            <p className="text-xs text-[#7A877E]">
              <span className="font-semibold text-[#242B26]">Elementos recomendados:</span>{" "}
              {current.recommendedElements}
            </p>
            <Link
              href={`/catalogo?intention=${current.id}`}
              className="inline-flex items-center justify-center gap-2 w-fit mt-1 bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] px-6 py-3 rounded-xl text-[11px] uppercase tracking-[0.15em] font-semibold transition-colors"
            >
              <span>Ver colección dedicada</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* Manifesto banner (deep botanical green) */}
        <div className="mt-6 rounded-2xl bg-[#4A5D4E] px-6 py-6 sm:px-8 sm:py-7 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <p className="text-xs sm:text-sm text-[#E8E2D9] leading-relaxed max-w-2xl">
            <span className="font-serif text-[#FDFBF7]">Cada pieza se limpia y se intenciona antes de salir de nuestro altar.</span>{" "}
            Envío en 24/48 h, empaquetado de regalo y guía ritual impresa en cada pedido.
          </p>
          <Link
            href="/nosotros"
            className="shrink-0 text-[11px] uppercase tracking-[0.15em] font-semibold text-[#242B26] bg-[#D4AF37] hover:bg-[#C29D2D] px-5 py-3 rounded-xl transition-colors"
          >
            Nuestro compromiso
          </Link>
        </div>
      </div>
    </section>
  );
}
