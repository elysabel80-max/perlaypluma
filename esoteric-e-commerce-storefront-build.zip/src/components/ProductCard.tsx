"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useCart } from "@/context/CartContext";
import { ShoppingBag, Star, Sparkles, Check, Heart, Shield, Feather, Sun, Moon } from "lucide-react";
import { OrnateFrame, Sigil } from "@/components/decor/Ornaments";

export interface ProductCardProps {
  product: {
    id: number;
    slug: string;
    name: string;
    subtitle: string;
    category: string;
    categoryName: string;
    subcategory: string;
    intention: string;
    price: string | number;
    originalPrice?: string | number | null;
    rating?: string | number | null;
    reviewsCount?: number | null;
    primaryImage: string;
    detailImage?: string;
    shortDescription: string;
    isBestseller?: boolean | null;
    isNewArrival?: boolean | null;
    ethicalCommitment?: string | null;
    mineralAuthenticity?: string | null;
  };
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const [isHovered, setIsHovered] = useState(false);
  const [added, setAdded] = useState(false);

  const numPrice = typeof product.price === "string" ? parseFloat(product.price) : product.price;
  const numOriginal = product.originalPrice
    ? typeof product.originalPrice === "string"
      ? parseFloat(product.originalPrice)
      : product.originalPrice
    : null;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(product, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  const getIntentionBadge = (intention: string) => {
    switch (intention) {
      case "proteccion":
        return { label: "Protección", icon: <Shield className="w-3 h-3 text-stone-700" />, bg: "bg-stone-100 text-stone-800" };
      case "calma":
        return { label: "Calma", icon: <Feather className="w-3 h-3 text-emerald-700" />, bg: "bg-emerald-50 text-emerald-900" };
      case "abundancia":
        return { label: "Abundancia", icon: <Sun className="w-3 h-3 text-amber-700" />, bg: "bg-amber-50 text-amber-900" };
      case "amor":
        return { label: "Amor Propio", icon: <Heart className="w-3 h-3 text-rose-700" />, bg: "bg-rose-50 text-rose-900" };
      case "intuicion":
        return { label: "Intuición", icon: <Moon className="w-3 h-3 text-violet-700" />, bg: "bg-violet-50 text-violet-900" };
      default:
        return { label: "Sagrado", icon: <Sparkles className="w-3 h-3 text-[#D4AF37]" />, bg: "bg-stone-100 text-stone-800" };
    }
  };

  const badge = getIntentionBadge(product.intention);

  return (
    <div
      className="group relative bg-[#FDFBF7] rounded-2xl overflow-hidden border border-[#E8E2D9] hover:border-[#D4AF37]/60 transition-all duration-300 hover:shadow-xl flex flex-col"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Top badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 items-start">
        {product.isBestseller && (
          <span className="bg-[#4A5D4E] text-[#FDFBF7] text-[10px] font-sans font-semibold tracking-wider uppercase px-2.5 py-1 rounded-full shadow-xs">
            Favorito
          </span>
        )}
        {product.isNewArrival && (
          <span className="bg-[#D4AF37] text-stone-900 text-[10px] font-sans font-semibold tracking-wider uppercase px-2.5 py-1 rounded-full shadow-xs">
            Novedad
          </span>
        )}
        <span
          className={`flex items-center gap-1 text-[10px] font-serif px-2.5 py-0.5 rounded-full border border-black/5 shadow-xs ${badge.bg}`}
        >
          {badge.icon}
          <span>{badge.label}</span>
        </span>
      </div>

      {/* Image container */}
      <Link href={`/producto/${product.slug}`} className="block relative aspect-square overflow-hidden bg-[#F2ECE1]">
        <Image
          src={isHovered && product.detailImage ? product.detailImage : product.primaryImage}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />

        {/* Sello geométrico */}
        <div className="pointer-events-none absolute top-3 right-3 z-10 opacity-70">
          <span className="w-7 h-7 rounded-full border border-[#FDFBF7]/70 bg-[#242B26]/25 backdrop-blur-xs flex items-center justify-center">
            <Sigil name="estrella" size={14} color="#F6ECD2" />
          </span>
        </div>

        {/* Quick Add Overlay */}
        <button
          onClick={handleAddToCart}
          className={`absolute bottom-3 right-3 z-20 pl-3 pr-3.5 py-2 rounded-full shadow-md transition-all duration-300 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider ${
            added
              ? "bg-emerald-700 text-white"
              : "bg-[#FDFBF7]/95 hover:bg-[#4A5D4E] text-[#2B352E] hover:text-[#FDFBF7] backdrop-blur-xs"
          }`}
          aria-label={`Añadir ${product.name} a la cesta`}
        >
          {added ? <Check className="w-3.5 h-3.5" /> : <ShoppingBag className="w-3.5 h-3.5" />}
          <span>{added ? "Añadido" : "Añadir"}</span>
        </button>
      </Link>

      {/* Product Details */}
      <div className="relative p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <span className="pointer-events-none absolute inset-x-4 top-0 h-px bg-linear-to-r from-transparent via-[#E0D3B9] to-transparent" aria-hidden="true" />
        <div>
          <div className="text-[11px] text-[#717E74] uppercase tracking-wider font-sans mb-1">
            {product.subcategory}
          </div>

          <Link href={`/producto/${product.slug}`} className="block group-hover:text-[#4A5D4E] transition-colors">
            <h3 className="font-serif text-base font-semibold text-[#242B26] leading-snug line-clamp-2">
              {product.name}
            </h3>
          </Link>

          <p className="text-xs text-[#5F6D63] mt-1.5 line-clamp-2 leading-relaxed">
            {product.subtitle}
          </p>
        </div>

        {/* Price & Rating */}
        <div className="mt-4 pt-3 border-t border-[#E8E2D9]/70 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="font-serif text-lg font-bold text-[#242B26]">
              {numPrice.toFixed(2)} €
            </span>
            {numOriginal && (
              <span className="text-xs text-stone-400 line-through">
                {numOriginal.toFixed(2)} €
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 text-xs text-[#2B352E]">
            <Star className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
            <span className="font-semibold">{product.rating || "4.9"}</span>
            <span className="text-[11px] text-stone-400">({product.reviewsCount || 24})</span>
          </div>
        </div>
      </div>
    </div>
  );
}
