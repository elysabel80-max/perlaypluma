"use client";

import React, { createContext, useContext, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  Sparkles,
  Check,
  X,
  Star,
  BookOpen,
  Gift,
  Percent,
  Moon,
  ArrowRight,
  ChevronDown,
  ShieldCheck,
  Mail,
  PartyPopper,
  Layers,
} from "lucide-react";
import { CLUB_PLANS, CLUB_GUIDES, CLUB_FAQ, COMPARISON_ROWS, type ClubPlan, type ClubGuide } from "@/data/club";
import { useMembership } from "@/context/MembershipContext";
import confetti from "canvas-confetti";

type ModalState =
  | { mode: "closed" }
  | { mode: "plan"; plan: ClubPlan }
  | { mode: "guide"; guide: ClubGuide };

interface ClubModalContextType {
  openPlan: (plan: ClubPlan) => void;
  openGuide: (guide: ClubGuide) => void;
}

const ClubModalContext = createContext<ClubModalContextType | undefined>(undefined);

function useClubModal() {
  const ctx = useContext(ClubModalContext);
  if (!ctx) throw new Error("useClubModal debe usarse dentro de ClubProvider");
  return ctx;
}

export function ClubProvider({ children }: { children: React.ReactNode }) {
  const [modal, setModal] = useState<ModalState>({ mode: "closed" });

  return (
    <ClubModalContext.Provider
      value={{
        openPlan: (plan) => setModal({ mode: "plan", plan }),
        openGuide: (guide) => setModal({ mode: "guide", guide }),
      }}
    >
      {children}
      {modal.mode !== "closed" && (
        <CheckoutModal state={modal} onClose={() => setModal({ mode: "closed" })} />
      )}
    </ClubModalContext.Provider>
  );
}

/* ------------------------------------------------------------------ */
/* Modal de alta / compra de guía                                      */
/* ------------------------------------------------------------------ */

function CheckoutModal({
  state,
  onClose,
}: {
  state: Exclude<ModalState, { mode: "closed" }>;
  onClose: () => void;
}) {
  const { activate } = useMembership();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState<null | { reference: string; discount?: string }>(null);
  const [error, setError] = useState("");

  const isPlan = state.mode === "plan";
  const title = isPlan ? state.plan.name : `Guía ${state.guide.number}`;
  const price = isPlan ? state.plan.price : state.guide.price;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes("@")) {
      setError("Introduce un correo electrónico válido.");
      return;
    }
    setSending(true);
    setError("");
    try {
      if (state.mode === "plan") {
        const res = await fetch("/api/subscriptions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, name, plan: state.plan.id }),
        });
        const data = await res.json();
        if (!res.ok || !data.success) throw new Error(data.message || "Error");
        activate(state.plan.id, email);
        setDone({
          reference: data.subscription?.reference ?? data.subscription?.id ?? "PP-CLUB",
          discount: state.plan.discount,
        });
      } else {
        const res = await fetch("/api/orders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            customerName: name || "Cliente Círculo de Luz",
            customerEmail: email,
            address: "Producto digital",
            city: "Digital",
            postalCode: "00000",
            items: [
              {
                id: 9000 + Number(state.guide.number),
                slug: state.guide.id,
                name: `Guía ${state.guide.number}: ${state.guide.title}`,
                subtitle: "Guía digital descargable",
                price: Number(state.guide.price.replace(",", ".")),
                quantity: 1,
                digital: true,
              },
            ],
            subtotal: state.guide.price.replace(",", "."),
            shipping: "0",
            total: state.guide.price.replace(",", "."),
            intentionNote: "Compra de guía digital",
          }),
        });
        const data = await res.json();
        if (!res.ok || !data.success) throw new Error(data.message || "Error");
        setDone({ reference: data.order?.orderNumber ?? "PP-GUIA" });
      }
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.65 },
          colors: ["#D4AF37", "#4A5D4E", "#FDFBF7"],
        });
      } catch {
        /* opcional */
      }
    } catch {
      setError("No hemos podido completar la operación. Inténtalo de nuevo.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-stone-900/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full sm:max-w-md bg-[#FDFBF7] rounded-t-3xl sm:rounded-3xl border border-[#E8E2D9] shadow-2xl p-6 sm:p-7 max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-stone-400 hover:text-stone-800 hover:bg-[#F2ECE1]"
          aria-label="Cerrar"
        >
          <X className="w-4 h-4" />
        </button>

        {done ? (
          <div className="text-center space-y-4 py-4">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto">
              <PartyPopper className="w-7 h-7" />
            </div>
            <h3 className="font-serif text-2xl text-[#242B26]">
              {isPlan ? "¡Bienvenida al Círculo de Luz!" : "¡Guía enviada!"}
            </h3>
            <p className="text-xs text-[#5B675E] leading-relaxed">
              {isPlan
                ? "Tu suscripción está activa. Hemos vinculado tu correo y el descuento ya se aplica automáticamente en tu bolsa de compra."
                : "Hemos registrado tu compra. En unos instantes recibirás el PDF y sus materiales complementarios en tu correo."}
            </p>
            <div className="p-3 rounded-xl bg-[#F4EFE6] border border-[#E0D7C8] text-xs text-stone-700 space-y-1">
              <p>
                <strong>Referencia:</strong> {done.reference}
              </p>
              <p>
                <strong>Correo:</strong> {email}
              </p>
              {done.discount && (
                <p>
                  <strong>Descuento activo:</strong> {done.discount} en toda la tienda
                </p>
              )}
            </div>
            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <Link
                href="/catalogo"
                onClick={onClose}
                className="flex-1 bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] py-2.5 rounded-lg text-xs font-medium text-center"
              >
                Ir a la tienda con mi descuento
              </Link>
              <button
                onClick={onClose}
                className="flex-1 border border-[#DDD3C3] py-2.5 rounded-lg text-xs font-medium text-stone-700 hover:bg-[#F2ECE1]"
              >
                Cerrar
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#EAE3D6] text-[10px] uppercase tracking-widest text-[#4A5D4E] font-semibold mb-3">
              <Sparkles className="w-3 h-3 text-[#D4AF37]" />
              <span>{isPlan ? "Alta de suscripción" : "Compra digital"}</span>
            </div>
            <h3 className="font-serif text-2xl text-[#242B26]">{title}</h3>
            <p className="text-xs text-[#5B675E] mt-1.5 leading-relaxed">
              {isPlan
                ? "Sin permanencia. Puedes cancelar en un clic cuando quieras."
                : "Pago único. Recibirás el material al terminar."}
            </p>

            <div className="flex items-baseline justify-between p-3.5 my-4 rounded-xl bg-[#F4EFE6] border border-[#E0D7C8]">
              <span className="text-[11px] uppercase tracking-wider text-[#6B786E]">
                {isPlan ? "Cuota mensual" : "Precio único"}
              </span>
              <span className="font-serif text-2xl font-bold text-[#242B26]">{price} €</span>
            </div>

            <form onSubmit={submit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-stone-700 mb-1">Nombre</label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Tu nombre"
                  className="w-full bg-[#F5EFE6] border border-[#D9D1C5] rounded-lg px-3 py-2.5 text-xs focus:outline-none focus:border-[#4A5D4E]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                  Correo electrónico *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="tu.correo@ejemplo.com"
                    className="w-full bg-[#F5EFE6] border border-[#D9D1C5] rounded-lg pl-9 pr-3 py-2.5 text-xs focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>
              </div>

              {error && <p className="text-[11px] text-rose-700">{error}</p>}

              <button
                type="submit"
                disabled={sending}
                className="w-full bg-[#D4AF37] hover:bg-[#C29D2D] text-[#242B26] py-3 rounded-xl text-xs uppercase tracking-[0.15em] font-semibold transition-colors disabled:opacity-60"
              >
                {sending
                  ? "Procesando..."
                  : isPlan
                    ? `Suscribirme por ${price} €/mes`
                    : `Comprar guía por ${price} €`}
              </button>
              <p className="text-[10px] text-center text-[#8A968D] leading-relaxed">
                Pago simulado en esta demostración: no se realizará ningún cargo.
              </p>
            </form>
          </>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Estado de membresía                                                 */
/* ------------------------------------------------------------------ */

export function ClubStatus() {
  const { isMember, planLabel, email, cancel } = useMembership();
  if (!isMember) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4">
        <div className="flex items-center gap-2.5">
          <ShieldCheck className="w-5 h-5 text-emerald-800" />
          <p className="text-xs text-emerald-900">
            <strong>Membresía activa: {planLabel}.</strong> Tu descuento se aplica solo en la cesta
            {email ? ` (${email})` : ""}.
          </p>
        </div>
        <button
          onClick={cancel}
          className="text-[11px] underline text-emerald-900 hover:text-emerald-950 self-start sm:self-auto"
        >
          Cancelar suscripción
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Planes                                                              */
/* ------------------------------------------------------------------ */

export function ClubPlans() {
  const { openPlan } = useClubModal();
  const { plan: activePlan } = useMembership();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
      {CLUB_PLANS.map((plan) => {
        const isActive = activePlan === plan.id;
        return (
          <div
            key={plan.id}
            className={`relative rounded-3xl border p-6 sm:p-8 flex flex-col gap-5 ${
              plan.highlight
                ? "bg-[#242B26] border-[#D4AF37]/60 text-[#E8E2D9] shadow-xl"
                : "bg-[#FDFBF7] border-[#E0D7C8] shadow-sm"
            }`}
          >
            {plan.highlight && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#D4AF37] text-[#242B26] text-[10px] uppercase tracking-[0.2em] font-bold px-3 py-1 rounded-full">
                Más elegido
              </span>
            )}

            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                {plan.id === "oro" ? (
                  <Moon className="w-4 h-4 text-[#D4AF37]" />
                ) : (
                  <Star className="w-4 h-4 text-[#D4AF37]" />
                )}
                <h3
                  className={`font-serif text-2xl ${
                    plan.highlight ? "text-[#FDFBF7]" : "text-[#242B26]"
                  }`}
                >
                  {plan.name}
                </h3>
              </div>
              <p
                className={`text-xs ${
                  plan.highlight ? "text-[#B5C2B7]" : "text-[#6B786E]"
                }`}
              >
                {plan.tagline}
              </p>
            </div>

            <div className="flex items-baseline gap-1.5">
              <span
                className={`font-serif text-4xl font-bold ${
                  plan.highlight ? "text-[#FDFBF7]" : "text-[#242B26]"
                }`}
              >
                {plan.price}
              </span>
              <span className={`text-xs ${plan.highlight ? "text-[#B5C2B7]" : "text-[#6B786E]"}`}>
                {plan.priceLabel}
              </span>
              <span
                className={`ml-auto text-[10px] uppercase tracking-wider px-2 py-1 rounded-full ${
                  plan.highlight
                    ? "bg-[#D4AF37]/20 text-[#E8CD82]"
                    : "bg-[#EFE9DD] text-[#4A5D4E]"
                }`}
              >
                {plan.discount}
              </span>
            </div>

            <p
              className={`text-[11px] leading-relaxed ${
                plan.highlight ? "text-[#B5C2B7]" : "text-[#5B675E]"
              }`}
            >
              {plan.audience}
            </p>

            <ul className="space-y-2.5 flex-1">
              {plan.benefits.map((benefit) => (
                <li key={benefit} className="flex items-start gap-2">
                  <Check
                    className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${
                      plan.highlight ? "text-[#D4AF37]" : "text-emerald-700"
                    }`}
                  />
                  <span
                    className={`text-[11px] leading-relaxed ${
                      plan.highlight ? "text-[#D7DFD8]" : "text-[#4E5B52]"
                    }`}
                  >
                    {benefit}
                  </span>
                </li>
              ))}
            </ul>

            <div className="space-y-2 pt-1">
              <button
                onClick={() => openPlan(plan)}
                className={`w-full py-3.5 rounded-xl text-[11px] uppercase tracking-[0.14em] font-semibold transition-colors ${
                  plan.highlight
                    ? "bg-[#D4AF37] hover:bg-[#C29D2D] text-[#242B26]"
                    : "bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7]"
                }`}
              >
                {isActive ? "Membresía activa · gestionar" : plan.cta}
              </button>
              <p
                className={`text-[10px] text-center ${
                  plan.highlight ? "text-[#8A968D]" : "text-[#8A968D]"
                }`}
              >
                {plan.note}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Tabla comparativa                                                   */
/* ------------------------------------------------------------------ */

export function ClubComparison() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Escritorio */}
      <div className="hidden md:block overflow-hidden rounded-2xl border border-[#E0D7C8] bg-[#FDFBF7] shadow-sm">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-[#F4EFE6] text-[#242B26]">
              <th className="px-5 py-4 font-serif text-sm font-semibold">Beneficios y ventajas</th>
              <th className="px-5 py-4 font-medium text-center">Usuario registrado</th>
              <th className="px-5 py-4 font-semibold text-center bg-[#EFE9DD]">
                🌟 Círculo Plata
              </th>
              <th className="px-5 py-4 font-semibold text-center bg-[#242B26] text-[#FDFBF7]">
                🌙 Círculo Oro VIP
              </th>
            </tr>
          </thead>
          <tbody>
            {COMPARISON_ROWS.map((row, index) => (
              <tr
                key={row.feature}
                className={index % 2 === 0 ? "bg-[#FDFBF7]" : "bg-[#FAF7F0]"}
              >
                <td className="px-5 py-3.5 font-medium text-[#3E4A41]">{row.feature}</td>
                <td className="px-5 py-3.5 text-center text-[#6B786E]">{row.registered}</td>
                <td className="px-5 py-3.5 text-center bg-[#EFE9DD]/60 text-[#3E4A41]">
                  {row.plata}
                </td>
                <td className="px-5 py-3.5 text-center bg-[#242B26]/5 font-medium text-[#242B26]">
                  {row.oro}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Móvil */}
      <div className="md:hidden space-y-3">
        {COMPARISON_ROWS.map((row) => (
          <div key={row.feature} className="rounded-2xl border border-[#E0D7C8] bg-[#FDFBF7] p-4">
            <p className="font-serif text-sm font-semibold text-[#242B26] mb-2.5">{row.feature}</p>
            <dl className="space-y-1.5 text-[11px]">
              <div className="flex justify-between gap-3">
                <dt className="text-[#8A968D]">Registrado</dt>
                <dd className="text-right text-[#4E5B52]">{row.registered}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-[#8A968D]">Plata</dt>
                <dd className="text-right text-[#4E5B52]">{row.plata}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-[#8A968D]">Oro VIP</dt>
                <dd className="text-right font-medium text-[#242B26]">{row.oro}</dd>
              </div>
            </dl>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Muestrario de guías                                                 */
/* ------------------------------------------------------------------ */

export function ClubGuides() {
  const { openGuide } = useClubModal();
  const [expanded, setExpanded] = useState<string | null>(CLUB_GUIDES[0].id);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {CLUB_GUIDES.map((guide) => {
        const isOpen = expanded === guide.id;
        return (
          <article
            key={guide.id}
            className="bg-[#FDFBF7] rounded-2xl border border-[#E8E2D9] overflow-hidden flex flex-col shadow-xs hover:shadow-lg transition-shadow"
          >
            <div className="relative aspect-16/10 bg-stone-200">
              <Image
                src={guide.image}
                alt={guide.title}
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-cover"
              />
              <span className="absolute top-3 left-3 bg-[#242B26]/85 backdrop-blur-xs text-[#FDFBF7] text-[10px] uppercase tracking-[0.2em] font-semibold px-2.5 py-1 rounded-full">
                Guía {guide.number}
              </span>
              <span className="absolute bottom-3 right-3 bg-[#FDFBF7]/95 text-[#242B26] text-[10px] font-semibold px-2.5 py-1 rounded-full">
                o {guide.price} €
              </span>
            </div>

            <div className="p-5 flex flex-col gap-3 flex-1">
              <h3 className="font-serif text-base font-semibold text-[#242B26] leading-snug">
                {guide.title}
              </h3>
              <p className="text-[11px] text-[#5B675E] leading-relaxed">{guide.description}</p>

              <button
                onClick={() => setExpanded(isOpen ? null : guide.id)}
                className="flex items-center justify-between text-[11px] font-semibold text-[#4A5D4E] py-2 border-y border-[#E8E2D9]"
                aria-expanded={isOpen}
              >
                <span className="flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5" />
                  Ver contenido de la guía
                </span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform ${isOpen ? "rotate-180" : ""}`}
                />
              </button>

              {isOpen && (
                <div className="space-y-2.5">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-[#8A968D] mb-1">
                      Lo que aprenderás
                    </p>
                    <ul className="space-y-1">
                      {guide.topics.map((topic) => (
                        <li key={topic} className="flex items-start gap-1.5 text-[11px] text-[#4E5B52]">
                          <Check className="w-3 h-3 text-emerald-700 mt-0.5 shrink-0" />
                          <span>{topic}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-[#8A968D] mb-1">
                      Incluye
                    </p>
                    <ul className="space-y-1">
                      {guide.includes.map((item) => (
                        <li key={item} className="flex items-start gap-1.5 text-[11px] text-[#4E5B52]">
                          <Layers className="w-3 h-3 text-[#D4AF37] mt-0.5 shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              <div className="mt-auto pt-2 space-y-2">
                <button
                  onClick={() => openGuide(guide)}
                  className="w-full bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] py-2.5 rounded-xl text-[10px] uppercase tracking-[0.12em] font-semibold transition-colors"
                >
                  Comprar por {guide.price} €
                </button>
                <p className="text-[10px] text-center text-[#8A968D]">
                  Incluida gratis en Plata y Oro VIP
                </p>
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* FAQ                                                                 */
/* ------------------------------------------------------------------ */

export function ClubFaq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="max-w-3xl mx-auto divide-y divide-[#E8E2D9] rounded-2xl border border-[#E0D7C8] bg-[#FDFBF7] overflow-hidden">
      {CLUB_FAQ.map((item, index) => {
        const isOpen = open === index;
        return (
          <div key={item.question}>
            <button
              onClick={() => setOpen(isOpen ? null : index)}
              className="w-full flex items-start justify-between gap-4 px-5 sm:px-6 py-4 text-left hover:bg-[#FAF7F0] transition-colors"
              aria-expanded={isOpen}
            >
              <span className="font-serif text-sm font-semibold text-[#242B26]">
                {item.question}
              </span>
              <ChevronDown
                className={`w-4 h-4 text-[#4A5D4E] shrink-0 mt-0.5 transition-transform ${
                  isOpen ? "rotate-180" : ""
                }`}
              />
            </button>
            {isOpen && (
              <div className="px-5 sm:px-6 pb-5 -mt-1">
                <p className="text-xs text-[#5B675E] leading-relaxed">{item.answer}</p>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* CTA de cierre                                                       */
/* ------------------------------------------------------------------ */

export function ClubClosing() {
  const { openPlan } = useClubModal();
  const plans = useMemo(() => CLUB_PLANS, []);

  return (
    <div className="rounded-3xl bg-[#242B26] px-6 py-10 sm:px-12 sm:py-14 text-center space-y-5">
      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#4A5D4E]/50 border border-[#5C7060] text-[10px] uppercase tracking-[0.22em] text-[#D4AF37] font-semibold">
        <Sparkles className="w-3 h-3" />
        <span>Último paso</span>
      </div>
      <h2 className="font-serif text-2xl sm:text-4xl text-[#FDFBF7] leading-tight max-w-2xl mx-auto">
        Tu espacio sagrado merece la mejor energía.
      </h2>
      <p className="text-xs sm:text-sm text-[#B5C2B7] max-w-xl mx-auto leading-relaxed">
        Da el paso hoy y transforma tu rutina diaria en un momento de conexión profunda.
      </p>
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
        {plans.map((plan) => (
          <button
            key={plan.id}
            onClick={() => openPlan(plan)}
            className={`w-full sm:w-auto px-6 py-3.5 rounded-xl text-[11px] uppercase tracking-[0.14em] font-semibold transition-colors flex items-center justify-center gap-2 ${
              plan.highlight
                ? "bg-[#D4AF37] hover:bg-[#C29D2D] text-[#242B26]"
                : "bg-[#FDFBF7] hover:bg-[#F2ECE1] text-[#242B26]"
            }`}
          >
            <Gift className="w-3.5 h-3.5" />
            <span>
              Unirme al {plan.name} · {plan.price} €/mes
            </span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        ))}
      </div>
      <p className="text-[10px] text-[#8A968D] flex items-center justify-center gap-2">
        <Percent className="w-3 h-3" />
        Descuento automático · Sin permanencia · Cancela en un clic
      </p>
    </div>
  );
}
