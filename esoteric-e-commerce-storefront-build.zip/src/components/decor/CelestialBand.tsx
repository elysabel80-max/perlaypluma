import React from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Sigil, MoonPhaseStrip, StarDivider, SacredBackdrop, type SigilName } from "@/components/decor/Ornaments";

const SYMBOLS: { name: SigilName; title: string; text: string }[] = [
  {
    name: "flor",
    title: "Flor de la Vida",
    text: "La matriz de la creación: 19 círculos que contienen toda forma geométrica del universo. Base de nuestros mandalas.",
  },
  {
    name: "sri",
    title: "Sri Yantra",
    text: "Nueve triángulos entrelazados que representan la unión de lo masculino y lo femenino. Geometría para meditar.",
  },
  {
    name: "pentagrama",
    title: "Pentagrama",
    text: "Los cinco elementos: tierra, agua, fuego, aire y espíritu. Símbolo de protección y de voluntad consciente.",
  },
  {
    name: "ojo",
    title: "Ojo de Horus",
    text: "Claridad, intuición y visión interior. Lo usamos como recordatorio de mirar más allá de lo evidente.",
  },
];

/**
 * Banda de geometría sagrada + ciclo lunar.
 * Aporta el carácter místico sin abandonar la paleta luminosa.
 */
export function CelestialBand() {
  return (
    <section className="relative overflow-hidden bg-[#F7F2E8] border-y border-[#E4DAC8] py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
      <SacredBackdrop variant="both" opacity={0.14} />

      <div className="relative max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="flex justify-center mb-4">
            <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#D8C79E] bg-[#FDFBF7]/70 backdrop-blur-xs text-[10px] uppercase tracking-[0.28em] text-[#8A6D28] font-semibold">
              Geometría sagrada
            </span>
          </div>
          <h2 className="font-serif text-2xl sm:text-4xl text-[#242B26] leading-tight">
            Símbolos que sostienen el ritual
          </h2>
          <StarDivider className="mt-5" />
          <p className="text-xs sm:text-sm text-[#5B675E] mt-4 leading-relaxed">
            Cada patrón tiene una intención: ordenar el caos, elevar la mirada y recordarte que
            formas parte de algo mayor. Los encontrarás grabados en nuestras piezas y en cada guía.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {SYMBOLS.map((symbol) => (
            <article
              key={symbol.title}
              className="group relative rounded-2xl border border-[#E0D3B9] bg-[#FDFBF7]/85 backdrop-blur-xs p-5 sm:p-6 text-center overflow-hidden hover:border-[#C9A24A]/70 transition-colors"
            >
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-[radial-gradient(circle_at_50%_0%,rgba(212,175,55,0.16),transparent_65%)]"
                aria-hidden="true"
              />
              <div className="relative flex justify-center mb-4">
                <span className="w-16 h-16 rounded-full border border-[#E0D3B9] bg-[#FAF6EC] flex items-center justify-center group-hover:animate-float-soft">
                  <Sigil name={symbol.name} size={38} />
                </span>
              </div>
              <h3 className="relative font-serif text-base font-semibold text-[#242B26]">
                {symbol.title}
              </h3>
              <p className="relative text-[11px] text-[#5B675E] leading-relaxed mt-2">
                {symbol.text}
              </p>
            </article>
          ))}
        </div>

        <div className="mt-12 rounded-3xl border border-[#D8C79E] bg-[#FDFBF7]/80 backdrop-blur-xs p-6 sm:p-8 flex flex-col lg:flex-row items-center gap-6 lg:gap-10">
          <div className="shrink-0">
            <MoonPhaseStrip size={22} label color="#4A5D4E" />
          </div>
          <div className="h-px w-full lg:h-14 lg:w-px bg-[#E0D3B9]" aria-hidden="true" />
          <div className="flex-1 text-center lg:text-left">
            <h3 className="font-serif text-lg sm:text-xl text-[#242B26]">
              Trabajamos con el calendario lunar
            </h3>
            <p className="text-[11px] sm:text-xs text-[#5B675E] leading-relaxed mt-1.5">
              Luna Nueva para sembrar intenciones, Cuarto Creciente para impulsar, Luna Llena para
              recargar minerales y Menguante para limpiar lo que ya no suma. Tu cuaderno ritual
              mensual incluye estas cuatro ventanas.
            </p>
          </div>
          <Link
            href="/circulo-de-luz"
            className="shrink-0 inline-flex items-center gap-2 bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] px-5 py-3 rounded-xl text-[10px] uppercase tracking-[0.16em] font-semibold transition-colors"
          >
            <span>Recibir el cuaderno lunar</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
