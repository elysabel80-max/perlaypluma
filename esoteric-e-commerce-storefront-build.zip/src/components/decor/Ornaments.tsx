import React from "react";

/* ------------------------------------------------------------------ */
/* Mandala                                                             */
/* ------------------------------------------------------------------ */

interface MandalaProps {
  size?: number;
  className?: string;
  opacity?: number;
  color?: string;
  strokeWidth?: number;
}

/** Mandala de 16 pétalos con anillos, hexagrama y constelación de puntos. */
export function Mandala({
  size = 560,
  className = "",
  opacity = 0.3,
  color = "#C9A24A",
  strokeWidth = 0.6,
}: MandalaProps) {
  const petals = Array.from({ length: 16 }, (_, i) => i * 22.5);
  const dots = Array.from({ length: 48 }, (_, i) => i * 7.5);
  const innerPetals = Array.from({ length: 8 }, (_, i) => i * 45);
  const seedCircles = Array.from({ length: 6 }, (_, i) => {
    const angle = (Math.PI / 3) * i;
    return { cx: 100 + Math.cos(angle) * 17, cy: 100 + Math.sin(angle) * 17 };
  });

  return (
    <svg
      viewBox="0 0 200 200"
      width={size}
      height={size}
      className={className}
      aria-hidden="true"
      fill="none"
    >
      <g stroke={color} strokeWidth={strokeWidth} opacity={opacity} strokeLinecap="round">
        <circle cx="100" cy="100" r="97" strokeDasharray="0.8 4.5" />
        <circle cx="100" cy="100" r="89" />
        <circle cx="100" cy="100" r="84" strokeDasharray="0.5 3.2" />
        <circle cx="100" cy="100" r="72" />

        {dots.map((angle, i) => (
          <circle
            key={`d-${angle}`}
            cx={100 + Math.cos((angle * Math.PI) / 180) * 93}
            cy={100 + Math.sin((angle * Math.PI) / 180) * 93}
            r={i % 4 === 0 ? 1.1 : 0.65}
            fill={color}
            stroke="none"
          />
        ))}

        {petals.map((angle) => (
          <ellipse
            key={`p-${angle}`}
            cx="100"
            cy="52"
            rx="11.5"
            ry="21"
            transform={`rotate(${angle} 100 100)`}
          />
        ))}

        <circle cx="100" cy="100" r="46" strokeDasharray="0.6 3" />
        <path d="M100 52 L141.6 124 L58.4 124 Z" />
        <path d="M100 148 L58.4 76 L141.6 76 Z" />

        {innerPetals.map((angle) => (
          <path
            key={`ip-${angle}`}
            d="M100 66 C108 76 108 90 100 100 C92 90 92 76 100 66 Z"
            transform={`rotate(${angle} 100 100)`}
          />
        ))}

        {seedCircles.map((c, i) => (
          <circle key={`s-${i}`} cx={c.cx} cy={c.cy} r="17" />
        ))}

        <circle cx="100" cy="100" r="7" />
        <circle cx="100" cy="100" r="1.8" fill={color} stroke="none" />
      </g>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Flor de la Vida                                                     */
/* ------------------------------------------------------------------ */

export function FlowerOfLife({
  size = 420,
  className = "",
  opacity = 0.28,
  color = "#C9A24A",
}: { size?: number; className?: string; opacity?: number; color?: string }) {
  const r = 20;
  const centers: { x: number; y: number }[] = [];
  const step = r * 1.5;
  const rowH = r * Math.sqrt(3);
  for (let row = -2; row <= 2; row++) {
    for (let col = -2; col <= 2; col++) {
      const x = 100 + col * step * 2 + (Math.abs(row) % 2 === 1 ? step : 0);
      const y = 100 + row * rowH;
      centers.push({ x, y });
    }
  }
  return (
    <svg viewBox="0 0 200 200" width={size} height={size} className={className} aria-hidden="true" fill="none">
      <g stroke={color} strokeWidth="0.55" opacity={opacity}>
        <circle cx="100" cy="100" r="94" />
        <circle cx="100" cy="100" r="88" strokeDasharray="0.7 3.4" />
        {centers.map((c, i) => (
          <circle key={i} cx={c.x} cy={c.y} r={r} />
        ))}
      </g>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Divisor ornamental                                                  */
/* ------------------------------------------------------------------ */

export function StarDivider({ className = "", color = "#C9A24A" }: { className?: string; color?: string }) {
  return (
    <div className={`flex items-center justify-center gap-3 ${className}`} aria-hidden="true">
      <span className="h-px w-14 sm:w-24 bg-linear-to-r from-transparent to-[#D8C79E]" />
      <svg viewBox="0 0 48 16" width="64" height="22" fill="none">
        <g stroke={color} strokeWidth="0.9" strokeLinecap="round">
          <path d="M24 1v14M17 8h14M19 3.5 29 12.5M29 3.5 19 12.5" opacity="0.75" />
          <circle cx="24" cy="8" r="2.1" fill={color} stroke="none" />
          <circle cx="9" cy="8" r="1.1" fill={color} stroke="none" opacity="0.7" />
          <circle cx="39" cy="8" r="1.1" fill={color} stroke="none" opacity="0.7" />
        </g>
      </svg>
      <span className="h-px w-14 sm:w-24 bg-linear-to-l from-transparent to-[#D8C79E]" />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Cabecera de sección con ornamento                                   */
/* ------------------------------------------------------------------ */

export function SectionOrnament({
  label,
  align = "center",
  tone = "green",
}: {
  label: string;
  align?: "center" | "left";
  tone?: "green" | "gold";
}) {
  const text = tone === "gold" ? "text-[#B08A2E]" : "text-[#4A5D4E]";
  return (
    <div
      className={`flex items-center gap-2.5 mb-3 ${
        align === "center" ? "justify-center" : "justify-start"
      }`}
    >
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" aria-hidden="true" className="shrink-0">
        <g stroke="#C9A24A" strokeWidth="1" strokeLinecap="round">
          <circle cx="12" cy="12" r="10.5" strokeDasharray="1 2.6" />
          <path d="M12 4.5 19.5 12 12 19.5 4.5 12Z" opacity="0.85" />
          <circle cx="12" cy="12" r="2.2" fill="#C9A24A" stroke="none" />
        </g>
      </svg>
      <span
        className={`text-[10px] sm:text-[11px] uppercase tracking-[0.28em] font-semibold ${text}`}
      >
        {label}
      </span>
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" aria-hidden="true" className="shrink-0">
        <g stroke="#C9A24A" strokeWidth="1" strokeLinecap="round">
          <circle cx="12" cy="12" r="10.5" strokeDasharray="1 2.6" />
          <path d="M12 4.5 19.5 12 12 19.5 4.5 12Z" opacity="0.85" />
          <circle cx="12" cy="12" r="2.2" fill="#C9A24A" stroke="none" />
        </g>
      </svg>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Fases lunares                                                       */
/* ------------------------------------------------------------------ */

const MOON_PATH = [0, 0.14, 0.32, 0.5, 0.5, 0.32, 0.14, 0];

/** Tira de 8 fases lunares. */
export function MoonPhaseStrip({
  size = 18,
  className = "",
  color = "#4A5D4E",
  label = false,
}: {
  size?: number;
  className?: string;
  color?: string;
  label?: boolean;
}) {
  return (
    <div className={`flex flex-col items-center gap-2 ${className}`}>
      <div className="flex items-center gap-1.5 sm:gap-2.5" aria-hidden="true">
        {MOON_PATH.map((phase, index) => {
          const r = 8;
          const maskId = `moon-${index}-${size}`;
          const offset = phase * 2 * r;
          const flip = index >= 4;
          return (
            <svg key={index} viewBox="0 0 20 20" width={size} height={size} fill="none">
              <defs>
                <mask id={maskId}>
                  <circle cx="10" cy="10" r={r} fill="white" />
                  <circle
                    cx="10"
                    cy="10"
                    r={r}
                    fill="black"
                    transform={`translate(${flip ? -offset : offset} 0)`}
                  />
                </mask>
              </defs>
              <circle cx="10" cy="10" r={r} stroke={color} strokeWidth="0.8" opacity="0.5" />
              <circle cx="10" cy="10" r={r} fill={color} mask={`url(#${maskId})`} opacity="0.85" />
            </svg>
          );
        })}
      </div>
      {label && (
        <span className="text-[9px] uppercase tracking-[0.3em] text-[#8A968D]">
          Ciclo lunar · 29,5 días
        </span>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Símbolos sagrados                                                   */
/* ------------------------------------------------------------------ */

export type SigilName = "flor" | "sri" | "estrella" | "ojo" | "pentagrama" | "triquetra";

/** Símbolos esotéricos de trazo fino para tarjetas y fichas. */
export function Sigil({
  name,
  size = 56,
  className = "",
  color = "#B08A2E",
}: {
  name: SigilName;
  size?: number;
  className?: string;
  color?: string;
}) {
  const common = {
    viewBox: "0 0 64 64",
    width: size,
    height: size,
    fill: "none" as const,
    className,
    "aria-hidden": true as const,
  };
  const stroke = { stroke: color, strokeWidth: 1, strokeLinecap: "round" as const };

  switch (name) {
    case "flor":
      return (
        <svg {...common}>
          <circle cx="32" cy="32" r="7" {...stroke} />
          {[0, 60, 120, 180, 240, 300].map((a) => (
            <circle
              key={a}
              cx={32 + Math.cos((a * Math.PI) / 180) * 7}
              cy={32 + Math.sin((a * Math.PI) / 180) * 7}
              r="7"
              {...stroke}
              opacity="0.8"
            />
          ))}
          <circle cx="32" cy="32" r="21" {...stroke} opacity="0.35" strokeDasharray="1 3" />
        </svg>
      );
    case "sri":
      return (
        <svg {...common}>
          <path d="M32 6 56 50H8Z" {...stroke} />
          <path d="M32 58 8 14h48Z" {...stroke} opacity="0.85" />
          <path d="M32 16 47 44H17Z" {...stroke} opacity="0.7" />
          <circle cx="32" cy="32" r="2.4" fill={color} stroke="none" />
        </svg>
      );
    case "estrella":
      return (
        <svg {...common}>
          <path d="M32 4 60 32 32 60 4 32Z" {...stroke} />
          <path d="M32 4 60 32 32 60 4 32Z" {...stroke} transform="rotate(45 32 32)" opacity="0.6" />
          <circle cx="32" cy="32" r="4.5" {...stroke} />
          <circle cx="32" cy="32" r="1.6" fill={color} stroke="none" />
        </svg>
      );
    case "ojo":
      return (
        <svg {...common}>
          <path d="M6 32c9-11 17-16 26-16s17 5 26 16c-9 11-17 16-26 16S15 43 6 32Z" {...stroke} />
          <circle cx="32" cy="32" r="8" {...stroke} />
          <circle cx="32" cy="32" r="3" fill={color} stroke="none" />
          <path d="M32 4v6M32 54v6M4 32h6M54 32h6" {...stroke} opacity="0.55" />
        </svg>
      );
    case "pentagrama":
      return (
        <svg {...common}>
          <circle cx="32" cy="32" r="26" {...stroke} opacity="0.45" />
          <path d="M32 8 46.6 52.8 8.8 25.2h46.4L17.4 52.8Z" {...stroke} />
        </svg>
      );
    case "triquetra":
    default:
      return (
        <svg {...common}>
          <circle cx="32" cy="24" r="12" {...stroke} />
          <circle cx="24" cy="40" r="12" {...stroke} />
          <circle cx="40" cy="40" r="12" {...stroke} />
        </svg>
      );
  }
}

/* ------------------------------------------------------------------ */
/* Fondo de geometría sagrada                                          */
/* ------------------------------------------------------------------ */

export function SacredBackdrop({
  variant = "mandala",
  className = "",
  opacity = 0.16,
}: {
  variant?: "mandala" | "flor" | "both";
  className?: string;
  opacity?: number;
}) {
  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`} aria-hidden="true">
      {variant !== "flor" && (
        <Mandala
          size={880}
          opacity={opacity}
          className="absolute -right-56 -top-56 animate-spin-slower"
          color="#C9A24A"
        />
      )}
      {variant !== "mandala" && (
        <FlowerOfLife
          size={620}
          opacity={opacity + 0.04}
          className="absolute -left-40 -bottom-48 animate-spin-slower-rev"
          color="#8C9A8F"
        />
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Esquinas ornamentales                                               */
/* ------------------------------------------------------------------ */

export function OrnateFrame({ className = "" }: { className?: string }) {
  return (
    <>
      <svg
        viewBox="0 0 60 60"
        className={`pointer-events-none absolute w-8 h-8 sm:w-10 sm:h-10 text-[#C9A24A]/60 ${className} left-2 top-2`}
        fill="none"
        aria-hidden="true"
      >
        <path d="M2 30V8A6 6 0 0 1 8 2h22" stroke="currentColor" strokeWidth="1.1" />
        <path d="M2 18C10 18 16 12 16 4" stroke="currentColor" strokeWidth="0.8" opacity="0.7" />
        <circle cx="8" cy="8" r="1.6" fill="currentColor" />
      </svg>
      <svg
        viewBox="0 0 60 60"
        className={`pointer-events-none absolute w-8 h-8 sm:w-10 sm:h-10 text-[#C9A24A]/60 ${className} right-2 top-2 rotate-90`}
        fill="none"
        aria-hidden="true"
      >
        <path d="M2 30V8A6 6 0 0 1 8 2h22" stroke="currentColor" strokeWidth="1.1" />
        <path d="M2 18C10 18 16 12 16 4" stroke="currentColor" strokeWidth="0.8" opacity="0.7" />
        <circle cx="8" cy="8" r="1.6" fill="currentColor" />
      </svg>
      <svg
        viewBox="0 0 60 60"
        className={`pointer-events-none absolute w-8 h-8 sm:w-10 sm:h-10 text-[#C9A24A]/60 ${className} left-2 bottom-2 -rotate-90`}
        fill="none"
        aria-hidden="true"
      >
        <path d="M2 30V8A6 6 0 0 1 8 2h22" stroke="currentColor" strokeWidth="1.1" />
        <path d="M2 18C10 18 16 12 16 4" stroke="currentColor" strokeWidth="0.8" opacity="0.7" />
        <circle cx="8" cy="8" r="1.6" fill="currentColor" />
      </svg>
      <svg
        viewBox="0 0 60 60"
        className={`pointer-events-none absolute w-8 h-8 sm:w-10 sm:h-10 text-[#C9A24A]/60 ${className} right-2 bottom-2 rotate-180`}
        fill="none"
        aria-hidden="true"
      >
        <path d="M2 30V8A6 6 0 0 1 8 2h22" stroke="currentColor" strokeWidth="1.1" />
        <path d="M2 18C10 18 16 12 16 4" stroke="currentColor" strokeWidth="0.8" opacity="0.7" />
        <circle cx="8" cy="8" r="1.6" fill="currentColor" />
      </svg>
    </>
  );
}
