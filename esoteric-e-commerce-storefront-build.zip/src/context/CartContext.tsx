"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import {
  FREE_SHIPPING_THRESHOLD,
  GIFT_PACKAGING_COST,
  SHIPPING_COST,
} from "@/lib/shipping";
import { useMembership } from "@/context/MembershipContext";

export interface CartItem {
  id: number;
  slug: string;
  name: string;
  subtitle: string;
  categoryName: string;
  price: number;
  image: string;
  quantity: number;
  intention?: string;
}

interface CartContextType {
  items: CartItem[];
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  addItem: (product: {
    id: number;
    slug: string;
    name: string;
    subtitle: string;
    categoryName: string;
    price: string | number;
    primaryImage: string;
    intention?: string;
  }, quantity?: number) => void;
  removeItem: (id: number) => void;
  updateQuantity: (id: number, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  subtotal: number;
  memberDiscount: number;
  memberPlanLabel: string;
  shipping: number;
  total: number;
  giftPackaging: boolean;
  setGiftPackaging: (val: boolean) => void;
  intentionNote: string;
  setIntentionNote: (note: string) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_STORAGE_KEY = "perla_pluma_cart_v1";

export function CartProvider({ children }: { children: React.ReactNode }) {
  const { discountRate, planLabel } = useMembership();
  const [items, setItems] = useState<CartItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [giftPackaging, setGiftPackaging] = useState(false);
  const [intentionNote, setIntentionNote] = useState("");
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed.items)) setItems(parsed.items);
        if (typeof parsed.giftPackaging === "boolean") setGiftPackaging(parsed.giftPackaging);
        if (typeof parsed.intentionNote === "string") setIntentionNote(parsed.intentionNote);
      }
    } catch (e) {
      console.warn("Could not load cart from localStorage", e);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    if (!isLoaded) return;
    try {
      localStorage.setItem(
        CART_STORAGE_KEY,
        JSON.stringify({
          items,
          giftPackaging,
          intentionNote,
        })
      );
    } catch (e) {
      console.warn("Could not save cart to localStorage", e);
    }
  }, [items, giftPackaging, intentionNote, isLoaded]);

  const openCart = () => setIsOpen(true);
  const closeCart = () => setIsOpen(false);
  const toggleCart = () => setIsOpen((prev) => !prev);

  const addItem = (
    product: {
      id: number;
      slug: string;
      name: string;
      subtitle: string;
      categoryName: string;
      price: string | number;
      primaryImage: string;
      intention?: string;
    },
    quantity: number = 1
  ) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.id === product.id);
      const numPrice = typeof product.price === "string" ? parseFloat(product.price) : product.price;

      if (existing) {
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        return [
          ...prev,
          {
            id: product.id,
            slug: product.slug,
            name: product.name,
            subtitle: product.subtitle,
            categoryName: product.categoryName,
            price: numPrice,
            image: product.primaryImage,
            quantity,
            intention: product.intention,
          },
        ];
      }
    });
    setIsOpen(true);
  };

  const removeItem = (id: number) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const updateQuantity = (id: number, quantity: number) => {
    if (quantity <= 0) {
      removeItem(id);
      return;
    }
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, quantity } : i))
    );
  };

  const clearCart = () => {
    setItems([]);
    setIntentionNote("");
    setGiftPackaging(false);
  };

  const totalItems = items.reduce((acc, curr) => acc + curr.quantity, 0);
  const subtotal = items.reduce((acc, curr) => acc + curr.price * curr.quantity, 0);
  // Descuento automático del Círculo de Luz (5% Plata / 10% Oro VIP)
  const memberDiscount = Math.round(subtotal * discountRate * 100) / 100;
  const discountedSubtotal = subtotal - memberDiscount;
  // Envío gratuito a partir del umbral configurado en lib/shipping.ts
  const shipping =
    discountedSubtotal >= FREE_SHIPPING_THRESHOLD || discountedSubtotal === 0
      ? 0
      : SHIPPING_COST;
  const giftPackagingCost = giftPackaging ? GIFT_PACKAGING_COST : 0;
  const total = discountedSubtotal + shipping + giftPackagingCost;

  return (
    <CartContext.Provider
      value={{
        items,
        isOpen,
        openCart,
        closeCart,
        toggleCart,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        totalItems,
        subtotal,
        memberDiscount,
        memberPlanLabel: planLabel,
        shipping,
        total,
        giftPackaging,
        setGiftPackaging,
        intentionNote,
        setIntentionNote,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return ctx;
}
