"use client";

import React, { createContext, useContext, useEffect, useState } from "react";

export type MembershipPlan = "none" | "plata" | "oro";

export interface MembershipState {
  plan: MembershipPlan;
  email: string;
  since: string | null;
}

interface MembershipContextType extends MembershipState {
  isMember: boolean;
  discountRate: number;
  planLabel: string;
  activate: (plan: Exclude<MembershipPlan, "none">, email: string) => void;
  cancel: () => void;
}

const MembershipContext = createContext<MembershipContextType | undefined>(undefined);

const STORAGE_KEY = "perla_pluma_membership_v1";

export const MEMBERSHIP_DISCOUNTS: Record<MembershipPlan, number> = {
  none: 0,
  plata: 0.05,
  oro: 0.1,
};

export const MEMBERSHIP_LABELS: Record<MembershipPlan, string> = {
  none: "Sin suscripción",
  plata: "Círculo Plata",
  oro: "Círculo Oro VIP",
};

export function MembershipProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<MembershipState>({ plan: "none", email: "", since: null });
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as MembershipState;
        if (parsed.plan === "plata" || parsed.plan === "oro" || parsed.plan === "none") {
          setState({
            plan: parsed.plan,
            email: parsed.email ?? "",
            since: parsed.since ?? null,
          });
        }
      }
    } catch {
      /* localStorage puede estar deshabilitado */
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* silencioso */
    }
  }, [state, loaded]);

  const activate = (plan: Exclude<MembershipPlan, "none">, email: string) => {
    setState({ plan, email, since: new Date().toISOString() });
  };

  const cancel = () => setState({ plan: "none", email: "", since: null });

  return (
    <MembershipContext.Provider
      value={{
        ...state,
        isMember: state.plan !== "none",
        discountRate: MEMBERSHIP_DISCOUNTS[state.plan],
        planLabel: MEMBERSHIP_LABELS[state.plan],
        activate,
        cancel,
      }}
    >
      {children}
    </MembershipContext.Provider>
  );
}

export function useMembership() {
  const ctx = useContext(MembershipContext);
  if (!ctx) throw new Error("useMembership debe usarse dentro de MembershipProvider");
  return ctx;
}
