export interface CategoryInfo {
  id: string;
  name: string;
  slug: string;
  description: string;
  subcategories: string[];
  bannerImage: string;
}

export interface IntentionInfo {
  id: string;
  name: string;
  badge: string;
  description: string;
  iconName: "Shield" | "Feather" | "Sun" | "Heart" | "Moon";
  colorBg: string;
  colorBorder: string;
  colorText: string;
  recommendedElements: string;
  image: string;
}

export const CATEGORIES: CategoryInfo[] = [
  {
    id: "velas-velones",
    slug: "velas-velones",
    name: "Velas & Velones",
    description: "Cera pura de abeja, soja vegetal y velones ritualizados ungidos artesanalmente para guiar y transmutar tus intenciones.",
    bannerImage: "https://images.pexels.com/photos/30235380/pexels-photo-30235380.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    subcategories: [
      "Velas de Miel Natural",
      "Velones de Propósito y Ritualizados",
      "Velas Aromáticas con Cristales",
      "Velas de Colores y Formas",
    ],
  },
  {
    id: "inciensos-aromaterapia",
    slug: "inciensos-aromaterapia",
    name: "Inciensos & Aromaterapia",
    description: "Varillas masala naturales, conos de cascada, atados de salvia blanca silvestre, palo santo ético y brumas áuricas artesanales.",
    bannerImage: "https://images.pexels.com/photos/17840021/pexels-photo-17840021.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    subcategories: [
      "Inciensos Naturales & Varillas Masala",
      "Conos & Conos de Reflujo",
      "Palo Santo & Atados de Salvia",
      "Defumación Activada & Resinas",
      "Sprays Áuricos & Aguas Floridas",
    ],
  },
  {
    id: "cuarzos-minerales",
    slug: "cuarzos-minerales",
    name: "Cuarzos & Minerales",
    description: "Minerales 100% auténticos y seleccionados éticamente. Cantos rodados, drusas vivas, selenita pura y joyería en Plata de Ley 925.",
    bannerImage: "https://images.pexels.com/photos/38684711/pexels-photo-38684711.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    subcategories: [
      "Cantos Rodados (Piedras Pulidas)",
      "Minerales en Bruto & Drusas",
      "Placas y Cuencos de Selenita",
      "Joyería en Minerales (Plata 925)",
    ],
  },
  {
    id: "kits-rituales",
    slug: "kits-rituales",
    name: "Kits & Rituales",
    description: "Cajas ritualizadas listas para regalar o emprender. Con todos los elementos purificados y su guía explicada paso a paso.",
    bannerImage: "https://images.pexels.com/photos/38684710/pexels-photo-38684710.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    subcategories: [
      "Kit de Limpieza Energética",
      "Kit de Abundancia & Prosperidad",
      "Kit de Protección Energética",
      "Kit de Amor Propio & Calma",
    ],
  },
  {
    id: "herramientas-misticas",
    slug: "herramientas-misticas",
    name: "Herramientas Místicas & Adivinación",
    description: "Barajas de tarot consagradas, péndulos de radiestesia en gemas nobles, cuencos tibetanos y paños sagrados para tu altar personal.",
    bannerImage: "https://images.pexels.com/photos/30828554/pexels-photo-30828554.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    subcategories: [
      "Tarot & Oráculos",
      "Péndulos de Radiestesia",
      "Sonido Sagrado & Meditación",
      "Accesorios de Altar & Calderos",
    ],
  },
];

export const INTENTIONS: Record<string, IntentionInfo> = {
  proteccion: {
    id: "proteccion",
    name: "Protección & Limpieza Energética",
    badge: "Escudo & Purificación",
    description: "Aleja cargas densas, sella tu hogar y transmuta cualquier vibración pesada en luz serena.",
    iconName: "Shield",
    colorBg: "bg-stone-100",
    colorBorder: "border-stone-300",
    colorText: "text-stone-800",
    recommendedElements: "Turmalina Negra, Salvia Blanca, Palo Santo, Velón de Corte San Benito",
    image: "https://images.pexels.com/photos/8436503/pexels-photo-8436503.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
  calma: {
    id: "calma",
    name: "Calma, Estrés & Ansiedad",
    badge: "Paz Mental & Sosiego",
    description: "Regula tus pulsaciones, armoniza tu espacio de descanso e invita a un estado de meditación profunda.",
    iconName: "Feather",
    colorBg: "bg-emerald-50",
    colorBorder: "border-emerald-200",
    colorText: "text-emerald-900",
    recommendedElements: "Amatista Natural, Lavanda, Incienso de Sándalo, Vela de Soja con Cristales",
    image: "https://images.pexels.com/photos/30235380/pexels-photo-30235380.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
  abundancia: {
    id: "abundancia",
    name: "Abundancia & Prosperidad",
    badge: "Abrecaminos & Éxito",
    description: "Atrae el flujo continuo de merecimiento, nuevos proyectos, prosperidad económica y claridad financiera.",
    iconName: "Sun",
    colorBg: "bg-amber-50",
    colorBorder: "border-amber-200",
    colorText: "text-amber-900",
    recommendedElements: "Pirita Dorada, Citrino Natural, Canela, Velón Abrecaminos Ungido",
    image: "https://images.pexels.com/photos/709622/pexels-photo-709622.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
  amor: {
    id: "amor",
    name: "Amor Propio & Relaciones",
    badge: "Apertura Cardíaca & Dulzura",
    description: "Nutre la ternura interna, sana vínculos afectivos, atrae vínculos armónicos y endulza la convivencia.",
    iconName: "Heart",
    colorBg: "bg-rose-50",
    colorBorder: "border-rose-200",
    colorText: "text-rose-900",
    recommendedElements: "Cuarzo Rosa de Madagascar, Velas de Miel 100%, Bruma Floral de Rosa Damascena",
    image: "https://images.pexels.com/photos/35901650/pexels-photo-35901650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
  intuicion: {
    id: "intuicion",
    name: "Intuición & Conexión Espiritual",
    badge: "Tercer Ojo & Conciencia",
    description: "Agudiza tu voz interior, facilita la lectura oracular, la canalización y la conexión con tus guías.",
    iconName: "Moon",
    colorBg: "bg-violet-50",
    colorBorder: "border-violet-200",
    colorText: "text-violet-900",
    recommendedElements: "Selenita Marroquí, Péndulo de Amatista, Baraja Rider-Waite, Cuenco Cantor Tibetano",
    image: "https://images.pexels.com/photos/30828554/pexels-photo-30828554.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
};
