export interface ClubPlan {
  id: "plata" | "oro";
  name: string;
  tagline: string;
  price: string;
  priceLabel: string;
  discount: string;
  audience: string;
  benefits: string[];
  cta: string;
  highlight: boolean;
  note: string;
}

export const CLUB_PLANS: ClubPlan[] = [
  {
    id: "plata",
    name: "Círculo Plata",
    tagline: "La puerta al aprendizaje místico",
    price: "4,99",
    priceLabel: "€ / mes",
    discount: "5% DTO",
    audience:
      "Para quienes buscan aprender a su ritmo, resolver dudas prácticas sobre rituales y beneficiarse de descuentos recurrentes al renovar sus inciensos, velas y minerales.",
    benefits: [
      "Biblioteca digital ilimitada: todas las guías en PDF y artículos del club.",
      "5% de descuento permanente y acumulable en toda la tienda.",
      "Ritual Lunar mensual descargable para Luna Nueva y Luna Llena.",
      "Informe de bienvenida personalizado según tu signo zodiacal.",
      "Comunidad privada, boletines y tiradas colectivas mensuales.",
    ],
    cta: "Suscribirme al Círculo Plata por 4,99€/mes",
    highlight: false,
    note: "Servicio 100% digital · sin permanencia · cancela en un clic",
  },
  {
    id: "oro",
    name: "Círculo Oro VIP",
    tagline: "La experiencia sagrada completa",
    price: "12,99",
    priceLabel: "€ / mes",
    discount: "10% DTO",
    audience:
      "Para compradoras habituales y practicantes que desean el máximo ahorro, detalles físicos en cada paquete y atención personalizada en su fecha especial.",
    benefits: [
      "Todo lo incluido en el Círculo Plata, sin límites.",
      "10% de descuento permanente en todo el catálogo.",
      "Obsequio de alta vibración en CADA pedido físico, sin importe mínimo.",
      "Mini-estudio astrológico anual en el mes de tu cumpleaños.",
      "Acceso anticipado 48 h a piezas únicas, geodas y ediciones limitadas.",
    ],
    cta: "Suscribirme al Círculo Oro VIP por 12,99€/mes",
    highlight: true,
    note: "Incluye regalo físico en cada pedido · cancela en un clic",
  },
];

export const COMPARISON_ROWS: {
  feature: string;
  registered: string;
  plata: string;
  oro: string;
}[] = [
  { feature: "Cuota mensual", registered: "0,00 €", plata: "4,99 € / mes", oro: "12,99 € / mes" },
  { feature: "Blog público y #BrujiTips", registered: "✅ Incluido", plata: "✅ Incluido", oro: "✅ Incluido" },
  {
    feature: "Guías exclusivas en PDF",
    registered: "A la carta (1,99 € – 2,99 €)",
    plata: "Ilimitado (gratis)",
    oro: "Ilimitado (gratis)",
  },
  { feature: "Descuento permanente en tienda", registered: "0%", plata: "5% DTO", oro: "10% DTO" },
  {
    feature: "Regalo físico en compras online",
    registered: "Solo compras > 50 €",
    plata: "Solo compras > 50 €",
    oro: "En CADA pedido (sin mínimo)",
  },
  {
    feature: "Estudio astrológico anual",
    registered: "No disponible",
    plata: "Informe base digital",
    oro: "Mini-análisis de cumpleaños",
  },
  {
    feature: "Venta privada y acceso anticipado",
    registered: "No",
    plata: "No",
    oro: "48 horas antes",
  },
  { feature: "Compromiso / permanencia", registered: "Sin compromiso", plata: "Cancela cuando quieras", oro: "Cancela cuando quieras" },
];

export interface ClubGuide {
  id: string;
  number: string;
  title: string;
  description: string;
  price: string;
  topics: string[];
  includes: string[];
  image: string;
}

export const CLUB_GUIDES: ClubGuide[] = [
  {
    id: "limpieza-vehiculo",
    number: "01",
    title: "Limpieza energética para tu vehículo y desplazamientos",
    description:
      "Tutorial práctico para purificar la vibración del coche tras viajes intensos o situaciones de estrés. Incluye el uso de atados de salvia blanca, rociado de Agua de Florida en alfombrillas y la colocación correcta de la turmalina negra en el salpicadero.",
    price: "1,99",
    topics: [
      "Preparación del espacio y apertura del ritual",
      "Sahumado de salvia blanca, orden y recorrido",
      "Agua de Florida: proporción y puntos de rociado",
      "Turmalina negra en el salpicadero: anclaje y recarga",
    ],
    includes: ["PDF ilustrado de 14 páginas", "Checklist imprimible de viaje", "Audio guiado de 6 minutos"],
    image:
      "https://images.pexels.com/photos/38684713/pexels-photo-38684713.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
  {
    id: "purificacion-hogar",
    number: "02",
    title: "Protocolo completo de purificación del hogar",
    description:
      "Guía paso a paso para una limpieza profunda en espacios habitados. Enseña el orden de sahumado ventana por ventana, el uso del palo santo para armonizar y la activación de velas de corte.",
    price: "2,99",
    topics: [
      "Diagnóstico previo: cómo percibir un espacio cargado",
      "Sahumado ventana por ventana y barrido de esquinas",
      "Palo santo: armonización posterior al desalojo",
      "Velas de corte: intención, encendido y lectura",
    ],
    includes: ["PDF de 22 páginas con planos de recorrido", "Calendario de limpiezas por estación", "Plantilla de intención"],
    image:
      "https://images.pexels.com/photos/6766575/pexels-photo-6766575.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
  {
    id: "lectura-llama",
    number: "03",
    title: "Manual de lectura de la llama y la cera de las velas",
    description:
      "Breviario ilustrado (#BrujiTip) para interpretar el movimiento de la llama, las chispas, el humo y las formas que adopta la cera al derretirse en un velón de propósito.",
    price: "1,99",
    topics: [
      "Anatomía de la llama: altura, color y estabilidad",
      "Chispas, crepitar y humo: mensajes frecuentes",
      "Formas de cera: caminos, lágrimas y espejos",
      "Cuándo repetir un ritual y cuándo esperar al ciclo lunar",
    ],
    includes: ["PDF ilustrado de 18 páginas", "Tabla de interpretación rápida", "Ficha de registro de tus velas"],
    image:
      "https://images.pexels.com/photos/30235380/pexels-photo-30235380.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
];

export const CLUB_FAQ: { question: string; answer: string }[] = [
  {
    question: "¿Cómo aplico mi descuento del club en la tienda online?",
    answer:
      "Al suscribirte, tu cuenta de correo queda vinculada a tu plan y el descuento se aplica automáticamente en tu bolsa de compra: 5% en el Círculo Plata y 10% en el Círculo Oro VIP, sin códigos ni mínimos.",
  },
  {
    question: "¿Hay algún compromiso de permanencia?",
    answer:
      "Ninguno. Puedes cambiar de plan o darte de baja en cualquier momento desde tu panel de cliente con un solo clic, sin llamadas ni formularios.",
  },
  {
    question: "¿Cómo funcionan los regalos físicos del Círculo Oro VIP?",
    answer:
      "Cada vez que realices una compra de productos físicos añadiremos automáticamente a tu paquete un detalle energético preparado con mimo (mineral rodado, mini-vela de cera pura o amuleto de protección), sin importar el importe de tu carrito.",
  },
  {
    question: "¿Qué ocurre si solo quiero una guía puntual sin suscribirme?",
    answer:
      "Puedes comprar cualquiera de nuestras guías en formato digital con un pago único de 1,99 € a 2,99 € desde esta misma página. Recibirás el PDF y sus materiales complementarios en tu correo al instante.",
  },
];
