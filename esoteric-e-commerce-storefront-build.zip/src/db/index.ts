import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

type Database = NodePgDatabase<Record<string, never>>;

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
  __arenaNextJsPostgresqlClient?: Database;
};

/**
 * The storefront is designed to boot even when no database is configured
 * (for example on a static/shared host). In that case every data helper
 * gracefully falls back to the curated demo catalogue.
 */
export function hasDatabaseUrl(): boolean {
  return Boolean(process.env.DATABASE_URL);
}

export function getDb(): Database | null {
  if (!process.env.DATABASE_URL) return null;
  if (globalForDb.__arenaNextJsPostgresqlClient) {
    return globalForDb.__arenaNextJsPostgresqlClient;
  }

  const pool =
    globalForDb.__arenaNextJsPostgresqlPool ??
    new Pool({
      connectionString: process.env.DATABASE_URL,
      connectionTimeoutMillis: 8000,
      idleTimeoutMillis: 30000,
      max: 5,
    });

  if (process.env.NODE_ENV !== "production") {
    globalForDb.__arenaNextJsPostgresqlPool = pool;
  }

  const client = drizzle(pool);
  globalForDb.__arenaNextJsPostgresqlClient = client;
  return client;
}

/**
 * Lazy proxy so importing `db` never throws at module-evaluation time,
 * which previously broke `next build` on hosts without DATABASE_URL.
 */
export const db = new Proxy({} as Database, {
  get(_target, property) {
    const client = getDb();
    if (!client) {
      throw new Error("DATABASE_UNAVAILABLE");
    }
    const value = (client as unknown as Record<string | symbol, unknown>)[property];
    return typeof value === "function" ? value.bind(client) : value;
  },
});
