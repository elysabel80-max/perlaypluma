import { pgTable, text, serial, numeric, timestamp, jsonb, integer, boolean } from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  subtitle: text("subtitle").notNull(),
  category: text("category").notNull(), // 'velas-velones' | 'inciensos-aromaterapia' | 'cuarzos-minerales' | 'kits-rituales' | 'herramientas-misticas'
  categoryName: text("category_name").notNull(),
  subcategory: text("subcategory").notNull(),
  intention: text("intention").notNull(), // 'proteccion' | 'calma' | 'abundancia' | 'amor' | 'intuicion'
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  originalPrice: numeric("original_price", { precision: 10, scale: 2 }),
  rating: numeric("rating", { precision: 3, scale: 2 }).default("4.9"),
  reviewsCount: integer("reviews_count").default(24),
  stock: integer("stock").default(15),
  isFeatured: boolean("is_featured").default(false),
  isBestseller: boolean("is_bestseller").default(false),
  isNewArrival: boolean("is_new_arrival").default(false),
  primaryImage: text("primary_image").notNull(),
  detailImage: text("detail_image").notNull(),
  contextImage: text("context_image").notNull(),
  shortDescription: text("short_description").notNull(),
  fullDescription: text("full_description").notNull(),
  
  // Specific blocks per the design guide:
  propositoSimbolismo: text("proposito_simbolismo"), // For candles / crystals
  composicion: text("composicion"), // For candles (wax type, cotton wick)
  modoDeUso: text("modo_de_uso"), // Step-by-step ritual instructions
  guiaLecturaLlama: text("guia_lectura_llama"), // #BrujiTip how flame burns
  
  aromaticNotes: text("aromatic_notes"), // Visual fragrance profile
  energeticEffect: text("energetic_effect"), // Purifying, calming, uplift
  ethicalCommitment: text("ethical_commitment"), // Sustainable harvesting

  mineralAuthenticity: text("mineral_authenticity"), // 100% natural guarantee
  gemotherapyProperties: text("gemotherapy_properties"), // Gem properties
  cleansingRechargeGuide: text("cleansing_recharge_guide"), // How to clean with water/salt/selenite/lunar

  kitContents: jsonb("kit_contents").$type<string[]>(), // Array of included items
  kitRitualSteps: jsonb("kit_ritual_steps").$type<string[]>(), // Step-by-step ritual
  presentation: text("presentation"), // Gift box packaging details

  mysticLevel: text("mystic_level"), // Principiante / Intermedio / Avanzado
  consecrationGuide: text("consecration_guide"), // Consecration guidelines
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id),
  author: text("author").notNull(),
  city: text("city").notNull(),
  rating: integer("rating").notNull(),
  title: text("title").notNull(),
  comment: text("comment").notNull(),
  verifiedPurchase: boolean("verified_purchase").default(true),
  date: text("date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone"),
  address: text("address").notNull(),
  city: text("city").notNull(),
  postalCode: text("postal_code").notNull(),
  country: text("country").notNull().default("España"),
  intentionNote: text("intention_note"), // Special energy blessing request
  giftPackaging: boolean("gift_packaging").default(false),
  items: jsonb("items").notNull(),
  subtotal: numeric("subtotal", { precision: 10, scale: 2 }).notNull(),
  shipping: numeric("shipping", { precision: 10, scale: 2 }).notNull(),
  total: numeric("total", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("confirmado"), // confirmado, energetizado, enviado
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const newsletter = pgTable("newsletter", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  reference: text("reference").notNull().unique(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  plan: text("plan").notNull(), // 'plata' | 'oro'
  planName: text("plan_name").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  discount: text("discount").notNull(),
  status: text("status").notNull().default("activa"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
