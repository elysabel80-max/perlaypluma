import { db, hasDatabaseUrl } from "@/db";
import { products, reviews } from "@/db/schema";
import { SEED_PRODUCTS, SEED_REVIEWS } from "@/data/seedData";
import { ensureDatabaseSeeded } from "@/lib/seed";
import { eq } from "drizzle-orm";

export type ProductRecord = typeof products.$inferSelect;
export type ReviewRecord = typeof reviews.$inferSelect;

/**
 * Small circuit breaker: if PostgreSQL is unreachable (shared hosting without a
 * database, cold Neon endpoint, etc.) we stop retrying for a minute and serve
 * the curated demo catalogue instantly instead of making the visitor wait.
 */
let dbUnavailableUntil = 0;
const DB_RETRY_COOLDOWN_MS = 60_000;

function dbUsable(): boolean {
  return hasDatabaseUrl() && Date.now() > dbUnavailableUntil;
}

function markDbUnavailable(error: unknown) {
  dbUnavailableUntil = Date.now() + DB_RETRY_COOLDOWN_MS;
  console.warn(
    "[perla-pluma] PostgreSQL no disponible; sirviendo catálogo demo:",
    error instanceof Error ? error.message : error
  );
}

function buildFallbackProducts(): ProductRecord[] {
  return SEED_PRODUCTS.map((item, index) => ({
    id: index + 1,
    slug: item.slug,
    name: item.name,
    subtitle: item.subtitle,
    category: item.category,
    categoryName: item.categoryName,
    subcategory: item.subcategory,
    intention: item.intention,
    price: item.price,
    originalPrice: item.originalPrice ?? null,
    rating: item.rating,
    reviewsCount: item.reviewsCount,
    stock: item.stock,
    isFeatured: item.isFeatured,
    isBestseller: item.isBestseller,
    isNewArrival: item.isNewArrival,
    primaryImage: item.primaryImage,
    detailImage: item.detailImage,
    contextImage: item.contextImage,
    shortDescription: item.shortDescription,
    fullDescription: item.fullDescription,
    propositoSimbolismo: item.propositoSimbolismo ?? null,
    composicion: item.composicion ?? null,
    modoDeUso: item.modoDeUso ?? null,
    guiaLecturaLlama: item.guiaLecturaLlama ?? null,
    aromaticNotes: item.aromaticNotes ?? null,
    energeticEffect: item.energeticEffect ?? null,
    ethicalCommitment: item.ethicalCommitment ?? null,
    mineralAuthenticity: item.mineralAuthenticity ?? null,
    gemotherapyProperties: item.gemotherapyProperties ?? null,
    cleansingRechargeGuide: item.cleansingRechargeGuide ?? null,
    kitContents: item.kitContents ?? null,
    kitRitualSteps: item.kitRitualSteps ?? null,
    presentation: item.presentation ?? null,
    mysticLevel: item.mysticLevel ?? null,
    consecrationGuide: item.consecrationGuide ?? null,
    createdAt: new Date(),
  }));
}

function buildFallbackReviews(): ReviewRecord[] {
  const all = buildFallbackProducts();
  return SEED_REVIEWS.map((review, index) => {
    const match = all.find((p) => p.slug === review.productSlug);
    return {
      id: index + 1,
      productId: match?.id ?? null,
      author: review.author,
      city: review.city,
      rating: review.rating,
      title: review.title,
      comment: review.comment,
      verifiedPurchase: review.verifiedPurchase,
      date: review.date,
      createdAt: new Date(),
    };
  });
}

/** All products: PostgreSQL when reachable, otherwise the curated demo catalogue. */
export async function getAllProducts(): Promise<ProductRecord[]> {
  if (dbUsable()) {
    try {
      await ensureDatabaseSeeded();
      const rows = await db.select().from(products);
      if (rows.length > 0) return rows;
    } catch (error) {
      markDbUnavailable(error);
    }
  }
  return buildFallbackProducts();
}

export async function getProductBySlug(slug: string): Promise<{
  product: ProductRecord | null;
  productReviews: ReviewRecord[];
  related: ProductRecord[];
}> {
  const all = await getAllProducts();
  const product = all.find((p) => p.slug === slug) ?? null;

  if (!product) {
    return { product: null, productReviews: [], related: [] };
  }

  let productReviews: ReviewRecord[] = [];
  if (dbUsable()) {
    try {
      productReviews = await db
        .select()
        .from(reviews)
        .where(eq(reviews.productId, product.id));
    } catch (error) {
      markDbUnavailable(error);
    }
  }
  if (productReviews.length === 0) {
    productReviews = buildFallbackReviews().filter((r) => r.productId === product.id);
  }

  const related = all
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 3);

  return { product, productReviews, related };
}

export async function getLatestReviews(limit = 3): Promise<ReviewRecord[]> {
  if (dbUsable()) {
    try {
      await ensureDatabaseSeeded();
      const rows = await db.select().from(reviews).limit(limit);
      if (rows.length > 0) return rows;
    } catch (error) {
      markDbUnavailable(error);
    }
  }
  return buildFallbackReviews().slice(0, limit);
}
