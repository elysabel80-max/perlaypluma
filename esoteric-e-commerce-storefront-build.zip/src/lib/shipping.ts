/**
 * Política de envío de Perla & Pluma (única fuente de verdad).
 * Cambiar aquí el umbral actualiza la cabecera, el carrito y el checkout.
 */
export const FREE_SHIPPING_THRESHOLD = 69;
export const SHIPPING_COST = 4.95;
export const GIFT_PACKAGING_COST = 3.5;
