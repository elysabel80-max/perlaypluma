"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  PackagePlus,
  Table as TableIcon,
  Layers,
  Sparkles,
  Check,
  AlertCircle,
  ExternalLink,
  Download,
  Search,
  Eye,
  FileSpreadsheet,
  ArrowRight,
  Shield,
  Key,
  Truck,
  Compass,
  CheckCircle2,
  RefreshCw,
  Save,
  Upload,
  Trash2,
} from "lucide-react";

interface ProductItem {
  slug: string;
  name: string;
  subtitle?: string;
  price: string;
  originalPrice?: string;
  category: string;
  categoryName: string;
  subcategory?: string;
  intention: string;
  primaryImage: string;
  shortDescription?: string;
  supplierUrl?: string;
  stock?: number;
}

interface AwProduct {
  id: number;
  code: string;
  name: string;
  wholesalePrice: string;
  suggestedRetail: string;
  stock: number;
  imageUrl: string;
  barcode: string;
  shortDescription: string;
  fullDescription: string;
  weight: number;
  slug: string;
}

const CATEGORIES_LIST = [
  { id: "velas-velones", name: "Velas & Velones" },
  { id: "inciensos-aromaterapia", name: "Inciensos & Aromaterapia" },
  { id: "cuarzos-minerales", name: "Cuarzos & Joyería en Plata" },
  { id: "kits-rituales", name: "Kits de Rituales Completos" },
  { id: "herramientas-misticas", name: "Herramientas Místicas & Altar" },
];

const SUBCATEGORIES_MAP: Record<string, string[]> = {
  "velas-velones": [
    "Velas de Miel Natural",
    "Velones de Propósito y Ritualizados",
    "Velas Aromáticas con Cristales",
    "Velas de Colores y Formas",
  ],
  "inciensos-aromaterapia": [
    "Inciensos Naturales & Varillas Masala",
    "Conos & Conos de Reflujo",
    "Palo Santo & Atados de Salvia",
    "Defumación Activada & Resinas",
    "Sprays Áuricos & Aguas Floridas",
  ],
  "cuarzos-minerales": [
    "Cantos Rodados (Piedras Pulidas)",
    "Minerales en Bruto & Drusas",
    "Placas y Cuencos de Selenita",
    "Joyería en Minerales (Plata 925)",
    "Pulseras & Amuletos Energéticos",
  ],
  "kits-rituales": [
    "Kit de Limpieza Energética",
    "Kit de Abundancia & Prosperidad",
    "Kit de Protección Energética",
    "Kit de Amor Propio & Calma",
  ],
  "herramientas-misticas": [
    "Tarot & Oráculos",
    "Runas Sagradas & Adivinación",
    "Péndulos de Radiestesia",
    "Sonido Sagrado & Meditación",
    "Accesorios de Altar & Calderos",
  ],
};

const INTENTIONS_LIST = [
  { id: "proteccion", name: "Protección & Limpieza Energética" },
  { id: "calma", name: "Calma, Estrés & Sosiego" },
  { id: "abundancia", name: "Abundancia & Prosperidad" },
  { id: "amor", name: "Amor Propio & Vínculos" },
  { id: "intuicion", name: "Intuición & Meditación" },
];

const DEMO_PRODUCT_SLUGS = [
  "velas-miel-pura-colmena",
  "velon-ritualizado-san-benito-corte",
  "vela-soja-amatista-lavanda",
  "atado-salvia-blanca-californiana",
  "incienso-masala-artesanal-sagrada-madre",
  "bruma-aurica-agua-florida-artesanal",
  "turmalina-negra-en-bruto-madagascar",
  "cuenco-placa-selenita-marroqui",
  "pulsera-cuarzo-rosa-plata-925",
  "pirita-cubica-dorada-peru",
  "kit-limpieza-energetica-integral",
  "kit-abundancia-prosperidad-canela",
  "kit-amor-propio-calma-rosa",
  "tarot-rider-waite-consagrado-con-bolsa",
  "pendulo-radiestesia-amatista-faceta",
  "cuenco-tibetano-7-metales-cantor",
  "tapete-altar-geometria-sagrada-flor-de-la-vida",
  "set-runas-vikingas-amatista-grabada-oro",
  "runas-madera-fresno-nordico-artesanal",
];

export default function AdminCatalogoPage() {
  const [activeTab, setActiveTab] = useState<"connections" | "aw-explorer" | "form" | "batch" | "list">("list");
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusMessage, setStatusMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Supplier Settings State
  const [supplierConfig, setSupplierConfig] = useState({
    awToken: "",
    eproloKey: "",
    eproloSecret: "",
    hasAwToken: false,
    hasEproloKey: false,
    awTokenMasked: "",
  });
  const [savingConfig, setSavingConfig] = useState(false);

  // AW Dropship Explorer State
  const [awSearch, setAwSearch] = useState("");
  const [awProducts, setAwProducts] = useState<AwProduct[]>([]);
  const [awLoading, setAwLoading] = useState(false);
  const [awTotal, setAwTotal] = useState(0);
  const [awPage, setAwPage] = useState(1);
  const [awCustomPrices, setAwCustomPrices] = useState<Record<number, string>>({});
  const [awSelectedIntention, setAwSelectedIntention] = useState<Record<number, string>>({});
  const [awSelectedCategory, setAwSelectedCategory] = useState<Record<number, string>>({});
  const [awSelectedSubcategory, setAwSelectedSubcategory] = useState<Record<number, string>>({});
  const [awAddedIds, setAwAddedIds] = useState<number[]>([]);
  const [awAddingId, setAwAddingId] = useState<number | null>(null);

  // In-line table edits state (Inventory tab)
  const [rowEdits, setRowEdits] = useState<
    Record<string, { price?: string; category?: string; subcategory?: string; intention?: string }>
  >({});
  const [savingRowSlug, setSavingRowSlug] = useState<string | null>(null);
  const [savedRowSlug, setSavedRowSlug] = useState<string | null>(null);

  // Batch selection & deletion state (Lotes)
  const [selectedSlugs, setSelectedSlugs] = useState<string[]>([]);
  const [deletingSlug, setDeletingSlug] = useState<string | null>(null);
  const [isDeletingBatch, setIsDeletingBatch] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    name: "",
    subtitle: "",
    price: "",
    originalPrice: "",
    category: "velas-velones",
    subcategory: "Velas de Miel Natural",
    intention: "proteccion",
    primaryImage: "",
    shortDescription: "",
    fullDescription: "",
    stock: "10",
    supplierUrl: "",
    supplierName: "",
  });
  const [submitting, setSubmitting] = useState(false);

  // Batch Import State
  const [rawTableText, setRawTableText] = useState("");
  const [parsedBatch, setParsedBatch] = useState<any[]>([]);

  // List Filter State
  const [searchFilter, setSearchFilter] = useState("");

  const loadCatalog = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/products");
      const data = await res.json();
      if (data.success && Array.isArray(data.products)) {
        setProducts(data.products);
      }
    } catch (e) {
      console.error("Error loading products:", e);
    } finally {
      setLoading(false);
    }
  };

  const loadSupplierSettings = async () => {
    try {
      const res = await fetch("/api/supplier-settings");
      const data = await res.json();
      if (data.success && data.settings) {
        setSupplierConfig((prev) => ({
          ...prev,
          hasAwToken: data.settings.hasAwToken,
          awTokenMasked: data.settings.awTokenMasked,
          hasEproloKey: data.settings.hasEproloKey,
        }));
      }
    } catch (e) {
      console.warn("Could not load supplier settings:", e);
    }
  };

  const searchAwCatalog = async (query: string, pageNum = 1) => {
    try {
      setAwLoading(true);
      const res = await fetch(`/api/aw/products?q=${encodeURIComponent(query)}&page=${pageNum}&per_page=12`);
      const data = await res.json();
      if (data.success && Array.isArray(data.products)) {
        setAwProducts(data.products);
        setAwTotal(data.total || data.products.length);
        setAwPage(pageNum);
      } else {
        setStatusMessage({ type: "error", text: data.message || "No se pudieron obtener productos de AW Artisan." });
      }
    } catch (err) {
      console.error("Error fetching AW products:", err);
    } finally {
      setAwLoading(false);
    }
  };

  useEffect(() => {
    loadCatalog();
    loadSupplierSettings();
    searchAwCatalog("", 1);
  }, []);

  const handleSaveSupplierSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingConfig(true);
    try {
      const res = await fetch("/api/supplier-settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          awToken: supplierConfig.awToken || undefined,
          eproloKey: supplierConfig.eproloKey || undefined,
          eproloSecret: supplierConfig.eproloSecret || undefined,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setStatusMessage({ type: "success", text: "¡Claves de proveedores guardadas y activadas con éxito!" });
        loadSupplierSettings();
        searchAwCatalog(awSearch || "cuarzo", 1);
      } else {
        setStatusMessage({ type: "error", text: data.message || "Error al guardar claves" });
      }
    } catch {
      setStatusMessage({ type: "error", text: "Error de red al guardar las claves" });
    } finally {
      setSavingConfig(false);
    }
  };

  // Add a product from AW Artisan with 1 click
  const handleAddAwProduct = async (item: AwProduct) => {
    setAwAddingId(item.id);
    try {
      const retailPrice = awCustomPrices[item.id] || item.suggestedRetail;
      const intention = awSelectedIntention[item.id] || "proteccion";
      let category = awSelectedCategory[item.id];

      if (!category) {
        const lower = item.name.toLowerCase();
        if (lower.includes("vela") || lower.includes("velon")) category = "velas-velones";
        else if (lower.includes("incienso") || lower.includes("aroma") || lower.includes("difusor")) category = "inciensos-aromaterapia";
        else if (lower.includes("cuarzo") || lower.includes("amatista") || lower.includes("ágata") || lower.includes("pulsera") || lower.includes("gema")) category = "cuarzos-minerales";
        else if (lower.includes("kit") || lower.includes("ritual")) category = "kits-rituales";
        else category = "herramientas-misticas";
      }

      const availableSubs = SUBCATEGORIES_MAP[category] || [];
      const subcategory = awSelectedSubcategory[item.id] || availableSubs[0] || "Minerales Auténticos";

      const payload = {
        name: item.name,
        price: retailPrice,
        originalPrice: (parseFloat(item.wholesalePrice) * 3).toFixed(2),
        category,
        categoryName: CATEGORIES_LIST.find((c) => c.id === category)?.name || "Catálogo Sagrado",
        subcategory,
        intention,
        primaryImage: item.imageUrl,
        detailImage: item.imageUrl,
        contextImage: item.imageUrl,
        shortDescription: item.shortDescription || "Pieza artesanal de alta vibración, purificada para tu bienestar.",
        fullDescription: item.fullDescription || "Pieza purificada y consagrada en nuestro altar, seleccionada con mimo para acompañarte y armonizar tu espacio.",
        supplierUrl: `https://www.awartisan.es/app/products/${item.id}`,
        supplierName: "AW Artisan España",
        stock: item.stock,
      };

      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success) {
        setAwAddedIds((prev) => [...prev, item.id]);
        setStatusMessage({
          type: "success",
          text: `¡«${item.name}» añadido a tu tienda en vivo con éxito!`,
        });
        await loadCatalog();
      } else {
        setStatusMessage({ type: "error", text: data.message || "Error al añadir el producto." });
      }
    } catch {
      setStatusMessage({ type: "error", text: "Error de red al añadir el artículo a la tienda." });
    } finally {
      setAwAddingId(null);
    }
  };

  // Save row changes in Inventory table
  const handleSaveRow = async (p: ProductItem) => {
    const edit = rowEdits[p.slug] || {};
    const updatedPrice = edit.price !== undefined ? edit.price : p.price;
    const updatedCategory = edit.category !== undefined ? edit.category : p.category;
    const updatedSubcategory = edit.subcategory !== undefined ? edit.subcategory : (p.subcategory || "");
    const updatedIntention = edit.intention !== undefined ? edit.intention : p.intention;
    const catName = CATEGORIES_LIST.find((c) => c.id === updatedCategory)?.name || updatedCategory;

    setSavingRowSlug(p.slug);
    try {
      const res = await fetch("/api/products", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          slug: p.slug,
          price: updatedPrice,
          category: updatedCategory,
          categoryName: catName,
          subcategory: updatedSubcategory,
          intention: updatedIntention,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSavedRowSlug(p.slug);
        setTimeout(() => setSavedRowSlug(null), 3500);
        setStatusMessage({
          type: "success",
          text: `¡«${p.name}» actualizado correctamente con su nueva subcategoría e intención!`,
        });
        await loadCatalog();
      } else {
        setStatusMessage({ type: "error", text: data.message || "Error al actualizar el producto." });
      }
    } catch {
      setStatusMessage({ type: "error", text: "Error de red al actualizar el producto." });
    } finally {
      setSavingRowSlug(null);
    }
  };

  // Toggle selection for a single product (batch selection / lote)
  const toggleSelectProduct = (slug: string) => {
    setSelectedSlugs((prev) =>
      prev.includes(slug) ? prev.filter((s) => s !== slug) : [...prev, slug]
    );
  };

  // Toggle select all visible products in current filter
  const toggleSelectAll = (filteredList: ProductItem[]) => {
    if (selectedSlugs.length === filteredList.length && filteredList.length > 0) {
      setSelectedSlugs([]);
    } else {
      setSelectedSlugs(filteredList.map((p) => p.slug));
    }
  };

  // Delete single product
  const handleDeleteSingle = async (slug: string, name: string) => {
    if (!window.confirm(`¿Seguro que deseas eliminar "${name}" del inventario de la tienda?`)) {
      return;
    }
    setDeletingSlug(slug);
    try {
      const res = await fetch("/api/products", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug }),
      });
      const data = await res.json();
      if (data.success) {
        setProducts((prev) => prev.filter((p) => p.slug !== slug));
        setSelectedSlugs((prev) => prev.filter((s) => s !== slug));
        setStatusMessage({
          type: "success",
          text: `✓ Artículo "${name}" eliminado correctamente del inventario.`,
        });
      } else {
        setStatusMessage({ type: "error", text: data.message || "Error al eliminar el artículo." });
      }
    } catch {
      setStatusMessage({ type: "error", text: "Error de red al intentar eliminar el artículo." });
    } finally {
      setDeletingSlug(null);
    }
  };

  // Delete batch (selected items / lote)
  const handleDeleteBatch = async () => {
    if (selectedSlugs.length === 0) return;
    if (
      !window.confirm(
        `¿Seguro que deseas eliminar el lote de ${selectedSlugs.length} artículos seleccionados del inventario?`
      )
    ) {
      return;
    }
    setIsDeletingBatch(true);
    try {
      const res = await fetch("/api/products", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slugs: selectedSlugs }),
      });
      const data = await res.json();
      if (data.success) {
        setProducts((prev) => prev.filter((p) => !selectedSlugs.includes(p.slug)));
        setStatusMessage({
          type: "success",
          text: `✓ Lote de ${selectedSlugs.length} productos eliminado con éxito del inventario.`,
        });
        setSelectedSlugs([]);
      } else {
        setStatusMessage({ type: "error", text: data.message || "Error al eliminar el lote." });
      }
    } catch {
      setStatusMessage({ type: "error", text: "Error de red al intentar eliminar el lote." });
    } finally {
      setIsDeletingBatch(false);
    }
  };

  // Purge the 19 demo products
  const handleDeleteDemoProducts = async () => {
    const presentDemoSlugs = products
      .filter((p) => DEMO_PRODUCT_SLUGS.includes(p.slug))
      .map((p) => p.slug);

    if (presentDemoSlugs.length === 0) {
      alert("Los 19 artículos de demostración ya no están en tu inventario.");
      return;
    }

    if (
      !window.confirm(
        `¿Deseas eliminar los ${presentDemoSlugs.length} artículos de demostración iniciales? (Los textos de guías y rituales se conservarán intactos).`
      )
    ) {
      return;
    }

    setIsDeletingBatch(true);
    try {
      const res = await fetch("/api/products", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slugs: presentDemoSlugs }),
      });
      const data = await res.json();
      if (data.success) {
        setProducts((prev) => prev.filter((p) => !presentDemoSlugs.includes(p.slug)));
        setSelectedSlugs((prev) => prev.filter((s) => !presentDemoSlugs.includes(s)));
        setStatusMessage({
          type: "success",
          text: `✓ Se han eliminado los ${presentDemoSlugs.length} artículos de demostración. Tu inventario ahora está limpio.`,
        });
      } else {
        setStatusMessage({ type: "error", text: data.message || "Error al eliminar artículos demo." });
      }
    } catch {
      setStatusMessage({ type: "error", text: "Error de red al intentar eliminar artículos demo." });
    } finally {
      setIsDeletingBatch(false);
    }
  };

  // Exportar Copia de Seguridad del Catálogo (Descarga en JSON)
  const handleExportBackup = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(products, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `catalogo-perla-pluma-backup-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setStatusMessage({ type: "success", text: "✓ Copia de seguridad del catálogo descargada en tu carpeta Descargas." });
  };

  // Restaurar Copia de Seguridad desde archivo JSON
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (!Array.isArray(json)) throw new Error("Formato no válido");
        const res = await fetch("/api/products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(json),
        });
        const data = await res.json();
        if (data.success) {
          setStatusMessage({ type: "success", text: `✓ ¡Copia de seguridad restaurada con éxito! Se cargaron los artículos en la tienda.` });
          await loadCatalog();
        } else {
          setStatusMessage({ type: "error", text: data.message || "Error al restaurar copia." });
        }
      } catch {
        setStatusMessage({ type: "error", text: "El archivo seleccionado no contiene una copia válida de productos." });
      }
    };
    reader.readAsText(file);
  };

  // Handle Single Product Submission
  const handleSingleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.price) {
      setStatusMessage({ type: "error", text: "El nombre y el precio son obligatorios." });
      return;
    }

    setSubmitting(true);
    setStatusMessage(null);

    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();

      if (data.success) {
        setStatusMessage({
          type: "success",
          text: `¡Producto "${formData.name}" creado con éxito y publicado en la tienda en vivo!`,
        });
        setFormData({
          name: "",
          subtitle: "",
          price: "",
          originalPrice: "",
          category: "velas-velones",
          subcategory: "Velas de Miel Natural",
          intention: "proteccion",
          primaryImage: "",
          shortDescription: "",
          fullDescription: "",
          stock: "10",
          supplierUrl: "",
          supplierName: "",
        });
        await loadCatalog();
        setActiveTab("list");
      } else {
        setStatusMessage({ type: "error", text: data.message || "Error al guardar el producto." });
      }
    } catch {
      setStatusMessage({ type: "error", text: "Error de red al conectar con el servidor." });
    } finally {
      setSubmitting(false);
    }
  };

  // Parse batch table text
  const handleParseBatch = () => {
    if (!rawTableText.trim()) {
      setStatusMessage({ type: "error", text: "Pega el contenido de una tabla o listado antes de procesar." });
      return;
    }

    const lines = rawTableText
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => l.length > 0 && !l.startsWith("|-") && !l.startsWith("+--"));

    if (lines.length === 0) {
      setStatusMessage({ type: "error", text: "No se encontraron filas con datos." });
      return;
    }

    const detected: any[] = [];
    const firstLine = lines[0].toLowerCase();
    const isMarkdownTable = firstLine.includes("|");
    const isCsv = firstLine.includes(",") || firstLine.includes(";");
    const isTab = firstLine.includes("\t");

    const splitRow = (row: string) => {
      if (isMarkdownTable) {
        return row
          .split("|")
          .map((c) => c.trim())
          .filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);
      }
      if (isTab) return row.split("\t").map((c) => c.trim());
      if (isCsv) {
        const delim = row.includes(";") ? ";" : ",";
        return row.split(delim).map((c) => c.replace(/^["']|["']$/g, "").trim());
      }
      return [row];
    };

    let startIndex = 0;
    if (
      firstLine.includes("nombre") ||
      firstLine.includes("producto") ||
      firstLine.includes("artículo") ||
      firstLine.includes("precio")
    ) {
      startIndex = 1;
    }

    for (let i = startIndex; i < lines.length; i++) {
      const cols = splitRow(lines[i]);
      if (cols.length >= 2) {
        const name = cols[0];
        const priceStr = cols[1]?.replace("€", "").trim();
        const categoryGuess = cols[2]?.toLowerCase() || "cuarzos-minerales";
        const intentionGuess = cols[3]?.toLowerCase() || "proteccion";
        const supplierUrl = cols[4] || "";
        const image = cols[5] || "/images/hero-retiro.jpg";
        const desc = cols[6] || "";

        let finalCat = "cuarzos-minerales";
        if (categoryGuess.includes("vela") || categoryGuess.includes("velon")) finalCat = "velas-velones";
        else if (categoryGuess.includes("incienso") || categoryGuess.includes("aroma") || categoryGuess.includes("salvia")) finalCat = "inciensos-aromaterapia";
        else if (categoryGuess.includes("kit") || categoryGuess.includes("ritual")) finalCat = "kits-rituales";
        else if (categoryGuess.includes("tarot") || categoryGuess.includes("altar") || categoryGuess.includes("pendulo") || categoryGuess.includes("joya")) finalCat = "herramientas-misticas";

        let finalIntention = "proteccion";
        if (intentionGuess.includes("calm") || intentionGuess.includes("estres") || intentionGuess.includes("paz")) finalIntention = "calma";
        else if (intentionGuess.includes("abund") || intentionGuess.includes("prosper") || intentionGuess.includes("diner")) finalIntention = "abundancia";
        else if (intentionGuess.includes("amor") || intentionGuess.includes("pareja") || intentionGuess.includes("autoestim")) finalIntention = "amor";
        else if (intentionGuess.includes("intui") || intentionGuess.includes("medita") || intentionGuess.includes("conexion")) finalIntention = "intuicion";

        const availableSubs = SUBCATEGORIES_MAP[finalCat] || [];

        if (name && priceStr) {
          detected.push({
            name,
            price: priceStr,
            category: finalCat,
            categoryName: CATEGORIES_LIST.find((c) => c.id === finalCat)?.name || "Catálogo Sagrado",
            subcategory: availableSubs[0] || "Minerales Auténticos",
            intention: finalIntention,
            supplierUrl,
            primaryImage: image.startsWith("http") ? image : "/images/hero-retiro.jpg",
            shortDescription: desc || `Pieza de ${name} seleccionada con amor para elevar tu vibración.`,
          });
        }
      }
    }

    setParsedBatch(detected);
    if (detected.length > 0) {
      setStatusMessage({
        type: "success",
        text: `Se han detectado ${detected.length} productos listos para importar. Revisa la tabla abajo y dale a "Confirmar e Importar Todos".`,
      });
    } else {
      setStatusMessage({
        type: "error",
        text: "No se pudieron reconocer columnas válidas de Nombre y Precio en el texto pegado.",
      });
    }
  };

  const handleImportBatch = async () => {
    if (parsedBatch.length === 0) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsedBatch),
      });
      const data = await res.json();
      if (data.success) {
        setStatusMessage({
          type: "success",
          text: `¡Éxito! Se han incorporado ${parsedBatch.length} productos a la tienda en vivo.`,
        });
        setParsedBatch([]);
        setRawTableText("");
        await loadCatalog();
        setActiveTab("list");
      } else {
        setStatusMessage({ type: "error", text: data.message || "Error al importar el lote." });
      }
    } catch {
      setStatusMessage({ type: "error", text: "Error de red al importar los productos." });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDownloadTemplate = () => {
    const csvContent =
      "Nombre,Precio,Categoria,Subcategoria,Intencion,Enlace_Proveedor,Foto_URL,Descripcion\n" +
      "Vela de Miel 100% Panal Artesanal,4.90,Velas & Velones,Velas de Miel Natural,Amor Propio,https://proveedor.com/item1,https://images.pexels.com/photos/30235380/pexels-photo-30235380.jpeg,Cera pura natural con aroma sutil\n" +
      "Palo Santo Sagrado de Recolección Ética,3.50,Inciensos & Aromaterapia,Palo Santo & Atados de Salvia,Protección,https://proveedor.com/item2,https://images.pexels.com/photos/8436503/pexels-photo-8436503.jpeg,Madera aromática de Perú\n" +
      "Pulsera de Amatista Natural y Plata,14.90,Cuarzos & Joyería en Plata,Joyería en Minerales (Plata 925),Calma,https://es.nihaojewelry.com/natural-stone-jewelry,https://images.pexels.com/photos/709622/pexels-photo-709622.jpeg,Pulsera elástica de cuentas pulidas\n";

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "plantilla_productos_notebooklm_perlaypluma.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredProducts = products.filter((p) => {
    if (!searchFilter) return true;
    const q = searchFilter.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      (p.subcategory && p.subcategory.toLowerCase().includes(q)) ||
      p.intention.toLowerCase().includes(q) ||
      (p.supplierUrl && p.supplierUrl.toLowerCase().includes(q))
    );
  });

  return (
    <main className="min-h-screen bg-[#FDFBF7] text-[#242B26] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Top Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E8E2D9] pb-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EAE3D6] text-xs font-semibold text-[#4A5D4E] uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Gestión de Catálogo &amp; Proveedores</span>
            </div>
            <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#1B1C1A]">
              Panel de Catálogo &amp; Dropshipping
            </h1>
            <p className="text-xs sm:text-sm text-[#5B675E] mt-1 max-w-2xl">
              Modifica categorías, subcategorías e intenciones en vivo, añade artículos desde AW Dropship y sincroniza pedidos en automático.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/catalogo"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-xs font-medium text-[#4A5D4E] hover:bg-[#F5F2EB] transition-colors shadow-2xs"
            >
              <Eye className="w-4 h-4 text-[#D4AF37]" />
              <span>Ver Tienda en Vivo</span>
            </Link>
          </div>
        </div>

        {/* Status Toast */}
        {statusMessage && (
          <div
            className={`p-4 rounded-2xl border flex items-start gap-3 transition-all ${
              statusMessage.type === "success"
                ? "bg-emerald-50 border-emerald-200 text-emerald-900"
                : "bg-rose-50 border-rose-200 text-rose-900"
            }`}
          >
            {statusMessage.type === "success" ? (
              <Check className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            )}
            <div className="text-xs sm:text-sm font-medium">{statusMessage.text}</div>
          </div>
        )}

        {/* Tab Selector */}
        <div className="flex flex-wrap gap-2 sm:gap-4 border-b border-[#E8E2D9] pb-4">
          <button
            onClick={() => setActiveTab("list")}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all ${
              activeTab === "list"
                ? "bg-[#4A5D4E] text-[#FDFBF7] shadow-sm font-semibold"
                : "bg-white text-stone-600 border border-[#E0D7C8] hover:bg-[#F5F2EB]"
            }`}
          >
            <Layers className="w-4 h-4 text-[#D4AF37]" />
            <span>Inventario en Tienda ({products.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("aw-explorer");
              if (awProducts.length === 0) searchAwCatalog(awSearch, 1);
            }}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all ${
              activeTab === "aw-explorer"
                ? "bg-[#4A5D4E] text-[#FDFBF7] shadow-sm font-semibold"
                : "bg-white text-stone-600 border border-[#E0D7C8] hover:bg-[#F5F2EB]"
            }`}
          >
            <Compass className="w-4 h-4 text-[#D4AF37]" />
            <span>Catálogo Proveedor AW Dropship (6.811 Artículos)</span>
          </button>

          <button
            onClick={() => setActiveTab("form")}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all ${
              activeTab === "form"
                ? "bg-[#4A5D4E] text-[#FDFBF7] shadow-sm font-semibold"
                : "bg-white text-stone-600 border border-[#E0D7C8] hover:bg-[#F5F2EB]"
            }`}
          >
            <PackagePlus className="w-4 h-4 text-[#D4AF37]" />
            <span>Añadir Producto Manual / Nihao</span>
          </button>

          <button
            onClick={() => setActiveTab("batch")}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all ${
              activeTab === "batch"
                ? "bg-[#4A5D4E] text-[#FDFBF7] shadow-sm font-semibold"
                : "bg-white text-stone-600 border border-[#E0D7C8] hover:bg-[#F5F2EB]"
            }`}
          >
            <TableIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>Importar Tabla (NotebookLM / Excel)</span>
          </button>

          <button
            onClick={() => setActiveTab("connections")}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all ${
              activeTab === "connections"
                ? "bg-[#4A5D4E] text-[#FDFBF7] shadow-sm font-semibold"
                : "bg-white text-stone-600 border border-[#E0D7C8] hover:bg-[#F5F2EB]"
            }`}
          >
            <Key className="w-4 h-4 text-[#D4AF37]" />
            <span>Conexión Proveedores ({supplierConfig.hasAwToken ? "✓ Conectado" : "Pendiente"})</span>
          </button>
        </div>

        {/* TAB 5: INVENTARIO EN TIENDA (COLUMNA SUBCATEGORÍAS & EDICIÓN DE INTENCIÓN/PRECIO) */}
        {activeTab === "list" && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E0D7C8] shadow-sm space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#1B1C1A]">
                  Inventario Activo en Tienda ({products.length} productos)
                </h2>
                <p className="text-xs sm:text-sm text-[#5B675E] mt-1">
                  Aquí puedes modificar directamente la <strong>Categoría</strong>, <strong>Subcategoría</strong>, <strong>Intención</strong> o <strong>Precio</strong> de cualquier artículo y darle a «Guardar».
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Botón para saltar al Catálogo Completo de Proveedor */}
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab("aw-explorer");
                    if (awProducts.length === 0) searchAwCatalog("", 1);
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#4A5D4E] text-white text-xs font-semibold hover:bg-[#38483B] transition-colors shadow-2xs cursor-pointer"
                  title="Abrir el catálogo de 6.811 artículos de AW Dropship para añadir novedades a tu tienda"
                >
                  <Compass className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Catálogo Proveedor (6.811)</span>
                </button>

                {/* Botón para ver el Catálogo Público de la Tienda */}
                <Link
                  href="/catalogo"
                  target="_blank"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-[#D8C79E] bg-[#FAF7F0] text-xs font-semibold text-[#4A5D4E] hover:bg-[#F2ECE1] transition-colors shadow-2xs"
                  title="Ver el catálogo público de la tienda como lo ven los clientes"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Ver Catálogo en Tienda</span>
                </Link>

                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#D8C79E] bg-[#FAF7F0] text-xs font-semibold text-[#4A5D4E] hover:bg-[#F2ECE1] transition-colors shadow-2xs"
                  title="Descargar copia de seguridad en JSON para tenerla guardada en tu PC"
                >
                  <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Copia de Seguridad</span>
                </button>

                <label
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#D8C79E] bg-[#FAF7F0] text-xs font-semibold text-[#4A5D4E] hover:bg-[#F2ECE1] cursor-pointer transition-colors shadow-2xs"
                  title="Restaurar productos desde un archivo de copia"
                >
                  <Upload className="w-3.5 h-3.5 text-[#4A5D4E]" />
                  <span>Restaurar Copia</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportBackup}
                    className="hidden"
                  />
                </label>

                <div className="relative w-full sm:w-60">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="text"
                    placeholder="Buscar en tu inventario..."
                    value={searchFilter}
                    onChange={(e) => setSearchFilter(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 rounded-xl border border-[#D8C79E] bg-[#FAF7F0] text-xs text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>
              </div>
            </div>

            {/* AVISO DE ARTÍCULOS DE DEMOSTRACIÓN */}
            {products.some((p) => DEMO_PRODUCT_SLUGS.includes(p.slug)) && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-amber-50/80 border border-amber-200">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wide">
                      Artículos de Prueba Iniciales ({products.filter((p) => DEMO_PRODUCT_SLUGS.includes(p.slug)).length} productos)
                    </h4>
                    <p className="text-xs text-amber-800 mt-0.5">
                      Puedes eliminar estos artículos de muestra para dejar tu inventario limpio. Las fotos de guía y textos de rituales permanecerán guardados.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleDeleteDemoProducts}
                  disabled={isDeletingBatch}
                  className="shrink-0 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold transition-all shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{isDeletingBatch ? "Eliminando..." : "Eliminar los 19 Artículos Demo"}</span>
                </button>
              </div>
            )}

            {/* BARRA DE ACCIÓN POR LOTE SELECCIONADO */}
            {selectedSlugs.length > 0 && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-rose-50 border border-rose-200">
                <div className="flex items-center gap-3">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
                  <span className="text-xs font-bold text-rose-900">
                    Lote seleccionado: {selectedSlugs.length} {selectedSlugs.length === 1 ? "artículo" : "artículos"}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedSlugs([])}
                    className="px-3 py-1.5 rounded-xl border border-rose-300 text-xs font-semibold text-rose-800 hover:bg-rose-100 transition-colors cursor-pointer"
                  >
                    Deseleccionar
                  </button>
                  <button
                    type="button"
                    onClick={handleDeleteBatch}
                    disabled={isDeletingBatch}
                    className="inline-flex items-center gap-2 px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs disabled:opacity-50 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isDeletingBatch ? "Eliminando lote..." : `Eliminar Lote Seleccionado (${selectedSlugs.length})`}</span>
                  </button>
                </div>
              </div>
            )}

            {loading ? (
              <div className="py-12 text-center text-xs text-stone-500">Cargando catálogo en vivo...</div>
            ) : filteredProducts.length === 0 ? (
              <div className="py-12 text-center text-xs text-stone-500">No se encontraron productos coincidentes.</div>
            ) : (
              <div className="overflow-x-auto rounded-2xl border border-[#E0D7C8]">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-[#FAF7F0] border-b border-[#E0D7C8] text-stone-700 font-bold uppercase tracking-wider">
                    <tr>
                      {/* Columna Lote (Checkbox) */}
                      <th className="p-3 w-12 text-center">
                        <div className="flex flex-col items-center gap-0.5">
                          <input
                            type="checkbox"
                            checked={
                              filteredProducts.length > 0 &&
                              selectedSlugs.length === filteredProducts.length
                            }
                            onChange={() => toggleSelectAll(filteredProducts)}
                            title="Seleccionar todo el lote visible"
                            className="w-4 h-4 rounded text-[#4A5D4E] focus:ring-[#4A5D4E] accent-[#4A5D4E] cursor-pointer"
                          />
                          <span className="text-[9px] text-stone-500 font-bold uppercase tracking-tight">Lote</span>
                        </div>
                      </th>
                      <th className="p-3">Foto</th>
                      <th className="p-3 min-w-[200px]">Nombre</th>
                      <th className="p-3 w-28">Precio (€)</th>
                      <th className="p-3 min-w-[180px]">Categoría</th>
                      <th className="p-3 min-w-[220px]">Subcategoría</th>
                      <th className="p-3 min-w-[180px]">Intención</th>
                      <th className="p-3">Proveedor</th>
                      <th className="p-3 text-center w-28">Guardar</th>
                      <th className="p-3 text-center w-28">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E0D7C8]">
                    {filteredProducts.map((p) => {
                      const edit = rowEdits[p.slug] || {};
                      const currentPrice = edit.price !== undefined ? edit.price : p.price;
                      const currentCat = edit.category !== undefined ? edit.category : p.category;
                      const currentSubcat = edit.subcategory !== undefined ? edit.subcategory : (p.subcategory || "");
                      const currentIntention = edit.intention !== undefined ? edit.intention : p.intention;
                      const isSaving = savingRowSlug === p.slug;
                      const isSaved = savedRowSlug === p.slug;
                      const isSelected = selectedSlugs.includes(p.slug);
                      const isDeletingThis = deletingSlug === p.slug;

                      const availableSubs = SUBCATEGORIES_MAP[currentCat] || [];

                      return (
                        <tr
                          key={p.slug}
                          className={`transition-colors ${
                            isSelected ? "bg-amber-50/60" : "hover:bg-[#FDFBF7]"
                          }`}
                        >
                          {/* 0. Selección de Lote */}
                          <td className="p-3 text-center">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleSelectProduct(p.slug)}
                              title={`Seleccionar ${p.name} en el lote`}
                              className="w-4 h-4 rounded text-[#4A5D4E] focus:ring-[#4A5D4E] accent-[#4A5D4E] cursor-pointer"
                            />
                          </td>

                          {/* 1. Foto */}
                          <td className="p-3">
                            <div className="relative w-11 h-11 rounded-lg overflow-hidden bg-stone-100 border border-stone-200">
                              {p.primaryImage ? (
                                <Image
                                  src={p.primaryImage}
                                  alt={p.name}
                                  fill
                                  sizes="44px"
                                  className="object-cover"
                                />
                              ) : (
                                <div className="w-full h-full bg-stone-200" />
                              )}
                            </div>
                          </td>

                          {/* 2. Nombre */}
                          <td className="p-3 font-semibold text-stone-800">
                            {p.name}
                            {p.subtitle && (
                              <span className="block text-[10px] text-stone-400 font-normal line-clamp-1">
                                {p.subtitle}
                              </span>
                            )}
                          </td>

                          {/* 3. Precio editable */}
                          <td className="p-3">
                            <div className="flex items-center gap-1">
                              <input
                                type="text"
                                value={currentPrice}
                                onChange={(e) =>
                                  setRowEdits({
                                    ...rowEdits,
                                    [p.slug]: { ...edit, price: e.target.value },
                                  })
                                }
                                className="w-16 px-2 py-1 rounded-lg border border-[#D8C79E] text-xs font-bold text-emerald-800 bg-white"
                              />
                              <span className="font-bold text-emerald-800">€</span>
                            </div>
                          </td>

                          {/* 4. Categoría editable */}
                          <td className="p-3">
                            <select
                              value={currentCat}
                              onChange={(e) => {
                                const newCat = e.target.value;
                                const newSub = SUBCATEGORIES_MAP[newCat]?.[0] || "";
                                setRowEdits({
                                  ...rowEdits,
                                  [p.slug]: { ...edit, category: newCat, subcategory: newSub },
                                });
                              }}
                              className="w-full px-2 py-1.5 rounded-lg border border-[#D8C79E] bg-white text-xs font-medium text-stone-700"
                            >
                              {CATEGORIES_LIST.map((c) => (
                                <option key={c.id} value={c.id}>
                                  {c.name}
                                </option>
                              ))}
                            </select>
                          </td>

                          {/* 5. Subcategoría editable */}
                          <td className="p-3">
                            <select
                              value={currentSubcat}
                              onChange={(e) =>
                                setRowEdits({
                                  ...rowEdits,
                                  [p.slug]: { ...edit, subcategory: e.target.value },
                                })
                              }
                              className="w-full px-2 py-1.5 rounded-lg border border-[#D8C79E] bg-white text-xs font-medium text-[#4A5D4E]"
                            >
                              {availableSubs.map((sub) => (
                                <option key={sub} value={sub}>
                                  {sub}
                                </option>
                              ))}
                              {currentSubcat && !availableSubs.includes(currentSubcat) && (
                                <option value={currentSubcat}>{currentSubcat}</option>
                              )}
                            </select>
                          </td>

                          {/* 6. Intención editable */}
                          <td className="p-3">
                            <select
                              value={currentIntention}
                              onChange={(e) =>
                                setRowEdits({
                                  ...rowEdits,
                                  [p.slug]: { ...edit, intention: e.target.value },
                                })
                              }
                              className="w-full px-2 py-1.5 rounded-lg border border-[#D8C79E] bg-white text-xs font-medium text-stone-700"
                            >
                              {INTENTIONS_LIST.map((i) => (
                                <option key={i.id} value={i.id}>
                                  {i.name.split("&")[0].trim()}
                                </option>
                              ))}
                            </select>
                          </td>

                          {/* 7. Proveedor / Enlace */}
                          <td className="p-3 text-stone-500">
                            {p.supplierUrl ? (
                              <a
                                href={p.supplierUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-[#4A5D4E] underline hover:text-[#D4AF37]"
                              >
                                <span>Ver</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            ) : (
                              <span className="text-stone-300">—</span>
                            )}
                          </td>

                          {/* 8. Guardar Fila */}
                          <td className="p-3 text-center">
                            <button
                              onClick={() => handleSaveRow(p)}
                              disabled={isSaving}
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5 shadow-2xs ${
                                isSaved
                                  ? "bg-emerald-100 text-emerald-800 border border-emerald-300"
                                  : "bg-[#4A5D4E] hover:bg-[#38483B] text-white"
                              }`}
                            >
                              {isSaving ? (
                                <RefreshCw className="w-3 h-3 animate-spin" />
                              ) : isSaved ? (
                                <>
                                  <Check className="w-3 h-3 text-emerald-600" />
                                  <span>Guardado</span>
                                </>
                              ) : (
                                <>
                                  <Save className="w-3 h-3 text-[#D4AF37]" />
                                  <span>Guardar</span>
                                </>
                              )}
                            </button>
                          </td>

                          {/* 9. Acciones: Ver Ficha + Eliminar */}
                          <td className="p-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <Link
                                href={`/producto/${p.slug}`}
                                target="_blank"
                                title="Ver ficha en la tienda"
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-[#D8C79E] text-[11px] font-medium text-[#4A5D4E] hover:bg-[#FAF7F0]"
                              >
                                <span>Ver</span>
                                <ArrowRight className="w-3 h-3 text-[#D4AF37]" />
                              </Link>
                              <button
                                type="button"
                                onClick={() => handleDeleteSingle(p.slug, p.name)}
                                disabled={isDeletingThis}
                                title="Eliminar este artículo del inventario"
                                className="p-1.5 rounded-lg border border-stone-200 text-stone-400 hover:text-rose-600 hover:border-rose-300 hover:bg-rose-50 transition-colors disabled:opacity-40 cursor-pointer"
                              >
                                {isDeletingThis ? (
                                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-rose-500" />
                                ) : (
                                  <Trash2 className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* TAB 1: EXPLORADOR DE PRODUCTOS AW ARTISAN (CON SELECTOR DE SUBCATEGORÍA) */}
        {activeTab === "aw-explorer" && (
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E0D7C8] shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>Conectado a Almacén AW Artisan España (6.811 Artículos)</span>
                  </div>
                  <h2 className="font-serif text-2xl font-bold text-[#1B1C1A]">
                    Explorador de Catálogo Directo
                  </h2>
                  <p className="text-xs sm:text-sm text-[#5B675E] mt-1">
                    Búsqueda libre en todo el almacén sin restricciones. Escribe cualquier término en la lupa o filtra por familia.
                  </p>
                </div>

                {/* Botón Ver Todo y Filtro por Familias */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => {
                      setAwSearch("");
                      searchAwCatalog("", 1);
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all border cursor-pointer ${
                      awSearch === ""
                        ? "bg-[#4A5D4E] text-white border-[#4A5D4E] shadow-2xs"
                        : "bg-[#FAF7F0] text-stone-700 border-[#E0D7C8] hover:bg-[#EAE3D6]"
                    }`}
                  >
                    🌐 Ver Catálogo Completo (6.811)
                  </button>

                  <select
                    value={awSearch}
                    onChange={(e) => {
                      const val = e.target.value;
                      setAwSearch(val);
                      searchAwCatalog(val, 1);
                    }}
                    className="px-3 py-2 rounded-xl text-xs font-medium border border-[#D8C79E] bg-[#FAF7F0] text-stone-700 focus:outline-none cursor-pointer"
                  >
                    <option value="">-- Filtrar por Familia Temática --</option>
                    <option value="vela">🕯️ Velas & Velones</option>
                    <option value="incienso">🌿 Inciensos & Varillas</option>
                    <option value="cuarzo">🔮 Cuarzos & Cristales</option>
                    <option value="amatista">✨ Amatistas & Drusas</option>
                    <option value="pulsera">📿 Pulseras & Joyería</option>
                    <option value="difusor">💨 Difusores & Quemadores</option>
                    <option value="aceite">💧 Aceites Esenciales</option>
                    <option value="salvia">🌾 Salvia & Palo Santo</option>
                    <option value="pendulo">🎯 Péndulos de Radiestesia</option>
                    <option value="selenita">🌙 Lámparas & Selenita</option>
                    <option value="cuenco">🔔 Cuencos Tibetanos</option>
                    <option value="jabon">🧼 Jabones & Cosmética Natural</option>
                  </select>

                  <button
                    onClick={() => setActiveTab("list")}
                    className="px-3 py-2 rounded-xl text-xs font-semibold border border-[#D8C79E] bg-white text-[#4A5D4E] hover:bg-[#F5F2EB] transition-colors cursor-pointer"
                  >
                    📦 Volver a Mi Tienda ({products.length})
                  </button>
                </div>
              </div>

              {/* Search Bar Libre */}
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="text"
                    value={awSearch}
                    onChange={(e) => setAwSearch(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && searchAwCatalog(awSearch, 1)}
                    placeholder="Escribe lo que quieras buscar libremente en los 6.811 artículos (ej: salvia, drusa, campana, orgonita, pulsera, vela...)"
                    className="w-full pl-11 pr-10 py-3 rounded-2xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                  />
                  {awSearch && (
                    <button
                      type="button"
                      onClick={() => {
                        setAwSearch("");
                        searchAwCatalog("", 1);
                      }}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs font-bold bg-stone-100 hover:bg-stone-200 rounded-full w-5 h-5 flex items-center justify-center cursor-pointer"
                      title="Borrar búsqueda y ver todo"
                    >
                      ✕
                    </button>
                  )}
                </div>
                <button
                  onClick={() => searchAwCatalog(awSearch, 1)}
                  disabled={awLoading}
                  className="px-6 py-3 rounded-2xl bg-[#4A5D4E] hover:bg-[#38483B] text-white text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 shadow-sm disabled:opacity-50 cursor-pointer"
                >
                  {awLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  <span>Buscar</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between text-xs text-stone-500 mt-3 gap-2">
                {awTotal > 0 ? (
                  <div>
                    {awSearch.trim() ? (
                      <span>
                        Resultados para <span className="font-semibold text-stone-800">«{awSearch}»</span>:{" "}
                        <strong className="text-emerald-700 font-bold">{awTotal}</strong> artículos disponibles
                      </span>
                    ) : (
                      <span>
                        Mostrando catálogo completo:{" "}
                        <strong className="text-emerald-700 font-bold">{awTotal}</strong> artículos disponibles en almacén
                      </span>
                    )}
                  </div>
                ) : (
                  <div>No se encontraron artículos para esta búsqueda. Prueba con otro término.</div>
                )}
                {awSearch && (
                  <button
                    onClick={() => {
                      setAwSearch("");
                      searchAwCatalog("", 1);
                    }}
                    className="text-stone-500 hover:text-[#4A5D4E] underline text-xs font-medium cursor-pointer"
                  >
                    Ver todo el catálogo (sin filtro)
                  </button>
                )}
              </div>
            </div>

            {/* Results Grid */}
            {awLoading ? (
              <div className="py-20 text-center space-y-3 bg-white rounded-3xl border border-[#E0D7C8]">
                <RefreshCw className="w-8 h-8 text-[#D4AF37] animate-spin mx-auto" />
                <p className="text-sm font-medium text-stone-600">Consultando almacén de AW Artisan España...</p>
              </div>
            ) : awProducts.length === 0 ? (
              <div className="py-16 text-center space-y-2 bg-white rounded-3xl border border-[#E0D7C8]">
                <p className="text-base font-serif font-bold text-stone-700">No se encontraron productos para esta búsqueda</p>
                <p className="text-xs text-stone-500">Prueba con palabras clave como cuarzo, incienso, difusor, amatista o salvia.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {awProducts.map((item) => {
                  const isAdded = awAddedIds.includes(item.id);
                  const isAdding = awAddingId === item.id;
                  const currentPrice = awCustomPrices[item.id] || item.suggestedRetail;
                  const currentIntention = awSelectedIntention[item.id] || "proteccion";
                  const currentCategory = awSelectedCategory[item.id] || "cuarzos-minerales";
                  const availableSubs = SUBCATEGORIES_MAP[currentCategory] || [];
                  const currentSubcategory = awSelectedSubcategory[item.id] || availableSubs[0] || "Minerales Auténticos";

                  return (
                    <div
                      key={item.id}
                      className="bg-white rounded-2xl border border-[#E0D7C8] overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-md transition-all"
                    >
                      <div>
                        {/* Image Preview */}
                        <div className="relative aspect-square w-full bg-[#FAF7F0] border-b border-[#E0D7C8] overflow-hidden">
                          {item.imageUrl ? (
                            <Image
                              src={item.imageUrl}
                              alt={item.name}
                              fill
                              sizes="(max-width: 768px) 100vw, 33vw"
                              className="object-contain p-4 hover:scale-105 transition-transform duration-500"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-stone-400 text-xs">
                              Sin fotografía
                            </div>
                          )}
                          <span className="absolute top-2.5 left-2.5 bg-black/70 text-white text-[10px] font-mono px-2 py-0.5 rounded-md backdrop-blur-xs">
                            {item.code}
                          </span>
                          <span className={`absolute top-2.5 right-2.5 text-[10px] font-bold px-2 py-0.5 rounded-full ${item.stock > 10 ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>
                            Stock: {item.stock} uds.
                          </span>
                        </div>

                        {/* Details */}
                        <div className="p-4 space-y-3">
                          <h3 className="font-serif text-sm font-bold text-[#1B1C1A] line-clamp-2 leading-snug">
                            {item.name}
                          </h3>

                          {/* Price Margins */}
                          <div className="flex items-center justify-between text-xs bg-[#FAF7F0] p-2.5 rounded-xl border border-[#E8E2D9]">
                            <div>
                              <span className="text-[10px] uppercase tracking-wider text-stone-400 block font-semibold">Coste Almacén</span>
                              <span className="font-bold text-stone-700">{item.wholesalePrice} €</span>
                            </div>
                            <div className="text-right">
                              <span className="text-[10px] uppercase tracking-wider text-emerald-600 block font-semibold">Tu PVP Venta</span>
                              <div className="flex items-center gap-1">
                                <input
                                  type="text"
                                  value={currentPrice}
                                  onChange={(e) =>
                                    setAwCustomPrices({ ...awCustomPrices, [item.id]: e.target.value })
                                  }
                                  className="w-16 px-1.5 py-0.5 rounded border border-[#D8C79E] text-xs font-bold text-emerald-800 text-right bg-white"
                                />
                                <span className="font-bold text-emerald-800">€</span>
                              </div>
                            </div>
                          </div>

                          {/* Category, Subcategory and Intention Selectors */}
                          <div className="space-y-2 text-[11px]">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="block text-[10px] text-stone-500 font-semibold mb-0.5">Categoría:</label>
                                <select
                                  value={currentCategory}
                                  onChange={(e) => {
                                    const newCat = e.target.value;
                                    setAwSelectedCategory({ ...awSelectedCategory, [item.id]: newCat });
                                    const subs = SUBCATEGORIES_MAP[newCat] || [];
                                    setAwSelectedSubcategory({ ...awSelectedSubcategory, [item.id]: subs[0] || "" });
                                  }}
                                  className="w-full px-2 py-1 rounded-lg border border-[#D8C79E] bg-white text-[11px] text-stone-700 font-medium"
                                >
                                  {CATEGORIES_LIST.map((c) => (
                                    <option key={c.id} value={c.id}>
                                      {c.name.split("&")[0].trim()}
                                    </option>
                                  ))}
                                </select>
                              </div>

                              <div>
                                <label className="block text-[10px] text-stone-500 font-semibold mb-0.5">Intención:</label>
                                <select
                                  value={currentIntention}
                                  onChange={(e) =>
                                    setAwSelectedIntention({ ...awSelectedIntention, [item.id]: e.target.value })
                                  }
                                  className="w-full px-2 py-1 rounded-lg border border-[#D8C79E] bg-white text-[11px] text-stone-700 font-medium"
                                >
                                  {INTENTIONS_LIST.map((int) => (
                                    <option key={int.id} value={int.id}>
                                      {int.name.split("&")[0].trim()}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            <div>
                              <label className="block text-[10px] text-stone-500 font-semibold mb-0.5">Subcategoría:</label>
                              <select
                                value={currentSubcategory}
                                onChange={(e) =>
                                  setAwSelectedSubcategory({ ...awSelectedSubcategory, [item.id]: e.target.value })
                                }
                                className="w-full px-2 py-1 rounded-lg border border-[#D8C79E] bg-white text-[11px] text-[#4A5D4E] font-medium"
                              >
                                {availableSubs.map((sub) => (
                                  <option key={sub} value={sub}>
                                    {sub}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Add Button */}
                      <div className="p-4 pt-0">
                        <button
                          onClick={() => handleAddAwProduct(item)}
                          disabled={isAdded || isAdding}
                          className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                            isAdded
                              ? "bg-emerald-100 text-emerald-800 border border-emerald-300 cursor-default"
                              : "bg-[#4A5D4E] hover:bg-[#38483B] text-white shadow-xs"
                          }`}
                        >
                          {isAdding ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              <span>Añadiendo a la tienda...</span>
                            </>
                          ) : isAdded ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>✓ En tu Tienda en Vivo</span>
                            </>
                          ) : (
                            <>
                              <PackagePlus className="w-3.5 h-3.5 text-[#D4AF37]" />
                              <span>➕ Añadir a mi Tienda en 1 Clic</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Pagination Controls */}
            {awTotal > 12 && (
              <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
                <button
                  onClick={() => searchAwCatalog(awSearch, 1)}
                  disabled={awPage === 1 || awLoading}
                  className="px-3 py-2 rounded-xl border border-[#D8C79E] bg-white text-xs font-semibold text-stone-700 hover:bg-[#F5F2EB] disabled:opacity-40 cursor-pointer"
                >
                  « Primera
                </button>
                <button
                  onClick={() => searchAwCatalog(awSearch, Math.max(1, awPage - 1))}
                  disabled={awPage === 1 || awLoading}
                  className="px-3.5 py-2 rounded-xl border border-[#D8C79E] bg-white text-xs font-semibold text-stone-700 hover:bg-[#F5F2EB] disabled:opacity-40 cursor-pointer"
                >
                  ‹ Anterior
                </button>
                <span className="text-xs text-stone-700 font-semibold px-3 py-2 bg-[#FAF7F0] border border-[#E0D7C8] rounded-xl">
                  Página {awPage} de {Math.ceil(awTotal / 12) || 1}
                </span>
                <button
                  onClick={() => searchAwCatalog(awSearch, awPage + 1)}
                  disabled={awPage * 12 >= awTotal || awLoading}
                  className="px-3.5 py-2 rounded-xl border border-[#D8C79E] bg-white text-xs font-semibold text-stone-700 hover:bg-[#F5F2EB] disabled:opacity-40 cursor-pointer"
                >
                  Siguiente ›
                </button>
                <button
                  onClick={() => searchAwCatalog(awSearch, Math.ceil(awTotal / 12))}
                  disabled={awPage >= Math.ceil(awTotal / 12) || awLoading}
                  className="px-3 py-2 rounded-xl border border-[#D8C79E] bg-white text-xs font-semibold text-stone-700 hover:bg-[#F5F2EB] disabled:opacity-40 cursor-pointer"
                >
                  Última »
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: AÑADIR PRODUCTO INDIVIDUAL (CON SUBCATEGORÍA) */}
        {activeTab === "form" && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E0D7C8] shadow-sm max-w-4xl space-y-6">
            <div>
              <h2 className="font-serif text-2xl font-bold text-[#1B1C1A]">
                Alta Rápida de Producto Manual / Nihao
              </h2>
              <p className="text-xs sm:text-sm text-[#5B675E] mt-1">
                Completa los datos esenciales. El producto se publicará al instante en el catálogo de Perla &amp; Pluma.
              </p>
            </div>

            <form onSubmit={handleSingleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    Nombre del Producto *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Pulsera de Ojo de Tigre con Dije en Plata de Ley"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    Subtítulo Espiritual
                  </label>
                  <input
                    type="text"
                    placeholder="Ej: Escudo Áurico &amp; Fuerza Interior"
                    value={formData.subtitle}
                    onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    Precio de Venta (€) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: 14.90"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    Categoría de Tienda
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => {
                      const newCat = e.target.value;
                      const subs = SUBCATEGORIES_MAP[newCat] || [];
                      setFormData({
                        ...formData,
                        category: newCat,
                        subcategory: subs[0] || "",
                      });
                    }}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] focus:outline-none focus:border-[#4A5D4E]"
                  >
                    {CATEGORIES_LIST.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    Subcategoría
                  </label>
                  <select
                    value={formData.subcategory}
                    onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] focus:outline-none focus:border-[#4A5D4E]"
                  >
                    {(SUBCATEGORIES_MAP[formData.category] || []).map((sub) => (
                      <option key={sub} value={sub}>
                        {sub}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    Intención Espiritual
                  </label>
                  <select
                    value={formData.intention}
                    onChange={(e) => setFormData({ ...formData, intention: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] focus:outline-none focus:border-[#4A5D4E]"
                  >
                    {INTENTIONS_LIST.map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    URL de la Imagen Principal (Pexels, Unsplash, AW o Nihao)
                  </label>
                  <input
                    type="text"
                    placeholder="https://images.pexels.com/..."
                    value={formData.primaryImage}
                    onChange={(e) => setFormData({ ...formData, primaryImage: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    Enlace Privado al Proveedor (AW Artisan, Nihao Jewelry o EPROLO)
                  </label>
                  <input
                    type="text"
                    placeholder="https://es.nihaojewelry.com/product/..."
                    value={formData.supplierUrl}
                    onChange={(e) => setFormData({ ...formData, supplierUrl: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                  />
                  <span className="text-[11px] text-stone-400 mt-1 block">
                    Solo visible para ti en el panel de pedidos para comprarlo con 1 clic al recibir una venta.
                  </span>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    Descripción Breve
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Breve frase que describe la esencia y energía del producto..."
                    value={formData.shortDescription}
                    onChange={(e) => setFormData({ ...formData, shortDescription: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3.5 px-6 rounded-2xl bg-[#4A5D4E] hover:bg-[#38483B] text-white text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
              >
                {submitting ? "Guardando..." : "Publicar Producto en Tienda"}
              </button>
            </form>
          </div>
        )}

        {/* TAB 4: IMPORTADOR DE TABLAS NOTEBOOKLM / EXCEL */}
        {activeTab === "batch" && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E0D7C8] shadow-sm max-w-4xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#1B1C1A]">
                  Importar Tabla de Productos
                </h2>
                <p className="text-xs sm:text-sm text-[#5B675E] mt-1">
                  Pega aquí la tabla generada por NotebookLM, una hoja de Excel, o un CSV copiado. El sistema detectará las columnas automáticamente.
                </p>
              </div>

              <button
                onClick={handleDownloadTemplate}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-[#D8C79E] bg-[#FAF7F0] text-xs font-medium text-[#4A5D4E] hover:bg-[#EAE3D6] transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Descargar Plantilla CSV</span>
              </button>
            </div>

            <div className="space-y-4">
              <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider">
                Pega la Tabla Aquí (Markdown, Tabulaciones o Comas):
              </label>
              <textarea
                rows={8}
                value={rawTableText}
                onChange={(e) => setRawTableText(e.target.value)}
                placeholder={`Nombre | Precio | Categoría | Subcategoría | Intención | Enlace Proveedor | Foto | Descripción
Vela de Miel Panal | 4.90 | Velas & Velones | Velas de Miel Natural | Amor Propio | https://... | https://... | Cera natural
Palo Santo Sagrado | 3.50 | Inciensos & Aromaterapia | Palo Santo & Salvia | Protección | https://... | https://... | Madera aromática`}
                className="w-full font-mono text-xs sm:text-sm px-4 py-3 rounded-2xl border border-[#D8C79E] bg-[#FAF7F0] text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
              />

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={handleParseBatch}
                  className="py-2.5 px-5 rounded-xl bg-[#4A5D4E] hover:bg-[#38483B] text-white text-xs sm:text-sm font-semibold transition-all flex items-center gap-2"
                >
                  <FileSpreadsheet className="w-4 h-4 text-[#D4AF37]" />
                  <span>Analizar y Previsualizar Tabla</span>
                </button>
              </div>
            </div>

            {/* PREVISUALIZACIÓN DE PRODUCTOS DETECTADOS */}
            {parsedBatch.length > 0 && (
              <div className="space-y-4 border-t border-[#E8E2D9] pt-6">
                <div className="flex items-center justify-between">
                  <h3 className="font-serif text-lg font-bold text-[#1B1C1A]">
                    Previsualización ({parsedBatch.length} artículos detectados)
                  </h3>
                  <button
                    type="button"
                    onClick={handleImportBatch}
                    disabled={submitting}
                    className="py-2.5 px-6 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-bold transition-all flex items-center gap-2 shadow-sm"
                  >
                    <Check className="w-4 h-4" />
                    <span>{submitting ? "Importando..." : "Confirmar e Importar Todos"}</span>
                  </button>
                </div>

                <div className="overflow-x-auto rounded-2xl border border-[#E0D7C8]">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-[#FAF7F0] border-b border-[#E0D7C8] text-stone-600 font-bold uppercase tracking-wider">
                      <tr>
                        <th className="p-3">Nombre</th>
                        <th className="p-3">Precio</th>
                        <th className="p-3">Categoría</th>
                        <th className="p-3">Subcategoría</th>
                        <th className="p-3">Intención</th>
                        <th className="p-3">Proveedor</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E0D7C8]">
                      {parsedBatch.map((item, idx) => (
                        <tr key={idx} className="hover:bg-[#FDFBF7]">
                          <td className="p-3 font-semibold text-stone-800">{item.name}</td>
                          <td className="p-3 text-emerald-700 font-bold">{item.price} €</td>
                          <td className="p-3 text-stone-600">{item.category}</td>
                          <td className="p-3 text-[#4A5D4E] font-medium">{item.subcategory}</td>
                          <td className="p-3 text-stone-600">{item.intention}</td>
                          <td className="p-3 text-stone-500 max-w-[200px] truncate">{item.supplierUrl || "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: CONEXIÓN PROVEEDORES */}
        {activeTab === "connections" && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E0D7C8] shadow-sm max-w-4xl space-y-8">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EAE3D6] text-xs font-semibold text-[#4A5D4E] uppercase tracking-wider mb-2">
                <Truck className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Enlace Directo con Almacenes</span>
              </div>
              <h2 className="font-serif text-2xl font-bold text-[#1B1C1A]">
                Conexión Automática con AW Dropship y EPROLO
              </h2>
              <p className="text-xs sm:text-sm text-[#5B675E] mt-1 leading-relaxed">
                Tus claves de API activas. Cada vez que un cliente pague un pedido en Perla &amp; Pluma, el sistema enviará automáticamente la orden y la dirección de envío al almacén del proveedor para que ellos preparen y manden el paquete.
              </p>
            </div>

            <form onSubmit={handleSaveSupplierSettings} className="space-y-6">
              {/* AW DROPSHIP */}
              <div className="p-5 rounded-2xl bg-[#FAF7F0] border border-[#E0D7C8] space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
                    <h3 className="font-serif text-base font-bold text-[#1B1C1A]">
                      1. AW Dropship España (Ancient Wisdom / aiku.io)
                    </h3>
                  </div>
                  <span className={`text-[11px] font-bold px-3 py-1 rounded-full w-fit ${supplierConfig.hasAwToken ? "bg-emerald-100 text-emerald-800" : "bg-stone-200 text-stone-600"}`}>
                    {supplierConfig.hasAwToken ? `✓ Conectado (${supplierConfig.awTokenMasked || "Activo"})` : "Pendiente de Token"}
                  </span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Conforme a la documentación oficial (<code>api.aiku.io/dropshipping/clients</code>), este Bearer Token permite que tu tienda registre automáticamente al comprador y genere la orden de envío en AW Dropship con empaque neutro sin que tengas que intervenir.
                </p>
                <div>
                  <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                    Token de API (Bearer Token de AW Dropship):
                  </label>
                  <input
                    type="password"
                    placeholder="Pega aquí tu Bearer Token (ej: 910|39iPxfpRJo...)"
                    value={supplierConfig.awToken}
                    onChange={(e) => setSupplierConfig({ ...supplierConfig, awToken: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                  />
                  <span className="text-[11px] text-stone-400 mt-1 block">
                    {supplierConfig.hasAwToken ? "Token guardado en el servidor con éxito." : "Obtenlo en tu panel de aw-dropship.es > Canales > Canal Manual / API > Tokens."}
                  </span>
                </div>
              </div>

              {/* EPROLO */}
              <div className="p-5 rounded-2xl bg-[#FAF7F0] border border-[#E0D7C8] space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                    <h3 className="font-serif text-base font-bold text-[#1B1C1A]">
                      2. EPROLO API
                    </h3>
                  </div>
                  <span className={`text-[11px] font-bold px-3 py-1 rounded-full w-fit ${supplierConfig.hasEproloKey ? "bg-blue-100 text-blue-800" : "bg-stone-200 text-stone-600"}`}>
                    {supplierConfig.hasEproloKey ? "✓ API Key Conectada" : "Pendiente de Clave"}
                  </span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Permite transmitir automáticamente los pedidos a la red de fulfillment de EPROLO y recibir el número de seguimiento de envío en vivo.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                      EPROLO API Key:
                    </label>
                    <input
                      type="password"
                      placeholder="Tu API Key de Eprolo"
                      value={supplierConfig.eproloKey}
                      onChange={(e) => setSupplierConfig({ ...supplierConfig, eproloKey: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[#38433C] uppercase tracking-wider mb-1.5">
                      EPROLO API Secret:
                    </label>
                    <input
                      type="password"
                      placeholder="Tu Secret de Eprolo"
                      value={supplierConfig.eproloSecret}
                      onChange={(e) => setSupplierConfig({ ...supplierConfig, eproloSecret: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-[#D8C79E] bg-white text-sm text-[#1B1C1A] placeholder-stone-400 focus:outline-none focus:border-[#4A5D4E]"
                    />
                  </div>
                </div>
              </div>

              {/* NIHAO JEWELRY INFO */}
              <div className="p-5 rounded-2xl bg-[#FAF7F0] border border-[#E0D7C8] space-y-2">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-purple-500"></span>
                  <h3 className="font-serif text-base font-bold text-[#1B1C1A]">
                    3. Nihao Jewelry (Piedras Naturales y Joyería)
                  </h3>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Nihao Jewelry no requiere clave de API. Al añadir un producto desde el formulario rápido o desde la tabla de NotebookLM, puedes guardar el enlace directo al artículo en Nihao. Cuando recibas un pedido, el sistema te mostrará el botón de enlace directo para tramitarlo en 1 clic.
                </p>
              </div>

              <button
                type="submit"
                disabled={savingConfig}
                className="w-full py-3.5 px-6 rounded-2xl bg-[#4A5D4E] hover:bg-[#38483B] text-white text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
              >
                {savingConfig ? "Guardando..." : "Guardar y Conectar Proveedores"}
              </button>
            </form>
          </div>
        )}
      </div>
    </main>
  );
}
