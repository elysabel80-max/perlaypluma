import { NextResponse } from "next/server";
import https from "https";
import { getSupplierSettings } from "@/lib/awDropship";

export const dynamic = "force-dynamic";

function httpsRequest(urlStr: string, options: { method?: string; headers?: Record<string, string>; body?: string } = {}): Promise<{ status: number; text: string; data: any }> {
  return new Promise((resolve, reject) => {
    const url = new URL(urlStr);
    const agent = new https.Agent({ rejectUnauthorized: false });
    const reqOptions = {
      method: options.method || "GET",
      hostname: url.hostname,
      port: url.port ? Number(url.port) : 443,
      path: url.pathname + url.search,
      headers: options.headers || {},
      agent,
    };

    const req = https.request(reqOptions, (res) => {
      let raw = "";
      res.on("data", (chunk) => (raw += chunk));
      res.on("end", () => {
        let parsed: any = null;
        try {
          parsed = JSON.parse(raw);
        } catch {
          parsed = null;
        }
        resolve({
          status: res.statusCode || 500,
          text: raw,
          data: parsed,
        });
      });
    });

    req.on("error", (err) => reject(err));
    if (options.body) {
      req.write(options.body);
    }
    req.end();
  });
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("q") || searchParams.get("search") || "";
    const page = searchParams.get("page") || "1";
    const perPage = searchParams.get("per_page") || "12";

    const settings = getSupplierSettings();
    const token = settings.awToken || process.env.AW_DROPSHIP_API_TOKEN;

    if (!token) {
      return NextResponse.json({
        success: false,
        message: "No se ha configurado el Token de AW Dropship. Ve a la pestaña 'Conexión Proveedores'.",
        products: [],
      });
    }

    const apiUrl = new URL("https://api.aiku.io/dropshipping/products");
    if (search.trim()) {
      apiUrl.searchParams.set("search", search.trim());
    }
    apiUrl.searchParams.set("page", page);
    apiUrl.searchParams.set("per_page", perPage);

    const res = await httpsRequest(apiUrl.toString(), {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token.trim()}`,
        Accept: "application/json",
      },
    });

    if (res.status < 200 || res.status >= 300) {
      return NextResponse.json(
        { success: false, message: `Error del proveedor (${res.status})`, error: res.text },
        { status: res.status }
      );
    }

    const data = res.data || {};
    const rawItems = Array.isArray(data.data) ? data.data : [];

    const products = rawItems.map((item: any) => {
      const wholesalePrice = parseFloat(item.price) || 0;
      // Recommended retail margin: 2.2x wholesale + 2€
      const suggestedRetail = (wholesalePrice * 2.2 + 2).toFixed(2);

      const imageUrl =
        item.image?.original_2x ||
        item.image?.original ||
        item.image?.png_2x ||
        item.image?.png ||
        item.image?.webp ||
        "";

      const cleanDesc = (item.description || "")
        .replace(/<[^>]+>/g, " ")
        .replace(/\s+/g, " ")
        .trim();

      return {
        id: item.id,
        code: item.code,
        name: item.name,
        wholesalePrice: wholesalePrice.toFixed(2),
        suggestedRetail,
        stock: item.current_stock || 0,
        imageUrl,
        barcode: item.ean_barcode || "",
        shortDescription: cleanDesc.slice(0, 160) + (cleanDesc.length > 160 ? "..." : ""),
        fullDescription: item.description || cleanDesc,
        weight: item.gross_weight || 0,
        slug: item.slug || item.code?.toLowerCase(),
      };
    });

    return NextResponse.json({
      success: true,
      total: data.meta?.total !== undefined ? data.meta.total : products.length,
      currentPage: data.meta?.current_page || Number(page),
      lastPage: data.meta?.last_page || Math.ceil((data.meta?.total || products.length) / Number(perPage)),
      products,
    });
  } catch (error) {
    console.error("Error in /api/aw/products:", error);
    return NextResponse.json(
      { success: false, message: "Error interno al conectar con AW Dropship", error: String(error) },
      { status: 500 }
    );
  }
}
