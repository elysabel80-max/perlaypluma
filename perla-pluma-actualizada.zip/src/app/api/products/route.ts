import { NextResponse } from "next/server";
import { getAllProducts, readDeletedSlugsFromFile, saveDeletedSlugsToFile } from "@/lib/catalog";
import fs from "fs";
import path from "path";
import { db, hasDatabaseUrl } from "@/db";
import { products } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";

export const dynamic = "force-dynamic";

function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\w-]+/g, "")
    .replace(/--+/g, "-");
}

function getCustomProductsFile(): string {
  return path.join(process.cwd(), "src", "data", "customProducts.json");
}

function readCustomProducts(): any[] {
  try {
    const file = getCustomProductsFile();
    if (fs.existsSync(file)) {
      const data = fs.readFileSync(file, "utf-8");
      return JSON.parse(data || "[]");
    }
  } catch (err) {
    console.error("Error reading customProducts.json:", err);
  }
  return [];
}

function saveCustomProducts(list: any[]) {
  const file = getCustomProductsFile();
  fs.writeFileSync(file, JSON.stringify(list, null, 2), "utf-8");
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const intention = searchParams.get("intention");
    const search = searchParams.get("q");
    const subcategory = searchParams.get("subcategory");

    let results = await getAllProducts();

    if (category) {
      results = results.filter((p) => p.category === category);
    }
    if (intention) {
      results = results.filter((p) => p.intention === intention);
    }
    if (subcategory) {
      results = results.filter((p) => p.subcategory === subcategory);
    }
    if (search) {
      const q = search.toLowerCase();
      results = results.filter((p) =>
        [p.name, p.subtitle, p.shortDescription, p.categoryName, p.subcategory]
          .filter(Boolean)
          .some((field) => field!.toLowerCase().includes(q))
      );
    }

    return NextResponse.json({
      success: true,
      products: results,
      total: results.length,
    });
  } catch (error) {
    console.error("GET /api/products error:", error);
    return NextResponse.json(
      { success: false, message: "Error al obtener los productos", products: [] },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const items = Array.isArray(body) ? body : [body];
    const existing = readCustomProducts();
    const created: any[] = [];

    for (const item of items) {
      if (!item.name || !item.price) continue;

      const baseSlug = item.slug ? slugify(item.slug) : slugify(item.name);
      let uniqueSlug = baseSlug;
      let counter = 1;
      while (existing.some((p: any) => p.slug === uniqueSlug)) {
        uniqueSlug = `${baseSlug}-${counter++}`;
      }

      const newProd = {
        slug: uniqueSlug,
        name: item.name.trim(),
        subtitle: item.subtitle || "Pieza seleccionada para Perla & Pluma",
        category: item.category || "cuarzos-minerales",
        categoryName: item.categoryName || "Cuarzos & Minerales",
        subcategory: item.subcategory || "Minerales Auténticos",
        intention: item.intention || "proteccion",
        price: typeof item.price === "number" ? item.price.toFixed(2) : String(item.price).replace(",", "."),
        originalPrice: item.originalPrice ? (typeof item.originalPrice === "number" ? item.originalPrice.toFixed(2) : String(item.originalPrice).replace(",", ".")) : null,
        rating: item.rating || "4.95",
        reviewsCount: item.reviewsCount || 1,
        stock: item.stock ? Number(item.stock) : 10,
        isFeatured: Boolean(item.isFeatured),
        isBestseller: Boolean(item.isBestseller),
        isNewArrival: true,
        primaryImage: item.primaryImage || item.image || "/images/hero-retiro.jpg",
        detailImage: item.detailImage || item.primaryImage || item.image || "/images/hero-retiro.jpg",
        contextImage: item.contextImage || item.primaryImage || item.image || "/images/hero-retiro.jpg",
        shortDescription: item.shortDescription || item.description || "Pieza ritualizada de alta vibración.",
        fullDescription: item.fullDescription || item.description || "Selección artesanal purificada para acompañarte en tus rituales y armonizar tu espacio.",
        supplierUrl: item.supplierUrl || item.enlace || item.proveedor || "",
        supplierName: item.supplierName || item.proveedor_nombre || "",
        createdAt: new Date().toISOString(),
      };

      existing.push(newProd);
      created.push(newProd);

      // If Postgres DB is configured and reachable
      if (hasDatabaseUrl()) {
        try {
          await db.insert(products).values({
            slug: newProd.slug,
            name: newProd.name,
            subtitle: newProd.subtitle,
            category: newProd.category,
            categoryName: newProd.categoryName,
            subcategory: newProd.subcategory,
            intention: newProd.intention,
            price: newProd.price,
            originalPrice: newProd.originalPrice,
            rating: newProd.rating,
            reviewsCount: newProd.reviewsCount,
            stock: newProd.stock,
            isFeatured: newProd.isFeatured,
            isBestseller: newProd.isBestseller,
            isNewArrival: newProd.isNewArrival,
            primaryImage: newProd.primaryImage,
            detailImage: newProd.detailImage,
            contextImage: newProd.contextImage,
            shortDescription: newProd.shortDescription,
            fullDescription: newProd.fullDescription,
            createdAt: new Date(),
          });
        } catch (dbErr) {
          console.warn("DB insert bypassed; saved to local catalog file:", dbErr);
        }
      }
    }

    saveCustomProducts(existing);

    return NextResponse.json({
      success: true,
      message: `¡${created.length} producto(s) guardado(s) exitosamente en el catálogo!`,
      products: created,
    });
  } catch (error) {
    console.error("POST /api/products error:", error);
    return NextResponse.json(
      { success: false, message: "Error al guardar los productos" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { slug, price, category, categoryName, subcategory, intention, stock } = body;

    if (!slug) {
      return NextResponse.json({ success: false, message: "El slug es obligatorio" }, { status: 400 });
    }

    const existing = readCustomProducts();
    const index = existing.findIndex((p: any) => p.slug === slug);

    if (index >= 0) {
      existing[index] = {
        ...existing[index],
        ...(price !== undefined && { price: String(price).replace(",", ".") }),
        ...(category !== undefined && { category }),
        ...(categoryName !== undefined && { categoryName }),
        ...(subcategory !== undefined && { subcategory }),
        ...(intention !== undefined && { intention }),
        ...(stock !== undefined && { stock: Number(stock) }),
        updatedAt: new Date().toISOString(),
      };
    } else {
      const all = await getAllProducts();
      const orig = all.find((p) => p.slug === slug);
      if (orig) {
        existing.push({
          ...orig,
          ...(price !== undefined && { price: String(price).replace(",", ".") }),
          ...(category !== undefined && { category }),
          ...(categoryName !== undefined && { categoryName }),
          ...(subcategory !== undefined && { subcategory }),
          ...(intention !== undefined && { intention }),
          ...(stock !== undefined && { stock: Number(stock) }),
          updatedAt: new Date().toISOString(),
        });
      }
    }

    saveCustomProducts(existing);

    if (hasDatabaseUrl()) {
      try {
        await db
          .update(products)
          .set({
            ...(price !== undefined && { price: String(price).replace(",", ".") }),
            ...(category !== undefined && { category }),
            ...(categoryName !== undefined && { categoryName }),
            ...(subcategory !== undefined && { subcategory }),
            ...(intention !== undefined && { intention }),
            ...(stock !== undefined && { stock: Number(stock) }),
          })
          .where(eq(products.slug, slug));
      } catch (err) {
        console.warn("Could not update in DB, updated in local JSON:", err);
      }
    }

    return NextResponse.json({
      success: true,
      message: "Producto actualizado correctamente",
    });
  } catch (err) {
    console.error("PATCH /api/products error:", err);
    return NextResponse.json({ success: false, message: "Error al actualizar" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const body = await request.json();
    const slugsToDelete: string[] = Array.isArray(body?.slugs)
      ? body.slugs
      : body?.slug
      ? [body.slug]
      : [];

    if (slugsToDelete.length === 0) {
      return NextResponse.json({ success: false, message: "No se proporcionaron artículos para eliminar." }, { status: 400 });
    }

    // 1. Remove from customProducts.json
    const custom = readCustomProducts();
    const updatedCustom = custom.filter((p: any) => !slugsToDelete.includes(p.slug));
    saveCustomProducts(updatedCustom);

    // 2. Add to deletedProducts.json so seed items are also hidden/deleted
    const currentDeleted = readDeletedSlugsFromFile();
    const mergedDeleted = Array.from(new Set([...currentDeleted, ...slugsToDelete]));
    saveDeletedSlugsToFile(mergedDeleted);

    // 3. Remove from PostgreSQL if connected
    if (hasDatabaseUrl()) {
      try {
        await db.delete(products).where(inArray(products.slug, slugsToDelete));
      } catch (err) {
        console.warn("Could not delete in DB, marked in local JSON:", err);
      }
    }

    return NextResponse.json({
      success: true,
      message: `Se han eliminado ${slugsToDelete.length} artículos del inventario correctamente.`,
      deletedCount: slugsToDelete.length,
    });
  } catch (err) {
    console.error("DELETE /api/products error:", err);
    return NextResponse.json({ success: false, message: "Error al eliminar productos" }, { status: 500 });
  }
}

