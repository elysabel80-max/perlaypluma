import type { Metadata } from "next";
import "./globals.css";
import { CartProvider } from "@/context/CartContext";
import { MembershipProvider } from "@/context/MembershipContext";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { CartDrawer } from "@/components/CartDrawer";

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL || "https://perlaypluma.com"
  ),
  title: {
    default: "Perla & Pluma | Tienda Esotérica & Misticismo Contemporáneo",
    template: "%s | Perla & Pluma",
  },
  description:
    "Tienda esotérica contemporánea: velas de cera pura de abeja, minerales seleccionados con rigor técnico, inciensos naturales y kits de rituales consagrados para tu bienestar.",
  keywords: [
    "tienda esotérica",
    "velas de miel",
    "cuarzos naturales",
    "inciensos artesanales",
    "kits de rituales",
    "tarot",
    "gemoterapia",
  ],
  openGraph: {
    type: "website",
    locale: "es_ES",
    siteName: "Perla & Pluma",
    title: "Perla & Pluma | Misticismo Contemporáneo",
    description:
      "Velas de cera pura, minerales auténticos, inciensos éticos y kits rituales empaquetados con mimo.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-sans antialiased text-[#2B352E] selection:bg-[#4A5D4E]/20 selection:text-[#242B26] min-h-screen flex flex-col">
        <MembershipProvider>
          <CartProvider>
            <Header />
            <main className="flex-1">{children}</main>
            <Footer />
            <CartDrawer />
          </CartProvider>
        </MembershipProvider>
      </body>
    </html>
  );
}
