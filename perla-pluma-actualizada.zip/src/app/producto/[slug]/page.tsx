"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useCart } from "@/context/CartContext";
import { ProductCard } from "@/components/ProductCard";
import {
  Sparkles,
  ShoppingBag,
  Star,
  Check,
  Shield,
  Feather,
  Sun,
  Heart,
  Moon,
  Info,
  Flame,
  Wind,
  Layers,
  Award,
  Box,
  Gift,
  AlertCircle,
  ArrowLeft,
} from "lucide-react";

export default function ProductDetailPage() {
  const params = useParams();
  const slug = params?.slug as string;

  const { addItem } = useCart();
  const [product, setProduct] = useState<any>(null);
  const [reviewsList, setReviewsList] = useState<any[]>([]);
  const [relatedList, setRelatedList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState<string>("");
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const [activeTab, setActiveTab] = useState<"ritual" | "details" | "reviews">("ritual");

  useEffect(() => {
    async function loadProduct() {
      if (!slug) return;
      setLoading(true);
      try {
        const res = await fetch(`/api/products/${slug}`);
        const data = await res.json();
        if (data.success) {
          setProduct(data.product);
          setReviewsList(data.reviews || []);
          setRelatedList(data.related || []);
          setActiveImage(data.product.primaryImage);
        }
      } catch (err) {
        console.error("Error loading product detail", err);
      } finally {
        setLoading(false);
      }
    }
    loadProduct();
  }, [slug]);

  if (loading) {
    return (
      <div className="py-32 text-center space-y-4">
        <Sparkles className="w-10 h-10 text-[#D4AF37] animate-spin mx-auto" />
        <p className="font-serif text-stone-600 text-sm">Consultando los registros sagrados de Perla & Pluma...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="py-24 max-w-md mx-auto text-center space-y-4 px-4">
        <h2 className="font-serif text-2xl text-stone-800">Pieza no encontrada</h2>
        <p className="text-xs text-stone-600">
          Esta pieza no existe o ha cambiado de plano en nuestro catálogo.
        </p>
        <Link
          href="/catalogo"
          className="inline-block bg-[#4A5D4E] text-[#FDFBF7] px-5 py-2.5 rounded-lg text-xs font-medium"
        >
          Volver al Catálogo
        </Link>
      </div>
    );
  }

  const numPrice = typeof product.price === "string" ? parseFloat(product.price) : product.price;
  const numOriginal = product.originalPrice
    ? typeof product.originalPrice === "string"
      ? parseFloat(product.originalPrice)
      : product.originalPrice
    : null;

  const handleAddToCart = () => {
    addItem(product, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const galleryImages = [
    product.primaryImage,
    product.detailImage,
    product.contextImage,
  ].filter(Boolean);

  const getIntentionBadge = (intention: string) => {
    switch (intention) {
      case "proteccion":
        return { label: "Protección & Limpieza", icon: <Shield className="w-3.5 h-3.5" />, bg: "bg-stone-100 text-stone-800" };
      case "calma":
        return { label: "Calma & Serenidad", icon: <Feather className="w-3.5 h-3.5" />, bg: "bg-emerald-50 text-emerald-900" };
      case "abundancia":
        return { label: "Abundancia & Prosperidad", icon: <Sun className="w-3.5 h-3.5" />, bg: "bg-amber-50 text-amber-900" };
      case "amor":
        return { label: "Amor Propio & Relaciones", icon: <Heart className="w-3.5 h-3.5" />, bg: "bg-rose-50 text-rose-900" };
      case "intuicion":
        return { label: "Intuición & Conexión", icon: <Moon className="w-3.5 h-3.5" />, bg: "bg-violet-50 text-violet-900" };
      default:
        return { label: "Intención Sagrada", icon: <Sparkles className="w-3.5 h-3.5" />, bg: "bg-stone-100 text-stone-800" };
    }
  };

  const badge = getIntentionBadge(product.intention);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-14 space-y-16">
      {/* Back button & Breadcrumbs */}
      <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 font-sans">
        <Link href="/catalogo" className="hover:text-stone-800 flex items-center gap-1">
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Catálogo</span>
        </Link>
        <span>/</span>
        <Link href={`/catalogo?category=${product.category}`} className="hover:text-stone-800">
          {product.categoryName}
        </Link>
        <span>/</span>
        <span className="text-stone-800 font-medium truncate max-w-xs">{product.name}</span>
      </div>

      {/* Main Product Hero Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
        {/* Left: Gallery (Col 7) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Main big image view */}
          <div className="relative aspect-square sm:aspect-4/3 rounded-3xl overflow-hidden bg-[#F2ECE1] border border-[#E8E2D9] shadow-sm">
            <Image
              src={activeImage || product.primaryImage}
              alt={product.name}
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 55vw"
              className="object-cover transition-all duration-300"
            />
            {/* Top Intention pill */}
            <div className="absolute top-4 left-4 flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-serif shadow-xs backdrop-blur-xs bg-white/90 border border-white/40">
              {badge.icon}
              <span className="font-medium">{badge.label}</span>
            </div>

            {/* Sello de Garantía Ritual */}
            <div className="absolute bottom-4 right-4 bg-[#242B26]/85 backdrop-blur-md text-[#FDFBF7] px-3.5 py-1.5 rounded-full text-[11px] font-sans flex items-center gap-1.5 shadow-md">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Pieza energizada en altar antes del envío</span>
            </div>
          </div>

          {/* Thumbnails */}
          <div className="grid grid-cols-3 gap-3">
            {galleryImages.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImage(img)}
                className={`relative aspect-square rounded-xl overflow-hidden bg-stone-100 border-2 transition-all ${
                  activeImage === img
                    ? "border-[#4A5D4E] scale-98 shadow-sm"
                    : "border-transparent opacity-80 hover:opacity-100"
                }`}
              >
                <Image
                  src={img}
                  alt={`${product.name} detalle ${idx + 1}`}
                  fill
                  sizes="120px"
                  className="object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Right: Info & Purchase (Col 5) */}
        <div className="lg:col-span-5 space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs uppercase font-sans tracking-widest text-[#D4AF37] font-semibold">
                {product.subcategory}
              </span>
              {product.mysticLevel && (
                <span className="text-[10px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md border border-stone-200">
                  Nivel: {product.mysticLevel}
                </span>
              )}
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl text-[#242B26] font-normal leading-tight">
              {product.name}
            </h1>

            <p className="text-sm text-[#5B675E] mt-2 font-serif italic">
              {product.subtitle}
            </p>

            {/* Rating summary */}
            <div className="flex items-center gap-2 mt-3 text-xs">
              <div className="flex items-center text-[#D4AF37]">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#D4AF37]" />
                ))}
              </div>
              <span className="font-semibold text-stone-800">{product.rating || "4.95"}</span>
              <span className="text-stone-400">({product.reviewsCount || 24} valoraciones en altar)</span>
            </div>
          </div>

          {/* Price */}
          <div className="p-4 bg-[#FAF7F0] rounded-2xl border border-[#E8E2D9] flex items-baseline justify-between">
            <div className="flex items-baseline gap-3">
              <span className="font-serif text-3xl font-bold text-[#242B26]">
                {numPrice.toFixed(2)} €
              </span>
              {numOriginal && (
                <span className="text-sm text-stone-400 line-through">
                  {numOriginal.toFixed(2)} €
                </span>
              )}
            </div>
            <span className="text-xs text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 font-medium">
              En stock ({product.stock} disponibles)
            </span>
          </div>

          {/* Short description */}
          <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
            {product.shortDescription}
          </p>

          {/* Purchase Controls */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-3">
              {/* Quantity selector */}
              <div className="flex items-center border border-[#DDD3C3] rounded-xl bg-[#FAF7F0] p-1">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="w-8 h-8 rounded-lg hover:bg-stone-200 flex items-center justify-center text-stone-700 font-semibold"
                  aria-label="Restar uno"
                >
                  -
                </button>
                <span className="w-10 text-center text-xs font-semibold">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => q + 1)}
                  className="w-8 h-8 rounded-lg hover:bg-stone-200 flex items-center justify-center text-stone-700 font-semibold"
                  aria-label="Sumar uno"
                >
                  +
                </button>
              </div>

              {/* Add to Cart Main Button */}
              <button
                onClick={handleAddToCart}
                className={`flex-1 py-3.5 px-6 rounded-xl font-medium text-xs tracking-wider uppercase transition-all shadow-md flex items-center justify-center gap-2 ${
                  added
                    ? "bg-emerald-700 text-white"
                    : "bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7]"
                }`}
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>¡Añadido a tu altar de compra!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>Añadir a la Cesta • {(numPrice * quantity).toFixed(2)} €</span>
                  </>
                )}
              </button>
            </div>

            <div className="text-[11px] text-stone-500 text-center flex items-center justify-center gap-2 pt-1">
              <span>✨ Envío peninsular</span>
              <span>•</span>
              <span>🌿 Empaque 100% biodegradable</span>
              <span>•</span>
              <span>🕯️ Detalle de regalo a partir de 5 €</span>
            </div>
          </div>

          {/* Informative Highlights per Design Guide */}
          <div className="border-t border-[#E8E2D9] pt-5 space-y-3">
            {/* Mineral Authenticity if available */}
            {product.mineralAuthenticity && (
              <div className="flex items-start gap-2.5 p-3 bg-[#F4EFE6] rounded-xl border border-[#DFD6C6]">
                <Award className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-semibold text-stone-900 block">Sello de Autenticidad Mineral:</span>
                  <p className="text-stone-600 text-[11px]">{product.mineralAuthenticity}</p>
                </div>
              </div>
            )}

            {/* Ethical Commitment if available */}
            {product.ethicalCommitment && (
              <div className="flex items-start gap-2.5 p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                <Feather className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-semibold text-emerald-950 block">Compromiso Ético & Sostenible:</span>
                  <p className="text-emerald-800 text-[11px]">{product.ethicalCommitment}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* DETAILED INFORMATION BLOCKS - Categorías adaptadas al Blueprint de Arquitectura E-Commerce Mística (Páginas 8-12) */}
      {(() => {
        // Fallbacks según los Requisitos de Ficha del documento Arquitectura E-Commerce Mística
        const propositoSimbolismo =
          product.propositoSimbolismo ||
          (product.intention === "calma"
            ? "Vela de vibración suave y serena. Su tono y luz están consagrados para pacificar la mente, aliviar tensiones cotidianas y favorecer un descanso profundo."
            : product.intention === "abundancia"
            ? "Llama de apertura y prosperidad. Su energía lumínica está sintonizada para activar el flujo del merecimiento, despejar bloqueos laborales y atraer oportunidades."
            : product.intention === "amor"
            ? "Vela consagrada para el amor propio y la calidez emocional. Su resplandor reconforta el corazón, disuelve la autoexigencia y armoniza el hogar."
            : product.intention === "intuicion"
            ? "Llama de visión interior y conexión sagrada. Ideada como faro en momentos de meditación, lectura de oráculos o recogimiento reflexivo."
            : "Vela consagrada para la protección y purificación energética. Su fuego transmuta cargas acumuladas y crea un cerco de luz segura en tu espacio sagrado.");

        const composicionVela =
          product.composicion ||
          "Garantía de cera natural vegetal purificada (soja / abeja) de combustión limpia y prolongada. Mecha de algodón 100% trenzado sin plomo ni humos tóxicos para preservar la pureza del aire.";

        const modoDeUsoVela =
          product.modoDeUso ||
          "Coloca la vela sobre una superficie ignífuga. Corta la mecha a unos 5 mm antes de cada encendido. Enciende siempre con cerilla de madera sosteniendo tu propósito en silencio. Deja que la capa superior de cera se funda hasta el borde en el primer encendido para evitar el efecto túnel. Nunca dejes una llama encendida sin supervisión.";

        const guiaLecturaVela =
          product.guiaLecturaLlama ||
          "Llama alta, viva y erguida: tu intención fluye con fuerza y sin obstáculos. Llama vacilante o chisporroteo inicial: el fuego está limpiando y disipando densidades del ambiente; déjala estabilizarse. Llama baja y quieta: momento de introspección y paciencia; la energía actúa en planos sutiles. Cera que consume de forma limpia y simétrica: ritual en perfecta armonía.";

        const notasAromaticas =
          product.aromaticNotes ||
          (product.name.toLowerCase().includes("rosa")
            ? "Perfil floral dulce y delicado, con notas sutiles de pétalos silvestres y fondo aterciopelado reconfortante."
            : product.name.toLowerCase().includes("lavanda")
            ? "Perfil herbal fresco, balsámico y agreste con fondo relajante de flores de montaña."
            : product.name.toLowerCase().includes("sandalo") || product.name.toLowerCase().includes("sándalo")
            ? "Perfil amaderado cálido, dulce y terroso con matices orientales profundos y envolventes."
            : product.name.toLowerCase().includes("salvia")
            ? "Perfil herbal penetrante, limpio y alcanforado con efecto refrescante y purificador."
            : product.name.toLowerCase().includes("palo santo")
            ? "Perfil resinoso amaderado, dulce y cítrico con notas de incienso sagrado ancestral."
            : "Perfil botánico natural, resinoso y equilibrado, libre de fijadores químicos invasivos.");

        const efectoEnergetico =
          product.energeticEffect ||
          (product.intention === "calma"
            ? "Serenidad inmediata, distensión del sistema nervioso y atmósfera idónea para la meditación y el descanso nocturno."
            : product.intention === "abundancia"
            ? "Elevación del estado de ánimo, claridad de enfoque y reactivación del optimismo y la motivación creativa."
            : product.intention === "amor"
            ? "Apertura emocional, sensación de calidez afectiva, autocuidado y armonización del espacio íntimo."
            : product.intention === "intuicion"
            ? "Apertura del tercer ojo, silencio mental y estado receptivo para prácticas de oráculo o recogimiento."
            : "Purificación profunda del campo áurico y estancias; despeje de miasmas y renovación vibratoria del aire.");

        const compromisoEtico =
          product.ethicalCommitment ||
          "Ingredientes botánicos 100% de origen natural, resinas puras y maderas recolectadas de forma ética y sostenible (especialmente en palo santo de recolección de caída natural). Sin aceites minerales sintéticos ni pegamentos industriales.";

        const garantiaAutenticidad =
          product.mineralAuthenticity ||
          "Sello de Garantía: Mineral 100% Auténtico de Origen Natural. Sin tintes artificiales, resinas ni tratamientos sintéticos de laboratorio. Cada pieza ha sido seleccionada de forma individual, limpiada y energetizada en altar antes de su expedición.";

        const propiedadesGemoterapeuticas =
          product.gemotherapyProperties ||
          (product.intention === "calma"
            ? "Piedra sintonizada para emitir una vibración de sosiego que apacigua el estrés mental y absorbe la agitación emocional."
            : product.intention === "abundancia"
            ? "Cristal de alta frecuencia que estimula la determinación, el dinamismo y la atracción de prosperidad tangible."
            : product.intention === "amor"
            ? "Gema que vibra en la frecuencia del chakra corazón; promueve la reconciliación interior, la autoestima y la dulzura en los vínculos."
            : product.intention === "intuicion"
            ? "Canaliza y estabiliza las percepciones sutiles, facilitando el recogimiento meditativo y la confianza en tu propia sabiduría interna."
            : "Escudo protector bioenergético que dispersa densidades psíquicas del entorno y mantiene tu campo áurico en equilibrio.");

        const guiaMantenimiento =
          product.cleansingRechargeGuide ||
          "Instrucciones estrictas de mantenimiento: Para limpieza, pasa la pieza por el humo de salvia blanca o palo santo durante un minuto, o deposítala sobre una placa de selenita. (Atención: evitar sumergir en agua con sal minerales porosos o con inclusiones metálicas para evitar deterioro). Para recargar: Coloca la gema bajo la luz de la Luna Llena o al sol suave del amanecer durante una hora.";

        const contenidoDesglosado =
          product.kitContents && Array.isArray(product.kitContents) && product.kitContents.length > 0
            ? product.kitContents
            : [
                "1x Elemento principal consagrado para el ritual",
                "1x Herramienta de sahumado y limpieza inicial",
                "1x Vela de encendido intencionado con cerilla ritual",
                "1x Mineral natural sintonizado de apoyo energético",
                "1x Guía física impresa exclusiva explicada paso a paso",
              ];

        const presentacionKit =
          product.presentation ||
          "Presentación en caja rígida artesanal eco-sostenible, protegida con papel de seda vegetal, sellada con cinta natural y acompañada de un sutil aroma de altar. Lista para regalar o convertirla en tu propio santuario de práctica personal.";

        const nivelRecomendado =
          product.mysticLevel || "Apto para todos los niveles (Iniciación, Práctica Regular y Avanzado)";

        const guiaConsagracion =
          product.consecrationGuide ||
          "Antes del primer uso, pasa la herramienta tres veces en sentido horario por el humo de incienso puro o salvia blanca. Sostenla entre tus manos unos minutos con los ojos cerrados, respirando hondo tres veces para sintonizarla con tu propia energía e intención.";

        return (
          <div className="pt-8 border-t border-[#E8E2D9]">
            {/* Navigation Tabs */}
            <div className="flex border-b border-[#E8E2D9] mb-8 gap-8 overflow-x-auto">
              <button
                onClick={() => setActiveTab("ritual")}
                className={`pb-3 text-sm font-serif transition-colors whitespace-nowrap relative ${
                  activeTab === "ritual"
                    ? "text-[#4A5D4E] font-bold border-b-2 border-[#4A5D4E]"
                    : "text-stone-500 hover:text-stone-800"
                }`}
              >
                {product.category === "velas-velones"
                  ? "Propósito & Lectura de la Llama"
                  : product.category === "inciensos-aromaterapia"
                  ? "Propiedades & Efecto Energético"
                  : product.category === "cuarzos-minerales"
                  ? "Propiedades Gemoterapéuticas"
                  : product.category === "kits-rituales"
                  ? "Desglose del Kit & Guía en Caja"
                  : "Uso & Consagración Sagrada"}
              </button>
              <button
                onClick={() => setActiveTab("details")}
                className={`pb-3 text-sm font-serif transition-colors whitespace-nowrap relative ${
                  activeTab === "details"
                    ? "text-[#4A5D4E] font-bold border-b-2 border-[#4A5D4E]"
                    : "text-stone-500 hover:text-stone-800"
                }`}
              >
                {product.category === "velas-velones"
                  ? "Ficha Técnica & Composición"
                  : product.category === "inciensos-aromaterapia"
                  ? "Ficha Técnica & Compromiso Ético"
                  : product.category === "cuarzos-minerales"
                  ? "Garantía & Mantenimiento Estricto"
                  : product.category === "kits-rituales"
                  ? "Presentación & Ficha Técnica"
                  : "Ficha Técnica & Nivel"}
              </button>
              <button
                onClick={() => setActiveTab("reviews")}
                className={`pb-3 text-sm font-serif transition-colors whitespace-nowrap relative ${
                  activeTab === "reviews"
                    ? "text-[#4A5D4E] font-bold border-b-2 border-[#4A5D4E]"
                    : "text-stone-500 hover:text-stone-800"
                }`}
              >
                Experiencias de Clientes ({reviewsList.length})
              </button>
            </div>

            {/* TAB 1: ESPECÍFICO SEGÚN CATÁLOGO */}
            {activeTab === "ritual" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Columna Izquierda: Descripción general + Especificaciones de la Categoría */}
                <div className="space-y-6">
                  {/* Historia & Significado */}
                  <div className="bg-[#FAF7F0] p-6 rounded-2xl border border-[#E8E2D9] space-y-3">
                    <h3 className="font-serif text-lg font-semibold text-[#242B26] flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                      <span>Historia &amp; Significado Energético</span>
                    </h3>
                    <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
                      {product.fullDescription}
                    </p>
                  </div>

                  {/* CATÁLOGO 1: VELAS & VELONES -> Propósito & Simbolismo */}
                  {product.category === "velas-velones" && (
                    <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9] space-y-2">
                      <div className="flex items-center gap-2 text-[#4A5D4E] text-xs font-bold uppercase tracking-wider">
                        <Sun className="w-4 h-4 text-[#D4AF37]" />
                        <span>Propósito &amp; Simbolismo (Intención del Color)</span>
                      </div>
                      <p className="text-xs text-[#5B675E] leading-relaxed">
                        {propositoSimbolismo}
                      </p>
                    </div>
                  )}

                  {/* CATÁLOGO 2: INCIENSOS & AROMATERAPIA -> Notas Aromáticas */}
                  {product.category === "inciensos-aromaterapia" && (
                    <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9] space-y-2">
                      <div className="flex items-center gap-2 text-[#4A5D4E] text-xs font-bold uppercase tracking-wider">
                        <Wind className="w-4 h-4 text-[#D4AF37]" />
                        <span>Perfil Olfativo &amp; Notas Aromáticas</span>
                      </div>
                      <p className="text-xs text-[#5B675E] leading-relaxed">
                        {notasAromaticas}
                      </p>
                    </div>
                  )}

                  {/* CATÁLOGO 3: CUARZOS & MINERALES -> Propiedades Gemoterapéuticas */}
                  {product.category === "cuarzos-minerales" && (
                    <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9] space-y-2">
                      <div className="flex items-center gap-2 text-[#4A5D4E] text-xs font-bold uppercase tracking-wider">
                        <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                        <span>Propiedades Gemoterapéuticas</span>
                      </div>
                      <p className="text-xs text-[#5B675E] leading-relaxed">
                        {propiedadesGemoterapeuticas}
                      </p>
                    </div>
                  )}

                  {/* CATÁLOGO 4: KITS & RITUALES -> Desglose en Caja */}
                  {product.category === "kits-rituales" && (
                    <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9] space-y-3">
                      <div className="flex items-center gap-2 text-[#4A5D4E] text-xs font-bold uppercase tracking-wider">
                        <Box className="w-4 h-4 text-[#D4AF37]" />
                        <span>Contenido Desglosado en Caja Regalo</span>
                      </div>
                      <ul className="space-y-2 text-xs text-stone-700">
                        {contenidoDesglosado.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 bg-[#FAF7F0] p-2.5 rounded-xl border border-[#E8E2D9]">
                            <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* CATÁLOGO 5: HERRAMIENTAS MÍSTICAS -> Nivel Recomendado */}
                  {product.category === "herramientas-misticas" && (
                    <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9] space-y-2">
                      <div className="flex items-center gap-2 text-[#4A5D4E] text-xs font-bold uppercase tracking-wider">
                        <Award className="w-4 h-4 text-[#D4AF37]" />
                        <span>Nivel Recomendado en Práctica</span>
                      </div>
                      <p className="text-xs text-[#5B675E] leading-relaxed font-medium">
                        {nivelRecomendado}
                      </p>
                    </div>
                  )}
                </div>

                {/* Columna Derecha: Modo de uso / Guías específicas */}
                <div className="space-y-6">
                  {/* CATÁLOGO 1: VELAS -> Modo de Uso Seguro + Guía de Lectura de la Llama */}
                  {product.category === "velas-velones" && (
                    <>
                      <div className="bg-[#FAF7F0] p-6 rounded-2xl border border-[#E8E2D9] space-y-3">
                        <h3 className="font-serif text-lg font-semibold text-[#242B26] flex items-center gap-2">
                          <Flame className="w-4 h-4 text-[#D4AF37]" />
                          <span>Modo de Uso Seguro &amp; Encendido Sagrado</span>
                        </h3>
                        <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
                          {modoDeUsoVela}
                        </p>
                      </div>

                      <div className="bg-[#FDFBF7] p-6 rounded-2xl border-2 border-dashed border-[#D4AF37] space-y-2 shadow-xs">
                        <div className="flex items-center gap-2 text-[#4A5D4E] text-xs font-bold uppercase tracking-wider">
                          <Flame className="w-4 h-4 text-[#D4AF37]" />
                          <span>Guía de Lectura de la Llama / Cera (#BrujiTip)</span>
                        </div>
                        <p className="text-xs text-[#5B675E] leading-relaxed italic">
                          {guiaLecturaVela}
                        </p>
                      </div>
                    </>
                  )}

                  {/* CATÁLOGO 2: INCIENSOS -> Efecto Energético */}
                  {product.category === "inciensos-aromaterapia" && (
                    <div className="bg-[#FAF7F0] p-6 rounded-2xl border border-[#E8E2D9] space-y-3">
                      <h3 className="font-serif text-lg font-semibold text-[#242B26] flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                        <span>Efecto Energético en el Espacio</span>
                      </h3>
                      <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
                        {efectoEnergetico}
                      </p>
                    </div>
                  )}

                  {/* CATÁLOGO 3: CUARZOS -> Guía de Mantenimiento Estricto (Limpieza & Recarga) */}
                  {product.category === "cuarzos-minerales" && (
                    <div className="bg-[#FAF7F0] p-6 rounded-2xl border border-[#E8E2D9] space-y-3">
                      <h3 className="font-serif text-lg font-semibold text-stone-900 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-[#D4AF37]" />
                        <span>Guía de Mantenimiento Estricto (Limpieza &amp; Recarga)</span>
                      </h3>
                      <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                        {guiaMantenimiento}
                      </p>
                    </div>
                  )}

                  {/* CATÁLOGO 4: KITS -> Guía Física Incluida en Caja */}
                  {product.category === "kits-rituales" && (
                    <div className="bg-[#FAF7F0] p-6 rounded-2xl border border-[#D8C79E] space-y-3">
                      <div className="flex items-center gap-2 text-[#4A5D4E]">
                        <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                        <h3 className="font-serif text-lg font-semibold text-[#242B26]">
                          Guía Ritual Exclusiva Incluida en Caja
                        </h3>
                      </div>
                      <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
                        Este kit incorpora en su interior la <strong>guía física exclusiva impresa en papel verjurado</strong>, explicada paso a paso y con total sencillez para principiantes o practicantes, asegurando que vivas la experiencia sin dudas.
                      </p>
                    </div>
                  )}

                  {/* CATÁLOGO 5: HERRAMIENTAS -> Guía de Consagración Previa */}
                  {product.category === "herramientas-misticas" && (
                    <div className="bg-[#FAF7F0] p-6 rounded-2xl border border-amber-200 space-y-3">
                      <h3 className="font-serif text-lg font-semibold text-amber-950 flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                        <span>Guía de Consagración Previa al Primer Uso</span>
                      </h3>
                      <p className="text-xs sm:text-sm text-amber-900 leading-relaxed">
                        {guiaConsagracion}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: FICHA TÉCNICA ESPECÍFICA */}
            {activeTab === "details" && (
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="bg-[#FAF7F0] p-6 sm:p-8 rounded-2xl border border-[#E8E2D9] space-y-6">
                  <h3 className="font-serif text-lg font-semibold text-[#242B26]">
                    Especificaciones Técnicas &amp; Garantía
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    {/* CATÁLOGO 1: Composición de Cera */}
                    {product.category === "velas-velones" && (
                      <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9] sm:col-span-2">
                        <span className="font-semibold text-stone-800 block mb-1">Garantía de Composición:</span>
                        <span className="text-stone-600">{composicionVela}</span>
                      </div>
                    )}

                    {/* CATÁLOGO 2: Compromiso Ético */}
                    {product.category === "inciensos-aromaterapia" && (
                      <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9] sm:col-span-2">
                        <span className="font-semibold text-stone-800 block mb-1">Compromiso Ético &amp; Sostenible:</span>
                        <span className="text-stone-600">{compromisoEtico}</span>
                      </div>
                    )}

                    {/* CATÁLOGO 3: Sello de Autenticidad Mineral */}
                    {product.category === "cuarzos-minerales" && (
                      <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9] sm:col-span-2">
                        <span className="font-semibold text-stone-800 block mb-1">Garantía de Autenticidad Mineral:</span>
                        <span className="text-stone-600">{garantiaAutenticidad}</span>
                      </div>
                    )}

                    {/* CATÁLOGO 4: Presentación del Kit */}
                    {product.category === "kits-rituales" && (
                      <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9] sm:col-span-2">
                        <span className="font-semibold text-stone-800 block mb-1">Presentación del Envío:</span>
                        <span className="text-stone-600">{presentacionKit}</span>
                      </div>
                    )}

                    {/* CATÁLOGO 5: Nivel Recomendado */}
                    {product.category === "herramientas-misticas" && (
                      <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9] sm:col-span-2">
                        <span className="font-semibold text-stone-800 block mb-1">Nivel Recomendado:</span>
                        <span className="text-stone-600">{nivelRecomendado}</span>
                      </div>
                    )}

                    <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9]">
                      <span className="font-semibold text-stone-800 block mb-1">Intención Primaria:</span>
                      <span className="text-stone-600 capitalize">{product.intention}</span>
                    </div>

                    <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9]">
                      <span className="font-semibold text-stone-800 block mb-1">Disponibilidad:</span>
                      <span className="text-stone-600">{product.stock} unidades listas en altar</span>
                    </div>

                    <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9] sm:col-span-2">
                      <span className="font-semibold text-stone-800 block mb-1">Selección &amp; Purificación:</span>
                      <span className="text-stone-600">Altar de Perla &amp; Pluma · Selección artesanal, ética y de alta vibración</span>
                    </div>
                  </div>

                  {/* Ficha ilustrada para kits de regalo */}
                  {product.category === "kits-rituales" && (
                    <div className="pt-6 border-t border-[#E8E2D9] space-y-4">
                      <div className="flex items-center gap-2 text-[#4A5D4E]">
                        <Box className="w-5 h-5 text-[#D4AF37]" />
                        <h4 className="font-serif text-base font-semibold text-stone-900">
                          Ficha Ilustrada del Kit de Regalo
                        </h4>
                      </div>
                      <div className="bg-[#FAF7F0] p-5 rounded-2xl border border-[#E0D7C8] flex flex-col sm:flex-row items-center gap-5">
                        <div className="bg-[#F5F2EB] rounded-xl p-3 border border-[#E8E2D9] shrink-0">
                          <Image
                            src="/images/kit-caja-dibujo.png"
                            alt="Caja ilustrada del kit de ritual"
                            width={160}
                            height={150}
                            className="object-contain"
                          />
                        </div>
                        <div className="space-y-1.5 text-xs text-stone-600">
                          <p className="font-semibold text-stone-800">
                            Empaquetado meticuloso en caja rígida protegida.
                          </p>
                          <p>
                            Cada elemento viene dispuesto y protegido con mimo para garantizar una apertura ceremonial inolvidable.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        );
      })()}
      <div className="pt-4"></div>

      {/* Tab 3: Customer Reviews */}
        {activeTab === "reviews" && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#E8E2D9]">
              <div>
                <h3 className="font-serif text-lg font-semibold text-[#242B26]">
                  Experiencias en el Altar
                </h3>
                <p className="text-xs text-stone-500">
                  Opiniones sinceras de almas que ya han integrado esta pieza en su espacio.
                </p>
              </div>
              <div className="text-right">
                <span className="font-serif text-2xl font-bold text-stone-800">
                  {product.rating || "4.95"} / 5
                </span>
                <div className="flex items-center text-[#D4AF37] text-xs">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-[#D4AF37]" />
                  ))}
                </div>
              </div>
            </div>

            {reviewsList.length === 0 ? (
              <div className="p-8 text-center bg-[#FAF7F0] rounded-2xl border border-[#E8E2D9]">
                <p className="text-xs text-stone-500">
                  Sé la primera persona en compartir la vibración de esta pieza.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {reviewsList.map((rev) => (
                  <div
                    key={rev.id}
                    className="p-5 bg-[#FAF7F0] rounded-2xl border border-[#E8E2D9] space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-serif font-semibold text-sm text-stone-800">
                          {rev.author}
                        </span>
                        <span className="text-xs text-stone-400">• {rev.city}</span>
                        {rev.verifiedPurchase && (
                          <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            Compra Verificada
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-stone-400">{rev.date}</span>
                    </div>

                    <div className="flex items-center text-[#D4AF37]">
                      {Array.from({ length: rev.rating }).map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-[#D4AF37]" />
                      ))}
                    </div>

                    <h4 className="font-serif text-sm font-semibold text-stone-900">
                      {rev.title}
                    </h4>

                    <p className="text-xs text-stone-600 leading-relaxed">
                      {rev.comment}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* RELATED PIECES */}
      {relatedList.length > 0 && (
        <div className="pt-12 border-t border-[#E8E2D9] space-y-6">
          <div className="text-center max-w-xl mx-auto">
            <span className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold">
              Sinergia Sagrada
            </span>
            <h2 className="font-serif text-2xl text-[#242B26] mt-1">
              Piezas afines a esta vibración
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedList.map((rel) => (
              <ProductCard key={rel.id} product={rel} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
