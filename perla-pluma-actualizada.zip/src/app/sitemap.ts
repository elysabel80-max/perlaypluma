import type { MetadataRoute } from "next";
import { getAllProducts } from "@/lib/catalog";
import { BLOG_POSTS } from "@/data/blogData";

const BASE_URL = (process.env.NEXT_PUBLIC_SITE_URL || "https://perlaypluma.com").replace(/\/$/, "");

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const products = await getAllProducts();
  const now = new Date();

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${BASE_URL}/`, lastModified: now, changeFrequency: "weekly", priority: 1 },
    { url: `${BASE_URL}/catalogo`, lastModified: now, changeFrequency: "weekly", priority: 0.9 },
    { url: `${BASE_URL}/guias`, lastModified: now, changeFrequency: "monthly", priority: 0.6 },
    {
      url: `${BASE_URL}/circulo-de-luz`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.9,
    },
    { url: `${BASE_URL}/nosotros`, lastModified: now, changeFrequency: "yearly", priority: 0.4 },
  ];

  const productRoutes: MetadataRoute.Sitemap = products
    .filter((product) => product && product.slug)
    .map((product) => ({
      url: `${BASE_URL}/producto/${product.slug}`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.8,
    }));

  const guideRoutes: MetadataRoute.Sitemap = BLOG_POSTS.map((post) => ({
    url: `${BASE_URL}/guias/${post.slug}`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.5,
  }));

  return [...staticRoutes, ...productRoutes, ...guideRoutes];
}
