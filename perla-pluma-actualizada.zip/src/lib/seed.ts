import { db, hasDatabaseUrl } from "@/db";
import { products, reviews } from "@/db/schema";
import { SEED_PRODUCTS, SEED_REVIEWS } from "@/data/seedData";
import { count, eq } from "drizzle-orm";

let seeded = false;

export async function ensureDatabaseSeeded() {
  if (seeded || !hasDatabaseUrl()) return;
  try {
    // Seed any missing products from SEED_PRODUCTS (onConflictDoNothing prevents duplicates)
    for (const item of SEED_PRODUCTS) {
      if (!item || !item.slug) continue;
      await db.insert(products).values({
        slug: item.slug,
        name: item.name,
        subtitle: item.subtitle,
        category: item.category,
        categoryName: item.categoryName,
        subcategory: item.subcategory,
        intention: item.intention,
        price: item.price,
        originalPrice: item.originalPrice || null,
        rating: item.rating,
        reviewsCount: item.reviewsCount,
        stock: item.stock,
        isFeatured: item.isFeatured,
        isBestseller: item.isBestseller,
        isNewArrival: item.isNewArrival,
        primaryImage: item.primaryImage,
        detailImage: item.detailImage,
        contextImage: item.contextImage,
        shortDescription: item.shortDescription,
        fullDescription: item.fullDescription,
        propositoSimbolismo: item.propositoSimbolismo || null,
        composicion: item.composicion || null,
        modoDeUso: item.modoDeUso || null,
        guiaLecturaLlama: item.guiaLecturaLlama || null,
        aromaticNotes: item.aromaticNotes || null,
        energeticEffect: item.energeticEffect || null,
        ethicalCommitment: item.ethicalCommitment || null,
        mineralAuthenticity: item.mineralAuthenticity || null,
        gemotherapyProperties: item.gemotherapyProperties || null,
        cleansingRechargeGuide: item.cleansingRechargeGuide || null,
        kitContents: item.kitContents || null,
        kitRitualSteps: item.kitRitualSteps || null,
        presentation: item.presentation || null,
        mysticLevel: item.mysticLevel || null,
        consecrationGuide: item.consecrationGuide || null,
      }).onConflictDoNothing();
    }

    // Seed reviews
    for (const r of SEED_REVIEWS) {
      const [prod] = await db.select().from(products).where(eq(products.slug, r.productSlug));
      if (prod) {
        await db.insert(reviews).values({
          productId: prod.id,
          author: r.author,
          city: r.city,
          rating: r.rating,
          title: r.title,
          comment: r.comment,
          verifiedPurchase: r.verifiedPurchase,
          date: r.date,
        });
      }
    }
    seeded = true;
  } catch (error) {
    console.error("Database seed error:", error);
  }
}
