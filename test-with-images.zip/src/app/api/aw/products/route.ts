import { NextResponse } from "next/server";
import { getSupplierSettings } from "@/lib/awDropship";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("q") || searchParams.get("search") || "";
    const page = searchParams.get("page") || "1";
    const perPage = searchParams.get("per_page") || "20";

    const settings = getSupplierSettings();
    const token = settings.awToken || process.env.AW_DROPSHIP_API_TOKEN;

    if (!token) {
      return NextResponse.json({
        success: false,
        message: "No se ha configurado el Token de AW Dropship.",
        products: [],
      });
    }

    const apiUrl = new URL("https://api.aiku.io/dropshipping/products");
    if (search.trim()) {
      apiUrl.searchParams.set("search", search.trim());
    }
    apiUrl.searchParams.set("page", page);
    apiUrl.searchParams.set("per_page", perPage);

    const res = await fetch(apiUrl.toString(), {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token.trim()}`,
        Accept: "application/json",
      },
      cache: "no-store",
    });

    if (!res.ok) {
      const errText = await res.text();
      return NextResponse.json(
        { success: false, message: `Error del proveedor (${res.status})`, error: errText },
        { status: res.status }
      );
    }

    const data = await res.json();
    const rawItems = Array.isArray(data.data) ? data.data : [];

    const products = rawItems.map((item: any) => {
      const wholesalePrice = parseFloat(item.price) || 0;
      // Recommended margin: 2.2x wholesale + 2€
      const suggestedRetail = (wholesalePrice * 2.2 + 2).toFixed(2);

      const imageUrl =
        item.image?.original_2x ||
        item.image?.original ||
        item.image?.png_2x ||
        item.image?.png ||
        item.image?.webp ||
        "";

      // Strip basic HTML for short summary
      const cleanDesc = (item.description || "")
        .replace(/<[^>]+>/g, " ")
        .replace(/\s+/g, " ")
        .trim();

      return {
        id: item.id,
        code: item.code,
        name: item.name,
        wholesalePrice: wholesalePrice.toFixed(2),
        suggestedRetail,
        stock: item.current_stock || 0,
        imageUrl,
        barcode: item.ean_barcode || "",
        shortDescription: cleanDesc.slice(0, 160) + (cleanDesc.length > 160 ? "..." : ""),
        fullDescription: item.description || cleanDesc,
        weight: item.gross_weight || 0,
        slug: item.slug || item.code?.toLowerCase(),
      };
    });

    return NextResponse.json({
      success: true,
      total: data.meta?.total || products.length,
      currentPage: data.meta?.current_page || Number(page),
      lastPage: data.meta?.last_page || 1,
      products,
    });
  } catch (error) {
    console.error("Error in /api/aw/products:", error);
    return NextResponse.json(
      { success: false, message: "Error interno al conectar con AW Dropship", error: String(error) },
      { status: 500 }
    );
  }
}
