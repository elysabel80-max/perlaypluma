import { NextResponse } from "next/server";
import { db, hasDatabaseUrl } from "@/db";
import { orders } from "@/db/schema";
import { forwardOrderToAwDropship } from "@/lib/awDropship";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      customerName,
      customerEmail,
      customerPhone,
      address,
      city,
      postalCode,
      country,
      intentionNote,
      giftPackaging,
      items,
      subtotal,
      shipping,
      total,
    } = body;

    if (!customerName || !customerEmail || !address || !items || items.length === 0) {
      return NextResponse.json(
        { success: false, message: "Faltan datos obligatorios para procesar el pedido" },
        { status: 400 }
      );
    }

    const orderNumber = `PP-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;

    const payload = {
      orderNumber,
      customerName,
      customerEmail,
      customerPhone: customerPhone || null,
      address,
      city: city || "España",
      postalCode: postalCode || "28001",
      country: country || "España",
      intentionNote: intentionNote || null,
      giftPackaging: Boolean(giftPackaging),
      items,
      subtotal: String(subtotal),
      shipping: String(shipping),
      total: String(total),
      status: "energetizado",
    };

    // Forward to dropshipping suppliers (AW Dropship, etc.) if configured
    try {
      forwardOrderToAwDropship({
        orderNumber,
        customerName,
        customerEmail,
        customerPhone: customerPhone || undefined,
        address,
        city: city || "Madrid",
        postalCode: postalCode || "28001",
        country: country || "España",
        items,
      }).catch((e) => console.warn("[Dropship Auto-Forward Background Error]:", e));
    } catch (fwErr) {
      console.warn("Could not forward to dropship supplier:", fwErr);
    }

    if (hasDatabaseUrl()) {
      try {
        const [newOrder] = await db.insert(orders).values(payload).returning();
        return NextResponse.json({ success: true, order: newOrder, persisted: true });
      } catch (dbError) {
        console.warn("Order could not be persisted, confirming in demo mode:", dbError);
      }
    }

    // Demo mode: confirm the order so the storefront checkout stays fully functional.
    return NextResponse.json({
      success: true,
      order: { id: 0, createdAt: new Date().toISOString(), ...payload },
      persisted: false,
    });
  } catch (error) {
    console.error("POST /api/orders error:", error);
    return NextResponse.json(
      { success: false, message: "Error al procesar el pedido" },
      { status: 500 }
    );
  }
}
