import { NextResponse } from "next/server";
import { getSupplierSettings, saveSupplierSettings } from "@/lib/awDropship";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const settings = getSupplierSettings();
    return NextResponse.json({
      success: true,
      settings: {
        hasAwToken: Boolean(settings.awToken),
        awTokenMasked: settings.awToken ? `***...${settings.awToken.slice(-6)}` : "",
        hasEproloKey: Boolean(settings.eproloKey),
        eproloKeyMasked: settings.eproloKey ? `***...${settings.eproloKey.slice(-6)}` : "",
      },
    });
  } catch (err) {
    return NextResponse.json({ success: false, message: "Error al leer credenciales" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const current = getSupplierSettings();

    const updated = {
      awToken: body.awToken !== undefined ? body.awToken.trim() : current.awToken,
      eproloKey: body.eproloKey !== undefined ? body.eproloKey.trim() : current.eproloKey,
      eproloSecret: body.eproloSecret !== undefined ? body.eproloSecret.trim() : current.eproloSecret,
    };

    saveSupplierSettings(updated);

    return NextResponse.json({
      success: true,
      message: "Credenciales de proveedores guardadas correctamente.",
    });
  } catch (err) {
    return NextResponse.json({ success: false, message: "Error al guardar credenciales" }, { status: 500 });
  }
}
