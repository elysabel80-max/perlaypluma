import React from "react";
import { Metadata } from "next";
import { Shield, Sparkles, Mail, MapPin, Phone, UserCheck } from "lucide-react";

export const metadata: Metadata = {
  title: "Aviso Legal | Perla & Pluma",
  description: "Información legal, fiscal y datos identificativos de Perla & Pluma de acuerdo con la LSSI-CE.",
};

export default function AvisoLegalPage() {
  return (
    <main className="min-h-screen bg-[#FDFBF7] text-[#242B26] py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAE3D6] text-xs font-semibold text-[#4A5D4E] tracking-wider uppercase mb-4">
            <Shield className="w-4 h-4 text-[#D4AF37]" />
            <span>Marco Legal &amp; Transparencia</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#1B1C1A] font-bold mb-3">
            Aviso Legal
          </h1>
          <p className="text-sm text-[#5B675E] max-w-xl mx-auto">
            En cumplimiento del artículo 10 de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y de Comercio Electrónico (LSSI-CE).
          </p>
        </div>

        {/* Legal Identity Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E0D7C8] shadow-sm mb-10">
          <h2 className="font-serif text-xl font-bold text-[#1B1C1A] mb-4 flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-[#4A5D4E]" />
            <span>1. Datos Identificativos del Responsable</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm text-[#38433C]">
            <div className="p-3.5 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6]">
              <strong className="block text-[#1B1C1A] mb-1 font-semibold">Titular del Sitio Web:</strong>
              Elisa Isabel Martínez Bueno
            </div>
            <div className="p-3.5 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6]">
              <strong className="block text-[#1B1C1A] mb-1 font-semibold">Nombre Comercial:</strong>
              Perla &amp; Pluma
            </div>
            <div className="p-3.5 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6]">
              <strong className="block text-[#1B1C1A] mb-1 font-semibold">NIF / CIF:</strong>
              72975373F
            </div>
            <div className="p-3.5 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6]">
              <strong className="block text-[#1B1C1A] mb-1 font-semibold">Domicilio de Actividad:</strong>
              Calle San Jorge, 15, Dúplex 9, España
            </div>
            <div className="p-3.5 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6]">
              <strong className="block text-[#1B1C1A] mb-1 font-semibold">Correo Electrónico Oficial:</strong>
              <a href="mailto:info@perlaypluma.laperladeeli.es" className="text-[#4A5D4E] underline hover:text-[#D4AF37]">
                info@perlaypluma.laperladeeli.es
              </a>
            </div>
            <div className="p-3.5 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6]">
              <strong className="block text-[#1B1C1A] mb-1 font-semibold">Teléfono de Atención:</strong>
              <a href="tel:+34685544054" className="text-[#4A5D4E] underline hover:text-[#D4AF37]">
                +34 685 54 40 54
              </a>
            </div>
          </div>
        </div>

        {/* Legal Body Sections */}
        <div className="space-y-8 text-xs sm:text-sm text-[#38433C] leading-relaxed">
          <section className="bg-white rounded-2xl p-6 border border-[#E0D7C8]">
            <h3 className="font-serif text-lg font-bold text-[#1B1C1A] mb-2">2. Objeto y Ámbito de Aplicación</h3>
            <p>
              El presente Aviso Legal regula el acceso y la utilización del sitio web de Perla &amp; Pluma, a través del cual se comercializan artículos esotéricos, minerales y gemas naturales, elementos de aromaterapia y ritual, así como contenidos digitales (guías y membresía del Círculo de Luz). La navegación por el sitio web atribuye la condición de Usuario e implica la aceptación plena y sin reservas de todas y cada una de las disposiciones incluidas en este documento.
            </p>
          </section>

          <section className="bg-white rounded-2xl p-6 border border-[#E0D7C8]">
            <h3 className="font-serif text-lg font-bold text-[#1B1C1A] mb-2">3. Propiedad Intelectual e Industrial</h3>
            <p className="mb-3">
              Todos los contenidos de este sitio web, incluyendo textos, fotografías de productos, ilustraciones originales, logotipos, marcas, diseño gráfico, código fuente y selecciones rituales, son titularidad exclusiva de Elisa Isabel Martínez Bueno o de terceros que han autorizado debidamente su uso.
            </p>
            <p>
              Queda expresamente prohibida la reproducción, distribución, comunicación pública o transformación de cualquier contenido sin la autorización previa y por escrito de la titular.
            </p>
          </section>

          <section className="bg-white rounded-2xl p-6 border border-[#E0D7C8]">
            <h3 className="font-serif text-lg font-bold text-[#1B1C1A] mb-2">4. Descargo de Responsabilidad Espiritual y de Bienestar</h3>
            <p>
              Las descripciones energéticas, propiedades de los cristales, minerales, sahumerios y velas que aparecen en este portal responden a tradiciones culturales, espirituales y holísticas ancestrales. En ningún caso estos productos sustituyen diagnósticos, tratamientos médicos, psicológicos o farmacológicos reglados. Perla &amp; Pluma no se responsabiliza del uso indebido o de interpretaciones erróneas de los artículos o contenidos espirituales suministrados.
            </p>
          </section>

          <section className="bg-white rounded-2xl p-6 border border-[#E0D7C8]">
            <h3 className="font-serif text-lg font-bold text-[#1B1C1A] mb-2">5. Legislación Aplicable y Jurisdicción</h3>
            <p>
              Para la resolución de cualquier controversia o cuestión litigiosa derivada del presente sitio web o de las actividades en él desarrolladas, será de aplicación la legislación española vigente, sometiéndose expresamente las partes a los Juzgados y Tribunales correspondientes al fuero legal del consumidor.
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
