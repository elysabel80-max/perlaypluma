import React from "react";
import { Metadata } from "next";
import { RefreshCw, PackageCheck, AlertTriangle, Truck, Clock, Mail } from "lucide-react";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Política de Devoluciones y Envíos | Perla & Pluma",
  description: "Información sobre envíos, derecho de desistimiento de 14 días, garantías y excepciones de productos digitales.",
};

export default function DevolucionesPage() {
  return (
    <main className="min-h-screen bg-[#FDFBF7] text-[#242B26] py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAE3D6] text-xs font-semibold text-[#4A5D4E] tracking-wider uppercase mb-4">
            <RefreshCw className="w-4 h-4 text-[#D4AF37]" />
            <span>Garantía de Satisfacción &amp; Envíos</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#1B1C1A] font-bold mb-3">
            Política de Devoluciones y Envíos
          </h1>
          <p className="text-sm text-[#5B675E] max-w-xl mx-auto">
            Claridad y cercanía en cada etapa de tu pedido. Conoce tus derechos de desistimiento y las condiciones de entrega.
          </p>
        </div>

        <div className="space-y-8 text-xs sm:text-sm text-[#38433C] leading-relaxed">
          {/* Envíos */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3 flex items-center gap-2">
              <Truck className="w-5 h-5 text-[#4A5D4E]" />
              <span>1. Condiciones y Tiempos de Envío</span>
            </h2>
            <ul className="space-y-2.5 list-disc pl-5">
              <li>
                <strong>Preparación y Embalaje Seguro:</strong> Cada pedido se prepara y protege meticulosamente para garantizar que cada pieza llegue en perfecto estado. El tiempo de preparación y procesamiento es de <strong>1 a 3 días laborables</strong> antes de la expedición.
              </li>
              <li>
                <strong>Tiempos de Tránsito y Entrega:</strong> Una vez expedido el paquete, el plazo habitual de entrega es de <strong>24 a 48/72 horas hábiles</strong> en España peninsular mediante servicio de mensajería urgente. El plazo total estimado de entrega desde que realizas la compra es de <strong>3 a 5 días laborables</strong>.
              </li>
              <li>
                <strong>Cobertura:</strong> Realizamos envíos a toda España peninsular e Islas Baleares. Para envíos a Canarias o destinos internacionales, las tarifas y plazos se calculan en el checkout.
              </li>
              <li>
                <strong>Seguimiento de Envío:</strong> En cuanto tu pedido sea despachado, recibirás un correo electrónico con el número de seguimiento y el enlace de la agencia de transporte para conocer en todo momento el estado de la entrega.
              </li>
            </ul>
          </section>

          {/* Derecho de Desistimiento 14 días */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3 flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#4A5D4E]" />
              <span>2. Derecho Legal de Desistimiento (14 días naturales)</span>
            </h2>
            <p className="mb-3">
              Tienes derecho a desistir de tu compra en un plazo de <strong>14 días naturales</strong> sin necesidad de justificación, a contar desde el día en que tú o un tercero indicado por ti reciba el paquete en mano.
            </p>
            <p className="mb-3">
              Para ejercer este derecho, deberás notificarnos tu decisión de forma inequívoca enviando un correo a{" "}
              <a href="mailto:info@perlaypluma.laperladeeli.es" className="text-[#4A5D4E] underline font-semibold">
                info@perlaypluma.laperladeeli.es
              </a>{" "}
              con tu número de pedido y datos de contacto.
            </p>
            <div className="p-4 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6] space-y-2">
              <strong className="text-[#1B1C1A] block">Requisitos indispensables para aceptar la devolución física:</strong>
              <ul className="list-disc pl-5 space-y-1">
                <li>El producto debe estar sin usar, limpio y en el mismo estado en que fue entregado.</li>
                <li>Debe conservar su embalaje original, etiquetas, precintos de seguridad intactos y accesorios o regalos que lo acompañaran.</li>
                <li>Los gastos de envío derivados de la devolución del producto corren a cargo del comprador, salvo tara demostrada.</li>
              </ul>
            </div>
          </section>

          {/* Excepciones de Desistimiento: Digitales e Higiene */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs bg-rose-50/20">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-700" />
              <span>3. Excepciones al Derecho de Desistimiento (Art. 103 LGDCU)</span>
            </h2>
            <ul className="space-y-2.5 list-disc pl-5">
              <li>
                <strong>Contenidos y Guías Digitales:</strong> Quedan excluidos del derecho de desistimiento los productos digitales (archivos PDF descargables, guías místicas o membresías activadas) una vez que la descarga o el acceso haya comenzado.
              </li>
              <li>
                <strong>Velas Ungidas y Artículos Consagrados Personalizados:</strong> Aquellas piezas ritualizadas o personalizadas expresamente para el comprador, o bienes precintados que no sean aptos para ser devueltos por razones de protección de la salud, higiene o integridad energética y que hayan sido desprecintados tras la entrega.
              </li>
            </ul>
          </section>

          {/* Rotura en Transporte */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3 flex items-center gap-2">
              <PackageCheck className="w-5 h-5 text-[#4A5D4E]" />
              <span>4. Artículos Dañados o Incidencias de Transporte</span>
            </h2>
            <p className="mb-2">
              Protegemos cuidadosamente cada mineral y pieza delicada. Si tu pedido sufriera algún daño durante el transporte, te rogamos comunicárnoslo en un plazo máximo de <strong>48 horas</strong> tras la recepción, enviando fotografías claras de la caja exterior, la etiqueta de envío y el artículo afectado a{" "}
              <a href="mailto:info@perlaypluma.laperladeeli.es" className="text-[#4A5D4E] underline font-semibold">
                info@perlaypluma.laperladeeli.es
              </a>.
            </p>
            <p>
              Tras verificar la rotura, gestionaremos el reenvío inmediato de una nueva pieza sin coste alguno para ti o el reembolso íntegro del producto.
            </p>
          </section>

          {/* Reembolsos */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              5. Plazos y Modo de Reembolso
            </h2>
            <p>
              Una vez recibido el paquete devuelto en nuestro taller y comprobado su estado original, emitiremos el reembolso correspondiente en un plazo máximo de 14 días naturales, utilizando el mismo método de pago con el que realizaste la compra.
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
