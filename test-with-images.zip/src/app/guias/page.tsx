import React from "react";
import Link from "next/link";
import Image from "next/image";
import { BLOG_POSTS } from "@/data/blogData";
import { Sparkles, ArrowRight, BookOpen, Lock, Sparkle } from "lucide-react";

export default function BlogIndexPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAE3D6] text-xs uppercase tracking-widest text-[#4A5D4E] font-medium">
          <BookOpen className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>Sabiduría Sagrada & Práctica Cotidiana</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-5xl text-[#242B26] font-normal">
          Guías & Blog Místico
        </h1>
        <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
          Explicaciones claras sin dogmas ni oscurantismos: cómo sahumar tu casa, elegir tu primer cuarzo sin dudar y leer los secretos del fuego y el humo.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {BLOG_POSTS.map((post) => (
          <article
            key={post.slug}
            className="group bg-[#FDFBF7] rounded-3xl overflow-hidden border border-[#E8E2D9] hover:border-[#D4AF37]/50 shadow-xs hover:shadow-xl transition-all flex flex-col"
          >
            <div className="relative aspect-16/10 bg-stone-200 overflow-hidden">
              <Image
                src={post.image}
                alt={post.title}
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute top-4 left-4 flex items-center gap-1.5">
                {post.isFree ? (
                  <span className="bg-[#4A5D4E] text-[#FDFBF7] text-[10px] font-sans font-bold uppercase tracking-wider px-3 py-1 rounded-full shadow-xs">
                    Guía Gratuita
                  </span>
                ) : (
                  <span className="bg-[#242B26]/90 backdrop-blur-xs text-[#FFE088] text-[10px] font-sans font-bold uppercase tracking-wider px-3 py-1 rounded-full shadow-xs flex items-center gap-1 border border-[#D4AF37]/50">
                    <Lock className="w-3 h-3 text-[#D4AF37]" />
                    <span>Círculo de Luz • {post.price}</span>
                  </span>
                )}
              </div>
            </div>

            <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between space-y-4">
              <div>
                <div className="text-[11px] text-[#7A877E] mb-2 font-medium">
                  {post.date} • {post.readTime}
                </div>
                <h2 className="font-serif text-lg font-bold text-[#1B1C1A] group-hover:text-[#4A5D4E] transition-colors leading-snug">
                  {post.title}
                </h2>
                <p className="text-xs sm:text-sm text-[#5B675E] mt-2.5 leading-relaxed line-clamp-3">
                  {post.excerpt}
                </p>
              </div>

              <div className="pt-4 border-t border-[#E8E2D9] flex items-center justify-between">
                {post.isFree ? (
                  <Link
                    href={`/guias/${post.slug}`}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#4A5D4E] group-hover:text-[#242B26]"
                  >
                    <span>Leer guía abierta</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </Link>
                ) : (
                  <div className="flex items-center justify-between w-full">
                    <Link
                      href={`/guias/${post.slug}`}
                      className="text-xs font-semibold text-[#735c00] hover:underline"
                    >
                      Comprar ({post.price})
                    </Link>
                    <Link
                      href="/circulo-de-luz"
                      className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-[#FDFBF7] bg-[#334537] hover:bg-[#242B26] px-3.5 py-1.5 rounded-lg shadow-xs"
                    >
                      <Sparkles className="w-3 h-3 text-[#FFE088]" />
                      <span>Acceso Club</span>
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
