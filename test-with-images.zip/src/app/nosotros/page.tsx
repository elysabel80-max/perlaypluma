import React from "react";
import Image from "next/image";
import Link from "next/link";
import { Sparkles, ShieldCheck, Feather, HeartHandshake, Flame, Sun } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 space-y-16 sm:space-y-24">
      {/* Hero Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAE3D6] text-xs uppercase tracking-widest text-[#4A5D4E] font-medium">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Nuestra Historia Real</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl text-[#242B26] font-normal leading-tight">
            Detrás de Perla y Pluma: <span className="italic text-[#735c00]">Una muy bonita causalidad</span>
          </h1>

          <div className="space-y-4 text-base sm:text-lg text-[#2B352E] leading-relaxed font-light">
            <p>
              Hay momentos en la vida que te rompen en mil pedazos, no para destruirte, sino para que la luz pueda entrar por las grietas. Para mí, ese momento llegó hace tres años con la partida de mi compañera de vida, mi perra Perla.
            </p>
            <p>
              Dicen que los animales son maestros silenciosos, pero ella fue mucho más: fue el detonante de mi gran despertar espiritual. Al irse, el dolor se transformó en una profunda apertura hacia lo invisible. Entendí que en el universo no existen las coincidencias, sino las causalidades. Ella no perdió la vida; simplemente cambió sus cuatro patas por un par de alas.
            </p>
            <p className="font-serif text-[#334537] italic font-normal text-lg sm:text-xl border-l-2 border-[#D4AF37] pl-4 py-1 bg-[#F4EFE6]/50 rounded-r-xl">
              De ese pacto de amor eterno nace Perla y Pluma.
            </p>
            <p>
              <strong>La Perla</strong> es el tesoro que se gesta en lo profundo, en el silencio del caparazón, tal y como yo he estado gestando este proyecto durante el último año y medio de mi vida. <strong>La Pluma</strong> representa el aire, la libertad de su nuevo vuelo y, sobre todo, esa señal universal que nuestros guías y seres queridos nos dejan en el camino para recordarnos que siguen aquí, cuidándonos desde el otro lado.
            </p>
            <p>
              Tras tres años de pausa laboral, de introspección y de aprender a escuchar las señales del cielo, abro las puertas de este espacio místico y esotérico. Cada cristal, cada vela, cada sahumerio y cada herramienta que encuentres aquí ha sido seleccionada desde el corazón, con la intención de que te sirva de puente para elevar tu vibración, conectar con tu propia intuición y aprender a ver las maravillosas causalidades de tu vida.
            </p>
            <p className="font-serif text-[#735c00] font-medium pt-2">
              Gracias por formar parte de este puente cósmico. Ella guía mis pasos, y este espacio es mi homenaje a su luz. Bienvenida a Perla y Pluma.
            </p>
          </div>

          <div className="pt-2">
            <Link
              href="/catalogo"
              className="inline-block bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7] px-7 py-3.5 rounded-xl text-xs uppercase tracking-wider font-medium transition-colors shadow-sm"
            >
              Explorar Nuestras Piezas
            </Link>
          </div>
        </div>

        <div className="lg:col-span-5 relative">
          <div className="relative aspect-4/5 rounded-3xl overflow-hidden shadow-2xl border-4 border-[#D8C79E] bg-[#EFE9DD]">
            <Image
              src="/images/perla.jpg"
              alt="Perla, el alma y la inspiración detrás de Perla & Pluma"
              fill
              className="object-cover object-center"
              sizes="(max-width: 1024px) 100vw, 45vw"
              priority
            />
          </div>
          <div className="mt-3 text-center">
            <span className="text-xs font-serif italic text-[#735c00]">
              &ldquo;Ella no perdió la vida; simplemente cambió sus cuatro patas por un par de alas.&rdquo;
            </span>
          </div>
        </div>
      </div>

      {/* Los 4 Pilares Inquebrantables */}
      <div className="bg-[#FAF7F0] rounded-3xl p-8 sm:p-14 border border-[#E8E2D9] space-y-10">
        <div className="text-center max-w-xl mx-auto">
          <span className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold">
            Código Deontológico
          </span>
          <h2 className="font-serif text-3xl text-[#242B26] mt-1">
            Los 4 Pilares de Perla & Pluma
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-[#4A5D4E]">
              <Flame className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <h3 className="font-serif text-base font-semibold text-[#242B26]">
              1. Cera Virgen & Botánica Real
            </h3>
            <p className="text-xs text-[#5B675E] leading-relaxed">
              Renunciamos al humo tóxico de parafinas derivadas del petróleo. Nuestras velas son de cera pura de abeja o soja vegetal con mechas de algodón sin plomo.
            </p>
          </div>

          <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-[#4A5D4E]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-base font-semibold text-[#242B26]">
              2. Rigor Técnico Mineral
            </h3>
            <p className="text-xs text-[#5B675E] leading-relaxed">
              Explicamos honestamente qué es cada piedra. Sin nombres inventados ni vidrios coloreados vendidos como gemas.
            </p>
          </div>

          <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-[#4A5D4E]">
              <Feather className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-base font-semibold text-[#242B26]">
              3. Recolección Ética
            </h3>
            <p className="text-xs text-[#5B675E] leading-relaxed">
              El Palo Santo proviene exclusivamente de madera caída de forma natural tras años en el bosque seco peruano, apoyando a comunidades indígenas.
            </p>
          </div>

          <div className="p-6 bg-[#FDFBF7] rounded-2xl border border-[#E0D7C8] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-[#4A5D4E]">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-base font-semibold text-[#242B26]">
              4. Cuidado en Cada Paquete
            </h3>
            <p className="text-xs text-[#5B675E] leading-relaxed">
              Cada pedido sale sahumado de nuestro altar, en caja kraft libre de plásticos, con ramita de lavanda silvestre y lacre auténtico.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
