import React from "react";
import { Metadata } from "next";
import { Cookie, CheckCircle2, Shield, Settings } from "lucide-react";

export const metadata: Metadata = {
  title: "Política de Cookies | Perla & Pluma",
  description: "Información sobre el uso de cookies técnicas, analíticas y de preferencias en Perla & Pluma.",
};

export default function CookiesPage() {
  return (
    <main className="min-h-screen bg-[#FDFBF7] text-[#242B26] py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAE3D6] text-xs font-semibold text-[#4A5D4E] tracking-wider uppercase mb-4">
            <Cookie className="w-4 h-4 text-[#D4AF37]" />
            <span>Navegación Transparente</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#1B1C1A] font-bold mb-3">
            Política de Cookies
          </h1>
          <p className="text-sm text-[#5B675E] max-w-xl mx-auto">
            Te explicamos qué son las cookies, cuáles empleamos y cómo puedes configurarlas en tu navegador.
          </p>
        </div>

        <div className="space-y-8 text-xs sm:text-sm text-[#38433C] leading-relaxed">
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              1. ¿Qué es una Cookie?
            </h2>
            <p>
              Una cookie es un pequeño archivo de texto que un sitio web descarga en tu ordenador, móvil o tableta al acceder a determinadas páginas. Permiten a una página web, entre otras cosas, recordar tus productos en la cesta de la compra, recordar tus preferencias de idioma y garantizar una navegación ágil y segura.
            </p>
          </section>

          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              2. Cookies que Utilizamos en este Sitio Web
            </h2>
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6]">
                <strong className="text-[#1B1C1A] block font-semibold mb-1">Cookies Técnicas (Estrictamente Necesarias):</strong>
                <p>
                  Son imprescindibles para el correcto funcionamiento de la web. Permiten gestionar la bolsa de la compra, autenticar a usuarios registrados en el Círculo de Luz y mantener la seguridad del proceso de pago. No pueden desactivarse en nuestros sistemas.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6]">
                <strong className="text-[#1B1C1A] block font-semibold mb-1">Cookies de Preferencias:</strong>
                <p>
                  Permiten recordar tus filtros elegidos en el catálogo o tus preferencias de visualización para que tu experiencia mística sea fluida cada vez que regresas.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-[#FAF7F0] border border-[#EAE3D6]">
                <strong className="text-[#1B1C1A] block font-semibold mb-1">Cookies Analíticas Anónimas:</strong>
                <p>
                  Nos ayudan a comprender de manera agregada y anónima cómo interactúan los visitantes con el sitio para mejorar el diseño, la rapidez de carga y el contenido más apreciado.
                </p>
              </div>
            </div>
          </section>

          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3 flex items-center gap-2">
              <Settings className="w-5 h-5 text-[#4A5D4E]" />
              <span>3. Cómo Gestionar o Desactivar las Cookies</span>
            </h2>
            <p className="mb-3">
              Puedes permitir, bloquear o eliminar las cookies instaladas en tu equipo mediante la configuración de las opciones de tu navegador de internet:
            </p>
            <ul className="list-disc pl-5 space-y-1.5">
              <li><strong>Google Chrome:</strong> Configuración &gt; Privacidad y seguridad &gt; Cookies y otros datos de sitios.</li>
              <li><strong>Mozilla Firefox:</strong> Opciones &gt; Privacidad y Seguridad &gt; Cookies y datos del sitio.</li>
              <li><strong>Apple Safari:</strong> Preferencias &gt; Privacidad &gt; Bloquear todas las cookies.</li>
              <li><strong>Microsoft Edge:</strong> Configuración &gt; Permisos del sitio &gt; Cookies y datos del sitio.</li>
            </ul>
            <p className="mt-3 text-stone-600">
              Ten en cuenta que si bloqueas las cookies técnicas necesarias, algunas funciones básicas como añadir artículos a la cesta o finalizar tu compra podrían no operar adecuadamente.
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
