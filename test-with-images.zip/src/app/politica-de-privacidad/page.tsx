import React from "react";
import { Metadata } from "next";
import { ShieldCheck, Lock, Eye, Database, Mail } from "lucide-react";

export const metadata: Metadata = {
  title: "Política de Privacidad | Perla & Pluma",
  description: "Protección de datos conforme al Reglamento General de Protección de Datos (RGPD) y LOPDGDD.",
};

export default function PrivacidadPage() {
  return (
    <main className="min-h-screen bg-[#FDFBF7] text-[#242B26] py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAE3D6] text-xs font-semibold text-[#4A5D4E] tracking-wider uppercase mb-4">
            <Lock className="w-4 h-4 text-[#D4AF37]" />
            <span>Confidencialidad &amp; RGPD</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#1B1C1A] font-bold mb-3">
            Política de Privacidad
          </h1>
          <p className="text-sm text-[#5B675E] max-w-xl mx-auto">
            Tratamos tus datos con total respeto, transparencia y máxima seguridad, conforme al Reglamento (UE) 2016/679 (RGPD) y la Ley Orgánica 3/2018 (LOPDGDD).
          </p>
        </div>

        <div className="space-y-8 text-xs sm:text-sm text-[#38433C] leading-relaxed">
          {/* Responsable */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#4A5D4E]" />
              <span>1. Responsable del Tratamiento de tus Datos</span>
            </h2>
            <ul className="space-y-1.5 pl-2">
              <li><strong>Identidad:</strong> Elisa Isabel Martínez Bueno (Perla &amp; Pluma)</li>
              <li><strong>NIF:</strong> 72975373F</li>
              <li><strong>Dirección:</strong> Calle San Jorge, 15, Dúplex 9, España</li>
              <li><strong>Correo de Privacidad:</strong> <a href="mailto:info@perlaypluma.laperladeeli.es" className="text-[#4A5D4E] underline font-semibold">info@perlaypluma.laperladeeli.es</a></li>
              <li><strong>Teléfono:</strong> +34 685 54 40 54</li>
            </ul>
          </section>

          {/* Finalidad */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3 flex items-center gap-2">
              <Eye className="w-5 h-5 text-[#4A5D4E]" />
              <span>2. Finalidad con la que Tratamos tus Datos</span>
            </h2>
            <ul className="space-y-2 list-disc pl-5">
              <li><strong>Gestión de pedidos:</strong> Tramitar tus compras de productos físicos, gestionar el empaquetado, emitir facturas y coordinar la entrega con la empresa de mensajería.</li>
              <li><strong>Entrega de contenidos digitales:</strong> Enviar tus enlaces de descarga de guías en PDF y gestionar tu membresía activa en el Círculo de Luz.</li>
              <li><strong>Atención al cliente:</strong> Responder a tus dudas, peticiones de rituales personalizados o consultas a través de WhatsApp, teléfono o correo electrónico.</li>
              <li><strong>Comunicaciones del Círculo de Luz:</strong> Enviarte cartas de Luna Llena, rituales de temporada y promociones exclusivas únicamente si nos has otorgado tu consentimiento voluntario.</li>
            </ul>
          </section>

          {/* Legitimación */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              3. Base Jurídica que Legítima el Tratamiento
            </h2>
            <p className="mb-2">
              El tratamiento de tus datos para la compraventa de productos y gestión del área de usuario se basa en la <strong>ejecución de una relación contractual</strong>.
            </p>
            <p>
              El envío de boletines espirituales, novedades o cartas lunares se fundamenta exclusivamente en tu <strong>consentimiento expreso e informado</strong>, revocable en cualquier momento.
            </p>
          </section>

          {/* Destinatarios */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3 flex items-center gap-2">
              <Database className="w-5 h-5 text-[#4A5D4E]" />
              <span>4. Destinatarios de tus Datos</span>
            </h2>
            <p className="mb-2">
              Tus datos no serán vendidos ni cedidos a terceros con fines publicitarios. Únicamente acceden a los datos estrictamente necesarios los proveedores indispensables para prestar el servicio:
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Empresas de logística y transporte para entregar tu paquete.</li>
              <li>Plataformas de pago seguro (bancos, Stripe, Bizum) para procesar el cobro sin almacenar nosotros los datos de tu tarjeta.</li>
              <li>Servicios de alojamiento web e infraestructura técnica segura (Hostinger).</li>
            </ul>
          </section>

          {/* Derechos */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              5. Tus Derechos y Cómo Ejercerlos
            </h2>
            <p className="mb-3">
              Tienes derecho a acceder a tus datos personales, solicitar la rectificación de los datos inexactos, pedir su supresión cuando ya no sean necesarios, así como a la limitación, oposición y portabilidad de los mismos.
            </p>
            <p>
              Para ejercitar cualquiera de estos derechos, basta con enviar una comunicación escrita acompañada de fotocopia de tu documento de identidad a{" "}
              <a href="mailto:info@perlaypluma.laperladeeli.es" className="text-[#4A5D4E] underline font-semibold">
                info@perlaypluma.laperladeeli.es
              </a>. Asimismo, tienes derecho a presentar una reclamación ante la Agencia Española de Protección de Datos (AEPD) en caso de considerar vulnerados tus derechos.
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
