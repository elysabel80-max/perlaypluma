"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useCart } from "@/context/CartContext";
import { ProductCard } from "@/components/ProductCard";
import {
  Sparkles,
  ShoppingBag,
  Star,
  Check,
  Shield,
  Feather,
  Sun,
  Heart,
  Moon,
  Info,
  Flame,
  Wind,
  Layers,
  Award,
  Box,
  Gift,
  AlertCircle,
  ArrowLeft,
} from "lucide-react";

export default function ProductDetailPage() {
  const params = useParams();
  const slug = params?.slug as string;

  const { addItem } = useCart();
  const [product, setProduct] = useState<any>(null);
  const [reviewsList, setReviewsList] = useState<any[]>([]);
  const [relatedList, setRelatedList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState<string>("");
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const [activeTab, setActiveTab] = useState<"ritual" | "details" | "reviews">("ritual");

  useEffect(() => {
    async function loadProduct() {
      if (!slug) return;
      setLoading(true);
      try {
        const res = await fetch(`/api/products/${slug}`);
        const data = await res.json();
        if (data.success) {
          setProduct(data.product);
          setReviewsList(data.reviews || []);
          setRelatedList(data.related || []);
          setActiveImage(data.product.primaryImage);
        }
      } catch (err) {
        console.error("Error loading product detail", err);
      } finally {
        setLoading(false);
      }
    }
    loadProduct();
  }, [slug]);

  if (loading) {
    return (
      <div className="py-32 text-center space-y-4">
        <Sparkles className="w-10 h-10 text-[#D4AF37] animate-spin mx-auto" />
        <p className="font-serif text-stone-600 text-sm">Consultando los registros sagrados de Perla & Pluma...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="py-24 max-w-md mx-auto text-center space-y-4 px-4">
        <h2 className="font-serif text-2xl text-stone-800">Pieza no encontrada</h2>
        <p className="text-xs text-stone-600">
          Esta pieza no existe o ha cambiado de plano en nuestro catálogo.
        </p>
        <Link
          href="/catalogo"
          className="inline-block bg-[#4A5D4E] text-[#FDFBF7] px-5 py-2.5 rounded-lg text-xs font-medium"
        >
          Volver al Catálogo
        </Link>
      </div>
    );
  }

  const numPrice = typeof product.price === "string" ? parseFloat(product.price) : product.price;
  const numOriginal = product.originalPrice
    ? typeof product.originalPrice === "string"
      ? parseFloat(product.originalPrice)
      : product.originalPrice
    : null;

  const handleAddToCart = () => {
    addItem(product, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const galleryImages = [
    product.primaryImage,
    product.detailImage,
    product.contextImage,
  ].filter(Boolean);

  const getIntentionBadge = (intention: string) => {
    switch (intention) {
      case "proteccion":
        return { label: "Protección & Limpieza", icon: <Shield className="w-3.5 h-3.5" />, bg: "bg-stone-100 text-stone-800" };
      case "calma":
        return { label: "Calma & Serenidad", icon: <Feather className="w-3.5 h-3.5" />, bg: "bg-emerald-50 text-emerald-900" };
      case "abundancia":
        return { label: "Abundancia & Prosperidad", icon: <Sun className="w-3.5 h-3.5" />, bg: "bg-amber-50 text-amber-900" };
      case "amor":
        return { label: "Amor Propio & Relaciones", icon: <Heart className="w-3.5 h-3.5" />, bg: "bg-rose-50 text-rose-900" };
      case "intuicion":
        return { label: "Intuición & Conexión", icon: <Moon className="w-3.5 h-3.5" />, bg: "bg-violet-50 text-violet-900" };
      default:
        return { label: "Intención Sagrada", icon: <Sparkles className="w-3.5 h-3.5" />, bg: "bg-stone-100 text-stone-800" };
    }
  };

  const badge = getIntentionBadge(product.intention);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-14 space-y-16">
      {/* Back button & Breadcrumbs */}
      <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 font-sans">
        <Link href="/catalogo" className="hover:text-stone-800 flex items-center gap-1">
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Catálogo</span>
        </Link>
        <span>/</span>
        <Link href={`/catalogo?category=${product.category}`} className="hover:text-stone-800">
          {product.categoryName}
        </Link>
        <span>/</span>
        <span className="text-stone-800 font-medium truncate max-w-xs">{product.name}</span>
      </div>

      {/* Main Product Hero Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
        {/* Left: Gallery (Col 7) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Main big image view */}
          <div className="relative aspect-square sm:aspect-4/3 rounded-3xl overflow-hidden bg-[#F2ECE1] border border-[#E8E2D9] shadow-sm">
            <Image
              src={activeImage || product.primaryImage}
              alt={product.name}
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 55vw"
              className="object-cover transition-all duration-300"
            />
            {/* Top Intention pill */}
            <div className="absolute top-4 left-4 flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-serif shadow-xs backdrop-blur-xs bg-white/90 border border-white/40">
              {badge.icon}
              <span className="font-medium">{badge.label}</span>
            </div>

            {/* Sello de Garantía Ritual */}
            <div className="absolute bottom-4 right-4 bg-[#242B26]/85 backdrop-blur-md text-[#FDFBF7] px-3.5 py-1.5 rounded-full text-[11px] font-sans flex items-center gap-1.5 shadow-md">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Pieza energizada en altar antes del envío</span>
            </div>
          </div>

          {/* Thumbnails */}
          <div className="grid grid-cols-3 gap-3">
            {galleryImages.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImage(img)}
                className={`relative aspect-square rounded-xl overflow-hidden bg-stone-100 border-2 transition-all ${
                  activeImage === img
                    ? "border-[#4A5D4E] scale-98 shadow-sm"
                    : "border-transparent opacity-80 hover:opacity-100"
                }`}
              >
                <Image
                  src={img}
                  alt={`${product.name} detalle ${idx + 1}`}
                  fill
                  sizes="120px"
                  className="object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Right: Info & Purchase (Col 5) */}
        <div className="lg:col-span-5 space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs uppercase font-sans tracking-widest text-[#D4AF37] font-semibold">
                {product.subcategory}
              </span>
              {product.mysticLevel && (
                <span className="text-[10px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md border border-stone-200">
                  Nivel: {product.mysticLevel}
                </span>
              )}
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl text-[#242B26] font-normal leading-tight">
              {product.name}
            </h1>

            <p className="text-sm text-[#5B675E] mt-2 font-serif italic">
              {product.subtitle}
            </p>

            {/* Rating summary */}
            <div className="flex items-center gap-2 mt-3 text-xs">
              <div className="flex items-center text-[#D4AF37]">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#D4AF37]" />
                ))}
              </div>
              <span className="font-semibold text-stone-800">{product.rating || "4.95"}</span>
              <span className="text-stone-400">({product.reviewsCount || 24} valoraciones en altar)</span>
            </div>
          </div>

          {/* Price */}
          <div className="p-4 bg-[#FAF7F0] rounded-2xl border border-[#E8E2D9] flex items-baseline justify-between">
            <div className="flex items-baseline gap-3">
              <span className="font-serif text-3xl font-bold text-[#242B26]">
                {numPrice.toFixed(2)} €
              </span>
              {numOriginal && (
                <span className="text-sm text-stone-400 line-through">
                  {numOriginal.toFixed(2)} €
                </span>
              )}
            </div>
            <span className="text-xs text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 font-medium">
              En stock ({product.stock} disponibles)
            </span>
          </div>

          {/* Short description */}
          <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
            {product.shortDescription}
          </p>

          {/* Purchase Controls */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-3">
              {/* Quantity selector */}
              <div className="flex items-center border border-[#DDD3C3] rounded-xl bg-[#FAF7F0] p-1">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="w-8 h-8 rounded-lg hover:bg-stone-200 flex items-center justify-center text-stone-700 font-semibold"
                  aria-label="Restar uno"
                >
                  -
                </button>
                <span className="w-10 text-center text-xs font-semibold">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => q + 1)}
                  className="w-8 h-8 rounded-lg hover:bg-stone-200 flex items-center justify-center text-stone-700 font-semibold"
                  aria-label="Sumar uno"
                >
                  +
                </button>
              </div>

              {/* Add to Cart Main Button */}
              <button
                onClick={handleAddToCart}
                className={`flex-1 py-3.5 px-6 rounded-xl font-medium text-xs tracking-wider uppercase transition-all shadow-md flex items-center justify-center gap-2 ${
                  added
                    ? "bg-emerald-700 text-white"
                    : "bg-[#4A5D4E] hover:bg-[#3B4B3F] text-[#FDFBF7]"
                }`}
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>¡Añadido a tu altar de compra!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>Añadir a la Cesta • {(numPrice * quantity).toFixed(2)} €</span>
                  </>
                )}
              </button>
            </div>

            <div className="text-[11px] text-stone-500 text-center flex items-center justify-center gap-2 pt-1">
              <span>✨ Envío peninsular</span>
              <span>•</span>
              <span>🌿 Empaque 100% biodegradable</span>
              <span>•</span>
              <span>🕯️ Detalle de regalo a partir de 5 €</span>
            </div>
          </div>

          {/* Informative Highlights per Design Guide */}
          <div className="border-t border-[#E8E2D9] pt-5 space-y-3">
            {/* Mineral Authenticity if available */}
            {product.mineralAuthenticity && (
              <div className="flex items-start gap-2.5 p-3 bg-[#F4EFE6] rounded-xl border border-[#DFD6C6]">
                <Award className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-semibold text-stone-900 block">Sello de Autenticidad Mineral:</span>
                  <p className="text-stone-600 text-[11px]">{product.mineralAuthenticity}</p>
                </div>
              </div>
            )}

            {/* Ethical Commitment if available */}
            {product.ethicalCommitment && (
              <div className="flex items-start gap-2.5 p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                <Feather className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-semibold text-emerald-950 block">Compromiso Ético & Sostenible:</span>
                  <p className="text-emerald-800 text-[11px]">{product.ethicalCommitment}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* DETAILED INFORMATION BLOCKS (Bloques específicos según Ficha de Producto de la Guía) */}
      <div className="pt-8 border-t border-[#E8E2D9]">
        {/* Navigation Tabs */}
        <div className="flex border-b border-[#E8E2D9] mb-8 gap-8">
          <button
            onClick={() => setActiveTab("ritual")}
            className={`pb-3 text-sm font-serif transition-colors relative ${
              activeTab === "ritual"
                ? "text-[#4A5D4E] font-bold border-b-2 border-[#4A5D4E]"
                : "text-stone-500 hover:text-stone-800"
            }`}
          >
            Modo de Uso & Propiedades Místicas
          </button>
          <button
            onClick={() => setActiveTab("details")}
            className={`pb-3 text-sm font-serif transition-colors relative ${
              activeTab === "details"
                ? "text-[#4A5D4E] font-bold border-b-2 border-[#4A5D4E]"
                : "text-stone-500 hover:text-stone-800"
            }`}
          >
            Ficha Técnica & Composición
          </button>
          <button
            onClick={() => setActiveTab("reviews")}
            className={`pb-3 text-sm font-serif transition-colors relative ${
              activeTab === "reviews"
                ? "text-[#4A5D4E] font-bold border-b-2 border-[#4A5D4E]"
                : "text-stone-500 hover:text-stone-800"
            }`}
          >
            Experiencias de Clientes ({reviewsList.length})
          </button>
        </div>

        {/* Tab 1: Ritual & Mystic Properties */}
        {activeTab === "ritual" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              {/* Full Description */}
              <div className="bg-[#FAF7F0] p-6 rounded-2xl border border-[#E8E2D9] space-y-3">
                <h3 className="font-serif text-lg font-semibold text-[#242B26] flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                  <span>Historia & Significado Energético</span>
                </h3>
                <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
                  {product.fullDescription}
                </p>
              </div>

              {/* Propósito & Simbolismo (Para Velas y Cuarzos) */}
              {product.propositoSimbolismo && (
                <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9] space-y-2">
                  <h4 className="font-serif text-base font-semibold text-[#242B26]">
                    Propósito & Simbolismo
                  </h4>
                  <p className="text-xs text-[#5B675E] leading-relaxed">
                    {product.propositoSimbolismo}
                  </p>
                </div>
              )}

              {/* Propiedades Gemoterapéuticas */}
              {product.gemotherapyProperties && (
                <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9] space-y-2">
                  <h4 className="font-serif text-base font-semibold text-[#242B26]">
                    Propiedades Gemoterapéuticas
                  </h4>
                  <p className="text-xs text-[#5B675E] leading-relaxed">
                    {product.gemotherapyProperties}
                  </p>
                </div>
              )}

              {/* Guía de Consagración (Para Herramientas Místicas) */}
              {product.consecrationGuide && (
                <div className="bg-amber-50/70 p-6 rounded-2xl border border-amber-200 space-y-2">
                  <h4 className="font-serif text-base font-semibold text-amber-950 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                    <span>Guía de Consagración Previa</span>
                  </h4>
                  <p className="text-xs text-amber-900 leading-relaxed">
                    {product.consecrationGuide}
                  </p>
                </div>
              )}
            </div>

            <div className="space-y-6">
              {/* Modo de Uso Seguro / Paso a Paso Ritual */}
              {product.modoDeUso && (
                <div className="bg-[#FAF7F0] p-6 rounded-2xl border border-[#E8E2D9] space-y-3">
                  <h3 className="font-serif text-lg font-semibold text-[#242B26] flex items-center gap-2">
                    <Flame className="w-4 h-4 text-[#D4AF37]" />
                    <span>Modo de Uso Seguro & Activación</span>
                  </h3>
                  <p className="text-xs sm:text-sm text-[#5B675E] leading-relaxed">
                    {product.modoDeUso}
                  </p>
                </div>
              )}

              {/* #BrujiTip: Guía de Lectura de la Llama / Cera (Requisito explícito de la guía) */}
              {product.guiaLecturaLlama && (
                <div className="bg-[#FDFBF7] p-6 rounded-2xl border-2 border-dashed border-[#D4AF37] space-y-2 shadow-xs">
                  <div className="flex items-center gap-2 text-[#4A5D4E] text-xs font-bold uppercase tracking-wider">
                    <Flame className="w-4 h-4 text-[#D4AF37]" />
                    <span>Guía de Lectura de la Llama / Cera (#BrujiTip)</span>
                  </div>
                  <p className="text-xs text-[#5B675E] leading-relaxed italic">
                    {product.guiaLecturaLlama}
                  </p>
                </div>
              )}

              {/* Guía de Limpieza & Recarga (Para Minerales: Agua/Sal vs Selenita/Humo) */}
              {product.cleansingRechargeGuide && (
                <div className="bg-stone-100 p-6 rounded-2xl border border-stone-200 space-y-2">
                  <h4 className="font-serif text-base font-semibold text-stone-900 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-stone-600" />
                    <span>Guía de Limpieza & Recarga Energética</span>
                  </h4>
                  <p className="text-xs text-stone-700 leading-relaxed">
                    {product.cleansingRechargeGuide}
                  </p>
                </div>
              )}

              {/* Fórmula Ritual Ilustrada si corresponde */}
              {product.intention && ["proteccion", "calma", "abundancia", "amor", "intuicion"].includes(product.intention) && (
                <div className="bg-[#FDFBF7] p-5 rounded-2xl border border-[#D8C79E] space-y-3">
                  <div className="flex items-center gap-2 text-[#4A5D4E]">
                    <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                    <span className="text-xs uppercase tracking-widest text-[#735c00] font-bold">
                      Fórmula &amp; Sinergia del Ritual:
                    </span>
                  </div>
                  <div className="overflow-hidden rounded-xl border border-[#E0D7C8] bg-[#FAF7F0] p-1 shadow-2xs">
                    <Image
                      src={`/images/vineta-formula-${product.intention}.png`}
                      alt={`Fórmula ilustrada para ${product.name}`}
                      width={1035}
                      height={215}
                      className="w-full h-auto object-contain rounded-lg"
                    />
                  </div>
                </div>
              )}

              {/* Kits: Paso a Paso Ritual */}
              {product.kitRitualSteps && Array.isArray(product.kitRitualSteps) && (
                <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E8E2D9] space-y-3">
                  <h4 className="font-serif text-base font-semibold text-[#242B26]">
                    Paso a Paso del Ritual Incluido
                  </h4>
                  <ol className="space-y-2 text-xs text-[#5B675E]">
                    {product.kitRitualSteps.map((step: string, sIdx: number) => (
                      <li key={sIdx} className="p-2 bg-[#FAF7F0] rounded-lg">
                        {step}
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Technical Specifications & Composition */}
        {activeTab === "details" && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="bg-[#FAF7F0] p-6 sm:p-8 rounded-2xl border border-[#E8E2D9] space-y-4">
              <h3 className="font-serif text-lg font-semibold text-[#242B26]">
                Composición & Características
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {product.composicion && (
                  <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9]">
                    <span className="font-semibold text-stone-800 block mb-1">Composición:</span>
                    <span className="text-stone-600">{product.composicion}</span>
                  </div>
                )}

                {product.aromaticNotes && (
                  <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9]">
                    <span className="font-semibold text-stone-800 block mb-1">Notas Aromáticas & Perfil:</span>
                    <span className="text-stone-600">{product.aromaticNotes}</span>
                  </div>
                )}

                {product.energeticEffect && (
                  <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9]">
                    <span className="font-semibold text-stone-800 block mb-1">Efecto Energético:</span>
                    <span className="text-stone-600">{product.energeticEffect}</span>
                  </div>
                )}

                <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9]">
                  <span className="font-semibold text-stone-800 block mb-1">Intención Primaria:</span>
                  <span className="text-stone-600 capitalize">{product.intention}</span>
                </div>

                <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9]">
                  <span className="font-semibold text-stone-800 block mb-1">Disponibilidad:</span>
                  <span className="text-stone-600">{product.stock} unidades listas en altar</span>
                </div>

                <div className="p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E2D9]">
                  <span className="font-semibold text-stone-800 block mb-1">Origen & Taller:</span>
                  <span className="text-stone-600">Artesanía sagrada en España y yacimientos certificados</span>
                </div>
              </div>

              {/* Kit Contents & Illustrated Sheet if available */}
              {(product.category === "kits-rituales" || (product.kitContents && Array.isArray(product.kitContents))) && (
                <div className="pt-6 border-t border-[#E8E2D9] space-y-4">
                  <div className="flex items-center gap-2 text-[#4A5D4E]">
                    <Box className="w-5 h-5 text-[#D4AF37]" />
                    <h4 className="font-serif text-base font-semibold text-stone-900">
                      Ficha Ilustrada del Kit &amp; Desglose de Componentes
                    </h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center bg-[#FAF7F0] p-5 rounded-2xl border border-[#E0D7C8]">
                    <div className="md:col-span-5 bg-[#F5F2EB] rounded-xl p-3 border border-[#E8E2D9] flex items-center justify-center shadow-2xs">
                      <Image
                        src="/images/kit-caja-dibujo.png"
                        alt="Ficha dibujada de la caja y elementos del kit"
                        width={580}
                        height={560}
                        className="w-full max-w-[260px] h-auto object-contain rounded-lg"
                      />
                    </div>
                    <div className="md:col-span-7 space-y-3">
                      <span className="text-xs font-bold uppercase tracking-wider text-[#735c00] block">
                        Contenido Desglosado en Caja Regalo:
                      </span>
                      {product.kitContents && (
                        <ul className="space-y-2 text-xs text-stone-700">
                          {product.kitContents.map((c: string, cIdx: number) => (
                            <li key={cIdx} className="flex items-start gap-2">
                              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                              <span>{c}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Presentation if available */}
              {product.presentation && (
                <div className="pt-4 border-t border-[#E8E2D9] flex items-start gap-3">
                  <Gift className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <span className="font-semibold text-stone-800 block">Presentación del Envío:</span>
                    <p className="text-stone-600 mt-0.5">{product.presentation}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Customer Reviews */}
        {activeTab === "reviews" && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#E8E2D9]">
              <div>
                <h3 className="font-serif text-lg font-semibold text-[#242B26]">
                  Experiencias en el Altar
                </h3>
                <p className="text-xs text-stone-500">
                  Opiniones sinceras de almas que ya han integrado esta pieza en su espacio.
                </p>
              </div>
              <div className="text-right">
                <span className="font-serif text-2xl font-bold text-stone-800">
                  {product.rating || "4.95"} / 5
                </span>
                <div className="flex items-center text-[#D4AF37] text-xs">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-[#D4AF37]" />
                  ))}
                </div>
              </div>
            </div>

            {reviewsList.length === 0 ? (
              <div className="p-8 text-center bg-[#FAF7F0] rounded-2xl border border-[#E8E2D9]">
                <p className="text-xs text-stone-500">
                  Sé la primera persona en compartir la vibración de esta pieza.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {reviewsList.map((rev) => (
                  <div
                    key={rev.id}
                    className="p-5 bg-[#FAF7F0] rounded-2xl border border-[#E8E2D9] space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-serif font-semibold text-sm text-stone-800">
                          {rev.author}
                        </span>
                        <span className="text-xs text-stone-400">• {rev.city}</span>
                        {rev.verifiedPurchase && (
                          <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            Compra Verificada
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-stone-400">{rev.date}</span>
                    </div>

                    <div className="flex items-center text-[#D4AF37]">
                      {Array.from({ length: rev.rating }).map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-[#D4AF37]" />
                      ))}
                    </div>

                    <h4 className="font-serif text-sm font-semibold text-stone-900">
                      {rev.title}
                    </h4>

                    <p className="text-xs text-stone-600 leading-relaxed">
                      {rev.comment}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* RELATED PIECES */}
      {relatedList.length > 0 && (
        <div className="pt-12 border-t border-[#E8E2D9] space-y-6">
          <div className="text-center max-w-xl mx-auto">
            <span className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold">
              Sinergia Sagrada
            </span>
            <h2 className="font-serif text-2xl text-[#242B26] mt-1">
              Piezas afines a esta vibración
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedList.map((rel) => (
              <ProductCard key={rel.id} product={rel} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
