import React from "react";
import { Metadata } from "next";
import { FileText, CheckCircle2, AlertCircle, Sparkles, Scale, RefreshCw } from "lucide-react";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Términos y Condiciones Generales de Contratación | Perla & Pluma",
  description: "Condiciones de compra, precios, impuestos (IVA/OSS), garantías y entrega de Perla & Pluma.",
};

export default function TerminosPage() {
  return (
    <main className="min-h-screen bg-[#FDFBF7] text-[#242B26] py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAE3D6] text-xs font-semibold text-[#4A5D4E] tracking-wider uppercase mb-4">
            <Scale className="w-4 h-4 text-[#D4AF37]" />
            <span>Condiciones Generales de Venta</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#1B1C1A] font-bold mb-3">
            Términos y Condiciones
          </h1>
          <p className="text-sm text-[#5B675E] max-w-xl mx-auto">
            Regulan las relaciones comerciales entre Elisa Isabel Martínez Bueno (Perla &amp; Pluma) y los clientes de la tienda online.
          </p>
        </div>

        <div className="space-y-8 text-xs sm:text-sm text-[#38433C] leading-relaxed">
          {/* Identificación */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              1. Identificación del Vendedor
            </h2>
            <p>
              Elisa Isabel Martínez Bueno, titular de Perla &amp; Pluma, con NIF 72975373F, domicilio en Calle San Jorge, 15, Dúplex 9 (España), teléfono +34 685 54 40 54 y correo electrónico{" "}
              <a href="mailto:info@perlaypluma.laperladeeli.es" className="text-[#4A5D4E] underline font-semibold">
                info@perlaypluma.laperladeeli.es
              </a>.
            </p>
          </section>

          {/* Precios e IVA */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              2. Precios, Moneda y Régimen Fiscal (IVA / Ventanilla Única OSS)
            </h2>
            <ul className="space-y-2.5 list-disc pl-5">
              <li>
                <strong>Moneda y Desglose:</strong> Todos los precios están expresados en Euros (€) e incluyen los impuestos aplicables en España (tipo general del 21% de IVA en productos físicos y aromaterapia; tipo superreducido del 4% en libros y guías digitales donde proceda por normativa fiscal).
              </li>
              <li>
                <strong>Compradores de la Unión Europea (Régimen OSS):</strong> Conforme a la directiva comunitaria de comercio electrónico transfronterizo (Ventanilla Única / One-Stop Shop), a los pedidos emitidos a consumidores finales de otros Estados miembros de la UE se les aplicará el tipo de IVA vigente en el país de destino de la entrega o descarga.
              </li>
              <li>
                <strong>Destinos fuera de la UE / Canarias, Ceuta y Melilla:</strong> Los posibles aranceles aduaneros, DUA o impuestos locales de importación serán abonados directamente por el destinatario en el momento de la recepción del paquete.
              </li>
            </ul>
          </section>

          {/* Productos y Regalos físicos */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              3. Productos, Artesanía y Política de Obsequios
            </h2>
            <ul className="space-y-2.5 list-disc pl-5">
              <li>
                <strong>Singularidad Mineral:</strong> Los minerales, cristales y velas de cera pura son elementos naturales y artesanales. Cada pieza es única, pudiendo presentar variaciones naturales de veta, tonalidad y morfología respecto a las fotografías de muestra.
              </li>
              <li>
                <strong>Condición de Regalo Físico (Pedido Mínimo de 5 €):</strong> Los obsequios energéticos de bienvenida o cortesía (como mini-velas de cera, piedras consagradas o tarjetas rituales) se incluyen exclusivamente en pedidos físicos con un importe mínimo de compra de <strong>5,00 €</strong> (gastos de envío excluidos), o dentro de los envíos de suscriptores del Círculo Oro VIP.
              </li>
            </ul>
          </section>

          {/* Productos Digitales */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs bg-amber-50/30">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-[#D4AF37]" />
              <span>4. Productos Digitales (Guías en PDF y Membresías)</span>
            </h2>
            <p className="mb-2">
              Las guías rituales, descargables en PDF y audios se entregan mediante enlace digital directo o correo electrónico tras la confirmación del pago.
            </p>
            <p className="text-stone-800 font-medium">
              ⚠️ <strong>Excepción al Derecho de Desistimiento:</strong> De conformidad con el artículo 103, letra m) del Real Decreto Legislativo 1/2007, de 27 de noviembre, el derecho de desistimiento no será aplicable al suministro de contenido digital que no se preste en un soporte material cuando la ejecución haya comenzado con el previo consentimiento expreso del consumidor. Por tanto, las descargas digitales no admiten devolución ni reembolso una vez iniciado el acceso.
            </p>
          </section>

          {/* Suscripción Círculo de Luz */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              5. Suscripción al Círculo de Luz
            </h2>
            <p>
              Las membresías (Círculo Plata a 4,99 €/mes y Círculo Oro VIP a 14,99 €/mes) se renuevan de manera automática mensual. El usuario puede cancelar su suscripción en cualquier momento con un solo clic desde su área de cliente, manteniendo el acceso a los beneficios hasta el final del periodo ya abonado, sin permanencias ni penalizaciones.
            </p>
          </section>

          {/* Envíos y Devoluciones enlace */}
          <section className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E0D7C8] shadow-xs">
            <h2 className="font-serif text-lg font-bold text-[#1B1C1A] mb-3">
              6. Envíos, Plazos y Derecho de Desistimiento Físico
            </h2>
            <p>
              Para conocer en detalle los plazos de entrega, los 14 días naturales de derecho de desistimiento para productos físicos y el procedimiento de devolución, consulta nuestra{" "}
              <Link href="/devoluciones" className="text-[#4A5D4E] underline font-semibold hover:text-[#D4AF37]">
                Política de Envíos y Devoluciones
              </Link>.
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
