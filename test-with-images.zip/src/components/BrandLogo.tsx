import React from "react";
import Image from "next/image";

interface BrandLogoProps {
  className?: string;
  height?: number;
  tone?: "dark" | "light";
  withWordmark?: boolean;
}

/**
 * Logotipo oficial auténtico de Perla & Pluma
 * Utiliza el archivo original perlayplumalogo.png proporcionado por la creadora.
 */
export function BrandLogo({
  className = "",
  height = 76,
}: BrandLogoProps) {
  return (
    <div className={`relative flex items-center ${className}`}>
      <Image
        src="/images/logo.png"
        alt="Perla & Pluma — Despliega tus alas y enciende tu luz"
        width={340}
        height={height}
        priority
        className="object-contain w-auto transition-transform duration-300 group-hover:scale-105"
        style={{ maxHeight: `${height}px` }}
      />
    </div>
  );
}
