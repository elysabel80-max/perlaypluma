"use client";

import React, { useState } from "react";
import { BrandLogo } from "@/components/BrandLogo";
import { Mandala, MoonPhaseStrip, StarDivider } from "@/components/decor/Ornaments";
import Link from "next/link";
import { Sparkles, Heart, Mail, ShieldCheck, Truck, RefreshCw, Feather } from "lucide-react";

export function Footer() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [feedback, setFeedback] = useState("");

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setStatus("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatus("success");
        setFeedback(data.message || "¡Gracias por unirte a nuestro Círculo de Luz!");
        setEmail("");
      } else {
        setStatus("error");
        setFeedback(data.message || "Ha ocurrido un error. Inténtalo de nuevo.");
      }
    } catch {
      setStatus("error");
      setFeedback("Error de conexión. Inténtalo más tarde.");
    }
  };

  return (
    <footer className="relative bg-[#242B26] text-[#E8E2D9] border-t border-[#38433C] overflow-hidden">
      <Mandala size={720} opacity={0.16} color="#D4AF37" className="pointer-events-none absolute -right-72 -top-56 animate-spin-slower" />
      <Mandala size={520} opacity={0.10} color="#8C9A8F" className="pointer-events-none absolute -left-56 bottom-0 animate-spin-slower-rev" />
      {/* Value props banner */}
      <div className="border-b border-[#38433C]/80 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-6 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-3">
            <div className="p-2.5 rounded-full bg-[#4A5D4E]/40 text-[#D4AF37]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="font-serif text-sm font-semibold text-[#FDFBF7]">Ritualización previa al envío</div>
              <div className="text-xs text-[#A8B3AA]">Limpio y consagrado en nuestro altar</div>
            </div>
          </div>

          <div className="flex items-center justify-center md:justify-start gap-3">
            <div className="p-2.5 rounded-full bg-[#4A5D4E]/40 text-[#D4AF37]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-serif text-sm font-semibold text-[#FDFBF7]">Minerales 100% Auténticos</div>
              <div className="text-xs text-[#A8B3AA]">Sin sintéticos ni tintes químicos</div>
            </div>
          </div>

          <div className="flex items-center justify-center md:justify-start gap-3">
            <div className="p-2.5 rounded-full bg-[#4A5D4E]/40 text-[#D4AF37]">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-serif text-sm font-semibold text-[#FDFBF7]">Empaquetado Protegido</div>
              <div className="text-xs text-[#A8B3AA]">Embalaje seguro y tarjeta personalizada</div>
            </div>
          </div>

          <div className="flex items-center justify-center md:justify-start gap-3">
            <div className="p-2.5 rounded-full bg-[#4A5D4E]/40 text-[#D4AF37]">
              <Feather className="w-5 h-5" />
            </div>
            <div>
              <div className="font-serif text-sm font-semibold text-[#FDFBF7]">Recolección Ética</div>
              <div className="text-xs text-[#A8B3AA]">Palo Santo certificado y cera de abeja pura</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main footer content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand info */}
          <div className="lg:col-span-2 space-y-4">
            <Link href="/" className="inline-block" aria-label="Perla & Pluma — Inicio">
              <BrandLogo height={76} tone="light" />
            </Link>
            <p className="text-xs sm:text-sm text-[#A8B3AA] leading-relaxed max-w-sm">
              Misticismo contemporáneo, luminoso y sereno. Te acompañamos en tu camino con herramientas consagradas, respeto por los ciclos de la tierra y amor por el ritual consciente.
            </p>
            <div className="pt-2 text-xs text-[#8A968D]">
              📍 Creado artesanalmente en España con dedicación espiritual.
            </div>
          </div>

          {/* Catalog links */}
          <div>
            <h4 className="font-serif text-sm font-semibold text-[#FDFBF7] tracking-wider mb-4 border-b border-[#38433C] pb-2 inline-block">
              Colecciones
            </h4>
            <ul className="space-y-2.5 text-xs text-[#B5C2B7]">
              <li>
                <Link href="/catalogo?category=velas-velones" className="hover:text-[#D4AF37] transition-colors">
                  Velas de Miel & Velones
                </Link>
              </li>
              <li>
                <Link href="/catalogo?category=inciensos-aromaterapia" className="hover:text-[#D4AF37] transition-colors">
                  Inciensos & Salvia Sagrada
                </Link>
              </li>
              <li>
                <Link href="/catalogo?category=cuarzos-minerales" className="hover:text-[#D4AF37] transition-colors">
                  Cuarzos & Joyería en Plata 925
                </Link>
              </li>
              <li>
                <Link href="/catalogo?category=kits-rituales" className="hover:text-[#D4AF37] transition-colors">
                  Kits de Rituales Completos
                </Link>
              </li>
              <li>
                <Link href="/catalogo?category=herramientas-misticas" className="hover:text-[#D4AF37] transition-colors">
                  Tarot, Péndulos & Altares
                </Link>
              </li>
              <li>
                <Link href="/circulo-de-luz" className="text-[#D4AF37] hover:underline transition-colors">
                  ✨ Círculo de Luz (Club)
                </Link>
              </li>
            </ul>
          </div>

          {/* Intention links */}
          <div>
            <h4 className="font-serif text-sm font-semibold text-[#FDFBF7] tracking-wider mb-4 border-b border-[#38433C] pb-2 inline-block">
              Por Intención
            </h4>
            <ul className="space-y-2.5 text-xs text-[#B5C2B7]">
              <li>
                <Link href="/catalogo?intention=proteccion" className="hover:text-[#D4AF37] transition-colors">
                  Protección & Limpieza
                </Link>
              </li>
              <li>
                <Link href="/catalogo?intention=calma" className="hover:text-[#D4AF37] transition-colors">
                  Calma, Estrés & Ansiedad
                </Link>
              </li>
              <li>
                <Link href="/catalogo?intention=abundancia" className="hover:text-[#D4AF37] transition-colors">
                  Abundancia & Prosperidad
                </Link>
              </li>
              <li>
                <Link href="/catalogo?intention=amor" className="hover:text-[#D4AF37] transition-colors">
                  Amor Propio & Relaciones
                </Link>
              </li>
              <li>
                <Link href="/catalogo?intention=intuicion" className="hover:text-[#D4AF37] transition-colors">
                  Intuición & Conexión
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter Box */}
          <div className="space-y-3">
            <h4 className="font-serif text-sm font-semibold text-[#FDFBF7] tracking-wider border-b border-[#38433C] pb-2 inline-block">
              Círculo de Luz
            </h4>
            <p className="text-xs text-[#A8B3AA]">
              Suscríbete a nuestras cartas de Luna Llena y recibe un 10% de descuento en tu primer ritual.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tu.correo@ejemplo.com"
                  required
                  className="w-full bg-[#1A201B] border border-[#38433C] rounded-lg px-3 py-2 text-xs text-[#FDFBF7] placeholder-[#6E7B71] focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <button
                type="submit"
                disabled={status === "loading"}
                className="w-full bg-[#D4AF37] hover:bg-[#C29D2D] text-[#1A201B] font-medium text-xs py-2 px-3 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{status === "loading" ? "Conectando..." : "Unirme al Círculo"}</span>
              </button>
            </form>
            {feedback && (
              <p
                className={`text-[11px] leading-tight ${
                  status === "success" ? "text-emerald-400" : "text-rose-400"
                }`}
              >
                {feedback}
              </p>
            )}
          </div>
        </div>

        <StarDivider className="mt-10" color="#D4AF37" />

        {/* Legal Navigation Links Bar */}
        <div className="pt-8 mt-8 border-t border-[#38433C]/80">
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-[#B5C2B7] mb-6">
            <Link href="/aviso-legal" className="hover:text-[#D4AF37] transition-colors">
              Aviso Legal
            </Link>
            <span className="text-[#4A5D4E]">·</span>
            <Link href="/terminos-y-condiciones" className="hover:text-[#D4AF37] transition-colors">
              Términos y Condiciones
            </Link>
            <span className="text-[#4A5D4E]">·</span>
            <Link href="/devoluciones" className="hover:text-[#D4AF37] transition-colors">
              Envíos y Devoluciones
            </Link>
            <span className="text-[#4A5D4E]">·</span>
            <Link href="/politica-de-privacidad" className="hover:text-[#D4AF37] transition-colors">
              Política de Privacidad
            </Link>
            <span className="text-[#4A5D4E]">·</span>
            <Link href="/politica-de-cookies" className="hover:text-[#D4AF37] transition-colors">
              Política de Cookies
            </Link>
          </div>

          {/* Fiscal & Business Identification */}
          <div className="bg-[#1A201B]/80 rounded-xl p-4 border border-[#38433C] text-center text-[11px] text-[#8C9A8F] max-w-4xl mx-auto space-y-1 mb-6">
            <p className="font-medium text-[#C8D3CA]">
              <strong>Perla &amp; Pluma</strong> · Titular: Elisa Isabel Martínez Bueno · NIF: 72975373F
            </p>
            <p>
              Domicilio: Calle San Jorge, 15, Dúplex 9 · Contacto:{" "}
              <a href="mailto:info@perlaypluma.laperladeeli.es" className="underline hover:text-[#D4AF37]">
                info@perlaypluma.laperladeeli.es
              </a>{" "}
              · Tel:{" "}
              <a href="tel:+34685544054" className="underline hover:text-[#D4AF37]">
                +34 685 54 40 54
              </a>
            </p>
          </div>

          {/* Bottom copyright */}
          <div className="flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#7C887F] gap-3">
            <p>© {new Date().getFullYear()} Perla &amp; Pluma — Misticismo Contemporáneo. Todos los derechos reservados.</p>
            <div className="flex flex-wrap gap-4 items-center">
              <Link href="/guias" className="hover:underline">Blog Místico</Link>
              <Link href="/nosotros" className="hover:underline">Compromiso Ético</Link>
              <Link href="/catalogo" className="hover:underline">Catálogo General</Link>
              <Link href="/admin/catalogo" className="text-[#D4AF37] hover:underline flex items-center gap-1 font-medium">
                <span>⚙️ Gestor Catálogo</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
