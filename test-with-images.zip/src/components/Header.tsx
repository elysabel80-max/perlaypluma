"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useCart } from "@/context/CartContext";
import { CATEGORIES, INTENTIONS } from "@/data/categories";
import { BrandLogo } from "@/components/BrandLogo";
import { FREE_SHIPPING_THRESHOLD } from "@/lib/shipping";
import { MoonPhaseStrip } from "@/components/decor/Ornaments";
import {
  ShoppingBag,
  Sparkles,
  Search,
  Menu,
  X,
  Heart,
  ChevronDown,
  Shield,
  Feather,
  Sun,
  Moon,
} from "lucide-react";

export function Header() {
  const { totalItems, openCart } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [catalogDropdownOpen, setCatalogDropdownOpen] = useState(false);
  const [intentionDropdownOpen, setIntentionDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchBarOpen, setSearchBarOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/catalogo?q=${encodeURIComponent(searchQuery.trim())}`;
    }
  };

  const getIntentionIcon = (iconName: string) => {
    switch (iconName) {
      case "Shield":
        return <Shield className="w-4 h-4 text-stone-700" />;
      case "Feather":
        return <Feather className="w-4 h-4 text-emerald-700" />;
      case "Sun":
        return <Sun className="w-4 h-4 text-amber-700" />;
      case "Heart":
        return <Heart className="w-4 h-4 text-rose-700" />;
      case "Moon":
        return <Moon className="w-4 h-4 text-violet-700" />;
      default:
        return <Sparkles className="w-4 h-4 text-[#D4AF37]" />;
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FDFBF7]/95 backdrop-blur-md border-b border-[#E8E2D9] transition-all">
      <span className="pointer-events-none absolute inset-x-0 bottom-0 h-px gold-hairline opacity-60" aria-hidden="true" />
      {/* Top Banner - Subtle mystic message */}
      <div className="bg-[#4A5D4E] text-[#FDFBF7] text-xs font-serif tracking-wider py-1.5 px-4 text-center">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
          <span>
            Cada pedido se limpia con humo sagrado y se intenciona antes de salir de nuestro altar • Envío gratis desde {FREE_SHIPPING_THRESHOLD}€
          </span>
          <span className="hidden md:block opacity-80">
            <MoonPhaseStrip size={12} color="#E8CD82" />
          </span>
          <Sparkles className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-24">
          {/* Mobile menu trigger */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-[#2B352E] hover:text-[#4A5D4E] focus:outline-none"
              aria-label="Abrir menú"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Marca: perla + pluma con logo ampliado y lema oficial */}
          <div className="flex items-center">
            <Link
              href="/"
              className="group flex flex-col items-start justify-center py-1"
              aria-label="Perla & Pluma — Inicio"
            >
              <BrandLogo height={74} className="hidden sm:block" />
              <BrandLogo height={56} className="sm:hidden" />
              <span className="text-[11px] sm:text-[12px] font-serif italic text-[#735c00] tracking-wide mt-1 font-medium">
                Despliega tus alas y enciende tu luz
              </span>
            </Link>
          </div>

          {/* Desktop Dual Navigation: Bloque A (Categorías) & Bloque B (Intención) */}
          <nav className="hidden lg:flex items-center space-x-7">
            <Link
              href="/"
              className="text-sm font-medium text-[#2B352E] hover:text-[#4A5D4E] transition-colors"
            >
              Inicio
            </Link>

            {/* Bloque A: Menú Catálogo */}
            <div
              className="relative"
              onMouseEnter={() => setCatalogDropdownOpen(true)}
              onMouseLeave={() => setCatalogDropdownOpen(false)}
            >
              <Link
                href="/catalogo"
                className="flex items-center gap-1 text-sm font-medium text-[#2B352E] hover:text-[#4A5D4E] py-2 transition-colors"
              >
                <span>Catálogo Sagrado</span>
                <ChevronDown className="w-3.5 h-3.5 text-stone-500" />
              </Link>

              {catalogDropdownOpen && (
                <div className="absolute top-full left-0 w-80 bg-[#FDFBF7] rounded-xl shadow-xl border border-[#E8E2D9] p-4 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="text-xs font-semibold uppercase tracking-wider text-[#4A5D4E] pb-2 border-b border-[#E8E2D9]/60 mb-2">
                    Navegación por Colección
                  </div>
                  <div className="space-y-1">
                    {CATEGORIES.map((cat) => (
                      <Link
                        key={cat.id}
                        href={`/catalogo?category=${cat.id}`}
                        className="block p-2 rounded-lg hover:bg-[#F2ECE1] transition-colors group"
                        onClick={() => setCatalogDropdownOpen(false)}
                      >
                        <div className="text-sm font-serif font-medium text-[#2B352E] group-hover:text-[#4A5D4E]">
                          {cat.name}
                        </div>
                        <div className="text-[11px] text-[#78857C] line-clamp-1">
                          {cat.subcategories.slice(0, 2).join(", ")}...
                        </div>
                      </Link>
                    ))}
                    <div className="pt-2 border-t border-[#E8E2D9]/60">
                      <Link
                        href="/catalogo"
                        className="block text-center text-xs font-medium text-[#4A5D4E] hover:underline"
                        onClick={() => setCatalogDropdownOpen(false)}
                      >
                        Ver todos los artículos →
                      </Link>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Bloque B: Navegación por Intención / Propósito */}
            <div
              className="relative"
              onMouseEnter={() => setIntentionDropdownOpen(true)}
              onMouseLeave={() => setIntentionDropdownOpen(false)}
            >
              <button
                className="flex items-center gap-1.5 text-sm font-medium text-[#4A5D4E] bg-[#4A5D4E]/8 hover:bg-[#4A5D4E]/15 px-3 py-1.5 rounded-full transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>¿Qué energía buscas?</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {intentionDropdownOpen && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 w-96 bg-[#FDFBF7] rounded-xl shadow-xl border border-[#E8E2D9] p-4 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="text-xs font-semibold uppercase tracking-wider text-[#4A5D4E] pb-2 border-b border-[#E8E2D9]/60 mb-2">
                    Filtro Emocional / Propósito
                  </div>
                  <div className="space-y-1.5">
                    {Object.values(INTENTIONS).map((item) => (
                      <Link
                        key={item.id}
                        href={`/catalogo?intention=${item.id}`}
                        className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-[#F2ECE1] transition-colors group"
                        onClick={() => setIntentionDropdownOpen(false)}
                      >
                        <div className="p-2 rounded-full bg-[#EAE3D6] group-hover:bg-[#D4AF37]/20">
                          {getIntentionIcon(item.iconName)}
                        </div>
                        <div className="flex-1">
                          <div className="text-xs font-serif font-semibold text-[#2B352E] group-hover:text-[#4A5D4E]">
                            {item.name}
                          </div>
                          <p className="text-[11px] text-[#637066] line-clamp-1 mt-0.5">
                            {item.description}
                          </p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Link
              href="/circulo-de-luz"
              className="flex items-center gap-1 text-sm font-medium text-[#4A5D4E] hover:text-[#242B26] transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Círculo de Luz</span>
            </Link>

            <Link
              href="/guias"
              className="text-sm font-medium text-[#2B352E] hover:text-[#4A5D4E] transition-colors"
            >
              Guías & Blog
            </Link>
            <Link
              href="/nosotros"
              className="text-sm font-medium text-[#2B352E] hover:text-[#4A5D4E] transition-colors"
            >
              El Altar
            </Link>
          </nav>

          {/* Right actions: Search + Cart */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            {/* Quick search button */}
            <div className="relative">
              {searchBarOpen ? (
                <form
                  onSubmit={handleSearchSubmit}
                  className="flex items-center bg-[#F2ECE1] rounded-full px-3 py-1.5 border border-[#D9D1C5] shadow-inner"
                >
                  <Search className="w-4 h-4 text-[#6B786E] mr-2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Vela de miel, turmalina..."
                    className="bg-transparent text-xs text-[#2B352E] focus:outline-none w-36 sm:w-48 placeholder-[#8A968D]"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setSearchBarOpen(false)}
                    className="text-[#6B786E] hover:text-[#2B352E] ml-1"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </form>
              ) : (
                <button
                  onClick={() => setSearchBarOpen(true)}
                  className="p-2 rounded-full text-[#2B352E] hover:bg-[#F2ECE1] transition-colors"
                  aria-label="Buscar producto"
                >
                  <Search className="w-5 h-5 text-[#4A5D4E]" />
                </button>
              )}
            </div>

            {/* Cart trigger button */}
            <button
              onClick={openCart}
              className="relative p-2.5 rounded-full bg-[#4A5D4E] text-[#FDFBF7] hover:bg-[#3B4B3F] transition-colors shadow-sm flex items-center justify-center group"
              aria-label="Ver bolsa de compras"
            >
              <ShoppingBag className="w-5 h-5 group-hover:scale-105 transition-transform" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#D4AF37] text-[#222] font-semibold text-[11px] w-5 h-5 rounded-full flex items-center justify-center shadow-md animate-pulse">
                  {totalItems}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#E8E2D9] bg-[#FDFBF7] px-4 pt-3 pb-6 space-y-4 shadow-lg animate-in fade-in duration-200">
          <form onSubmit={handleSearchSubmit} className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar velas, inciensos, gemas..."
              className="w-full bg-[#F2ECE1] border border-[#D9D1C5] rounded-lg px-4 py-2.5 text-sm focus:outline-none"
            />
            <button
              type="submit"
              className="absolute right-3 top-2.5 text-[#4A5D4E]"
            >
              <Search className="w-5 h-5" />
            </button>
          </form>

          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-[#4A5D4E] mb-2">
              Categorías
            </div>
            <div className="space-y-1 pl-2">
              {CATEGORIES.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/catalogo?category=${cat.id}`}
                  className="block text-sm py-1.5 text-[#2B352E] hover:text-[#4A5D4E]"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {cat.name}
                </Link>
              ))}
            </div>
          </div>

          <div className="pt-2 border-t border-[#E8E2D9]">
            <div className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] mb-2 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Por Intención</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {Object.values(INTENTIONS).map((item) => (
                <Link
                  key={item.id}
                  href={`/catalogo?intention=${item.id}`}
                  className="p-2 rounded-lg bg-[#F2ECE1] text-xs font-serif text-[#2B352E] hover:bg-[#EAE3D6] flex items-center gap-1.5"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {getIntentionIcon(item.iconName)}
                  <span>{item.name.split("&")[0]}</span>
                </Link>
              ))}
            </div>
          </div>

          <div className="pt-2 border-t border-[#E8E2D9] flex justify-between text-sm">
            <Link
              href="/circulo-de-luz"
              className="text-[#D4AF37] font-semibold"
              onClick={() => setMobileMenuOpen(false)}
            >
              Círculo de Luz
            </Link>
            <Link
              href="/guias"
              className="text-[#4A5D4E] font-medium"
              onClick={() => setMobileMenuOpen(false)}
            >
              Guías & Blog Místico
            </Link>
            <Link
              href="/nosotros"
              className="text-[#4A5D4E] font-medium"
              onClick={() => setMobileMenuOpen(false)}
            >
              Sobre Perla & Pluma
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
