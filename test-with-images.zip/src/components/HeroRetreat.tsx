import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Sparkles } from "lucide-react";
import { Mandala, MoonPhaseStrip } from "@/components/decor/Ornaments";

/**
 * Portada: primero la fotografía, después el mensaje.
 * Réplica del hero del deck: salvia blanca, perla y concha sobre lino,
 * con logotipo serif y CTA dorado superpuestos.
 */
export function HeroRetreat() {
  return (
    <section className="relative">
      <div className="relative w-full min-h-screen h-[100dvh] overflow-hidden bg-[#1E2620]">
        <Image
          src="/images/hero-retiro.jpg"
          alt="Mesa con velas, amatistas y cuarzos: el retiro esotérico contemporáneo de Perla & Pluma"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center scale-[1.02]"
        />

        {/* Geometría sagrada dorada sobre la fotografía */}
        <Mandala
          size={1150}
          opacity={0.30}
          color="#F0DBA4"
          className="pointer-events-none absolute -right-1/3 -top-1/4 hidden sm:block animate-spin-slower"
        />
        <Mandala
          size={620}
          opacity={0.22}
          color="#F0DBA4"
          className="pointer-events-none absolute -left-40 -bottom-40 animate-spin-slower-rev"
        />

        {/* Legibilidad sin oscurecer la estética luminosa */}
        <div className="absolute inset-0 bg-linear-to-t from-[#1E2620]/80 via-[#1E2620]/25 to-transparent" />
        <div className="absolute inset-0 bg-linear-to-r from-[#1E2620]/25 via-transparent to-transparent" />

        {/* Contenido sobre la imagen */}
        <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-end pb-10 sm:pb-14">
          <div className="max-w-2xl space-y-4 sm:space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FDFBF7]/15 backdrop-blur-md border border-[#FDFBF7]/25 text-[10px] sm:text-[11px] uppercase tracking-[0.25em] text-[#F3EDE2] font-medium w-fit">
              <Sparkles className="w-3 h-3 text-[#D4AF37]" />
              <span>Perla & Pluma</span>
              <span className="w-1 h-1 rounded-full bg-[#D4AF37]" />
            </div>

            <h1 className="font-serif text-[2rem] leading-[1.1] sm:text-4xl lg:text-5xl text-[#FDFBF7] font-normal drop-shadow-sm max-w-2xl">
              Tu tienda esotérica online
              <span className="block italic text-[#E8CD82] mt-1 text-[1.8rem] sm:text-4xl lg:text-5xl">para elevar tu vibración diaria</span>
            </h1>

            <p className="text-xs sm:text-sm lg:text-base text-[#E8E2D9] max-w-xl leading-relaxed">
              Descubre minerales 100% naturales, inciensos artesanales y kits de rituales seleccionados con mimo y preparados con la mejor energía para acompañarte en tu día a día.
            </p>

            <div className="pt-1">
              <MoonPhaseStrip size={15} color="#F0DBA4" />
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-5 pt-1">
              <Link
                href="/catalogo"
                className="inline-flex items-center justify-center gap-2 bg-[#D4AF37] hover:bg-[#C29D2D] text-[#242B26] px-7 py-3.5 sm:py-4 rounded-xl text-[11px] sm:text-xs uppercase tracking-[0.18em] font-semibold transition-colors shadow-lg"
              >
                <span>Explorar colección</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/circulo-de-luz"
                className="text-[11px] sm:text-xs uppercase tracking-[0.18em] font-medium text-[#FDFBF7]/90 hover:text-[#D4AF37] transition-colors text-center sm:text-left underline underline-offset-4 decoration-[#D4AF37]/50"
              >
                Círculo de Luz
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Indicador de scroll, tal como en el deck */}
      <div className="relative bg-[#FDFBF7] py-5 flex flex-col items-center gap-2 overflow-hidden">
        <Mandala size={150} opacity={0.35} className="pointer-events-none absolute -top-16 left-1/2 -translate-x-1/2 animate-spin-slower" />
        <span className="relative text-[10px] uppercase tracking-[0.3em] text-[#8A968D]">
          Desliza para comenzar el recorrido
        </span>
        <span className="relative h-8 w-px bg-linear-to-b from-[#C9BFAE] to-transparent" />
        <span className="relative w-1.5 h-1.5 rounded-full bg-[#C9A24A]" />
      </div>
    </section>
  );
}
