"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Sparkles, Shield, Feather, Sun, Heart, Moon, ArrowRight, Check } from "lucide-react";
import { INTENTIONS } from "@/data/categories";
import { Mandala, SectionOrnament, Sigil, StarDivider, type SigilName } from "@/components/decor/Ornaments";

/**
 * Sección del deck: "¿Qué necesitas transformar o atraer hoy?" (Bloque B).
 * Cinco propósitos con iconografía serena + manifiesto en verde botánico.
 */
export function IntentionSelector() {
  const [selectedIntention, setSelectedIntention] = useState<string>("proteccion");
  const current = INTENTIONS[selectedIntention] || INTENTIONS.proteccion;

  const getIcon = (id: string) => {
    switch (id) {
      case "proteccion":
        return <Shield className="w-5 h-5" />;
      case "calma":
        return <Feather className="w-5 h-5" />;
      case "abundancia":
        return <Sun className="w-5 h-5" />;
      case "amor":
        return <Heart className="w-5 h-5" />;
      case "intuicion":
        return <Moon className="w-5 h-5" />;
      default:
        return <Sparkles className="w-5 h-5" />;
    }
  };

  return (
    <section id="intenciones" className="relative py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-[#F4EFE6] border-y border-[#E8E2D9] overflow-hidden">
      <Mandala size={780} opacity={0.13} className="pointer-events-none absolute -left-64 top-1/2 -translate-y-1/2 hidden md:block animate-spin-slower-rev" />
      <div className="relative max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <SectionOrnament label="Navegación por intención · Bloque B" />
          <h2 className="font-serif text-2xl sm:text-4xl lg:text-[2.6rem] text-[#242B26] font-normal leading-tight">
            ¿Qué necesitas transformar o atraer hoy?
          </h2>
          <StarDivider className="mt-5" />
          <p className="text-xs sm:text-sm text-[#5B675E] mt-3 leading-relaxed">
            No busques por categorías infinitas: elige cómo te sientes y te acompañamos hacia la
            herramienta sagrada afín a tu momento vital.
          </p>
        </div>

        {/* Five purpose cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4 mb-8">
          {Object.values(INTENTIONS).map((item) => {
            const isSelected = selectedIntention === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setSelectedIntention(item.id)}
                className={`group text-left rounded-2xl p-4 sm:p-5 border transition-all duration-300 flex flex-col gap-3 ${
                  isSelected
                    ? "bg-[#FDFBF7] border-[#4A5D4E] shadow-md -translate-y-0.5"
                    : "bg-[#FDFBF7]/80 border-[#E0D7C8] hover:border-[#C9BFAE] hover:shadow-sm"
                }`}
                aria-pressed={isSelected}
              >
                <div className="flex items-center justify-between">
                  <span className="relative flex items-center justify-center w-11 h-11">
                    <svg viewBox="0 0 44 44" className="absolute inset-0 w-full h-full" fill="none" aria-hidden="true">
                      <circle cx="22" cy="22" r="21" stroke="#C9A24A" strokeWidth="0.7" strokeDasharray="1 3" opacity="0.75" />
                      <circle cx="22" cy="22" r="17.5" stroke="#C9A24A" strokeWidth="0.6" opacity="0.5" />
                    </svg>
                    <span
                      className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                        isSelected ? "bg-[#4A5D4E] text-[#D4AF37]" : "bg-[#EFE9DD] text-[#4A5D4E]"
                      }`}
                    >
                      {getIcon(item.id)}
                    </span>
                  </span>
                  {isSelected && (
                    <span className="w-5 h-5 rounded-full bg-[#D4AF37] text-[#242B26] flex items-center justify-center">
                      <Check className="w-3 h-3" />
                    </span>
                  )}
                </div>

                <div>
                  <div className="font-serif text-sm sm:text-base font-bold text-[#1B1C1A] leading-snug">
                    {item.name}
                  </div>
                  <div className="text-[11px] sm:text-xs uppercase tracking-wider text-[#334537] font-bold mt-1.5 leading-snug">
                    {item.badge}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected intention detail with Blueprint formula & #BrujiTip */}
        <div className="bg-[#FDFBF7] rounded-3xl overflow-hidden border border-[#D8C79E] shadow-sm grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-4 relative aspect-4/3 lg:aspect-auto min-h-[220px] bg-stone-200">
            <Image
              src={current.image}
              alt={current.name}
              fill
              sizes="(max-width: 1024px) 100vw, 400px"
              className="object-cover"
            />
            <div className="absolute top-3 left-3 bg-[#FDFBF7] px-3.5 py-1.5 rounded-full text-xs font-serif font-bold text-[#334537] flex items-center gap-1.5 shadow-sm border border-[#D8C79E]">
              {getIcon(current.id)}
              <span>{current.badge}</span>
            </div>
          </div>

          <div className="lg:col-span-8 p-6 sm:p-8 flex flex-col justify-between gap-5">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="text-[11px] uppercase tracking-widest text-[#334537] font-bold">Enfoque:</span>
                <span className="text-sm text-[#2B352E] italic">{current.focus || current.description}</span>
              </div>

              <h3 className="font-serif text-2xl sm:text-3xl text-[#1B1C1A] font-bold mb-3">{current.name}</h3>

              {/* Tags de exploración */}
              {current.tags && current.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-4">
                  {current.tags.map((tag, idx) => (
                    <span key={idx} className="px-3.5 py-1.5 rounded-full bg-[#EFE9DD] text-[#1B1C1A] text-xs font-semibold border border-[#D8C79E]/60">
                      [ {tag} ]
                    </span>
                  ))}
                </div>
              )}

              {/* Viñeta Ilustrada de la Fórmula según Blueprint */}
              {current.formulaVignette && (
                <div className="mb-4 overflow-hidden rounded-2xl border border-[#D8C79E] bg-[#FAF7F0] p-2 shadow-2xs">
                  <Image
                    src={current.formulaVignette}
                    alt={`Fórmula ilustrada para ${current.name}`}
                    width={1035}
                    height={215}
                    className="w-full h-auto object-contain rounded-xl"
                  />
                </div>
              )}

              {/* Fórmula de Cross-Selling del Blueprint */}
              {current.formulaItems && !current.formulaVignette && (
                <div className="p-4 rounded-2xl bg-[#F5F3EF] border border-[#E0D7C8] mb-4">
                  <div className="text-xs uppercase tracking-widest text-[#735c00] font-bold mb-2">
                    Fórmula de Ritual &amp; Kit:
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm font-semibold text-[#1B1C1A]">
                    {current.formulaItems.map((item, idx) => (
                      <React.Fragment key={idx}>
                        <span className="px-3 py-1.5 rounded-lg bg-white border border-[#D8C79E] shadow-2xs">
                          {item}
                        </span>
                        {idx < (current.formulaItems?.length || 0) - 1 && (
                          <span className="text-[#D4AF37] font-bold text-sm">+</span>
                        )}
                      </React.Fragment>
                    ))}
                    <span className="text-[#334537] font-bold text-sm">=</span>
                    <span className="px-3.5 py-1.5 rounded-lg bg-[#334537] text-[#FDFBF7] font-serif font-bold shadow-xs">
                      {current.kitResult}
                    </span>
                  </div>
                </div>
              )}

              {/* Recuadro BrujiTip */}
              {current.brujiTip && (
                <div className="relative pl-4 border-l-3 border-[#D4AF37] py-2 bg-[#FAF7F0] pr-4 rounded-r-xl">
                  <p className="text-sm text-[#1B1C1A] leading-relaxed italic">
                    <strong className="text-[#735c00] not-italic font-bold font-serif">#BrujiTip:</strong> {current.brujiTip}
                  </p>
                </div>
              )}
            </div>

            <div className="space-y-3 pt-3 border-t border-[#E8E2D9]">
              <div className="p-3.5 rounded-xl bg-[#EFE9DD] border border-[#D8C79E]">
                <span className="text-xs font-bold text-[#334537] uppercase tracking-wider block mb-1">
                  Elementos clave recomendados:
                </span>
                <span className="text-sm sm:text-base font-semibold text-[#1B1C1A] leading-snug">
                  {current.recommendedElements}
                </span>
              </div>
              
              <div className="flex justify-end pt-1">
                <Link
                  href={`/catalogo?intention=${current.id}`}
                  className="inline-flex items-center justify-center gap-2 bg-[#334537] hover:bg-[#242B26] text-[#FDFBF7] px-7 py-3.5 rounded-xl text-xs uppercase tracking-[0.15em] font-bold transition-colors shadow-xs"
                >
                  <span>Ver colección &amp; kit</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Manifesto banner ajustado sin mención a 24/48h ni regalos universales */}
        <div className="mt-8 rounded-2xl bg-[#334537] px-6 py-6 sm:px-8 sm:py-7 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <p className="text-sm sm:text-base text-[#FDFBF7] leading-relaxed max-w-2xl font-light">
            <span className="font-serif font-bold text-[#FFE088]">Cada pieza se limpia y se intenciona artesanalmente en nuestro altar antes del envío.</span>{" "}
            Obsequios rituales y gemas sagradas exclusivas para miembros del Círculo de Luz.
          </p>
          <Link
            href="/circulo-de-luz"
            className="shrink-0 text-xs uppercase tracking-[0.15em] font-bold text-[#242B26] bg-[#D4AF37] hover:bg-[#C29D2D] px-6 py-3.5 rounded-xl transition-colors shadow-md"
          >
            Círculo de Luz
          </Link>
        </div>
      </div>
    </section>
  );
}
