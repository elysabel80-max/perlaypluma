export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string;
  image: string;
  content: string[];
  isFree?: boolean;
  price?: string;
}

export const BLOG_POSTS: BlogPost[] = [
  {
    slug: "como-hacer-limpieza-energetica-casa",
    title: "Cómo hacer una limpieza energética profunda en casa: Guía paso a paso",
    excerpt: "Aprende a desalojar la pesadez ambiental con salvia blanca, sal marina y palo santo sin rituales complejos ni dogmas.",
    category: "Guía Abierta Gratuita",
    readTime: "6 min de lectura",
    date: "12 de Marzo, 2026",
    isFree: true,
    image: "https://images.pexels.com/photos/8436503/pexels-photo-8436503.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    content: [
      "Los espacios acumulan memoria emocional. Discusiones, temporadas de estrés, visitas con vibraciones pesadas o simplemente el paso del tiempo pueden hacer que un hogar se sienta denso, frío o inquietante.",
      "Antes de comenzar, abre al menos una ventana hacia el exterior. El humo no debe quedar atrapado, sino servir de vehículo para arrastrar hacia fuera todo estancamiento.",
      "Paso 1: Sahúmo de expulsión. Enciende tu atado de salvia blanca silvestre o defumación de ruda. Recorre las esquinas de cada estancia en sentido contrario a las agujas del reloj, pues los vértices de las paredes suelen condensar el cansancio acumulado.",
      "Paso 2: Neutralización. Coloca en un cuenco pequeño un puñado de sal marina gruesa con unas gotas de Agua de Florida detrás de la puerta principal.",
      "Paso 3: Bendición y llenado. Con palo santo o incienso de mirra, recorre de nuevo el espacio, esta vez en sentido horario, visualizando luz dorada e intencionando serenidad, risas y descanso reparador.",
    ],
  },
  {
    slug: "guia-para-elegir-primer-cristal",
    title: "Guía para elegir tu primer cristal: Escucha a tu intuición",
    excerpt: "Turmalina, cuarzo rosa o amatista: descubre cuál es la piedra que te está llamando según tu momento vital actual.",
    category: "Exclusivo Círculo de Luz",
    readTime: "4 min de lectura",
    date: "05 de Marzo, 2026",
    isFree: false,
    price: "4,90 €",
    image: "https://images.pexels.com/photos/38684710/pexels-photo-38684710.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    content: [
      "En el mundo de los minerales existe una regla de oro: el cristal que más necesitas es siempre el primero en el que tus ojos se posan sin buscarlo.",
      "Si sientes una fuerte necesidad de protegerte del cansancio ajeno o el ambiente laboral hostil, tu guardián indiscutible es la Turmalina Negra en bruto.",
      "Si estás transitando un proceso de sanación afectiva, duelo o necesitas perdonarte y tratarte con ternura, el Cuarzo Rosa de Madagascar envolverá tu pecho con un bálsamo reconfortante.",
      "Para quienes padecen insomnio, sobrecarga mental y exceso de pensamientos circulares, la Drusa de Amatista colocada en la mesita de noche equilibra los ciclos circadianos y aporta lucidez a los sueños.",
    ],
  },
  {
    slug: "significado-del-humo-del-incienso",
    title: "El significado del humo del incienso: Lectura e interpretación de signos",
    excerpt: "¿Tu humo sube recto, se divide en dos o hace espirales rápidas? Descubre qué te está comunicando el elemento aire.",
    category: "Exclusivo Círculo de Luz",
    readTime: "5 min de lectura",
    date: "26 de Febrero, 2026",
    isFree: false,
    price: "4,90 €",
    image: "https://images.pexels.com/photos/17840021/pexels-photo-17840021.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    content: [
      "La libanomancia o lectura del humo es una de las prácticas adivinatorias más antiguas de Oriente y del Mediterráneo antiguo.",
      "Humo recto y vertical: Indica que la petición asciende sin interferencias. Hay una conexión diáfana con tu intención y el entorno está receptivo.",
      "Humo en espirales concéntricas: El humo está transmutando energías densas presentes en la habitación. Deja que trabaje tranquilamente.",
      "Humo dividido en dos vertientes: Simboliza dudas internas o que tu mente está oscilando entre dos decisiones opuestas. Siéntate a respirar y aclara tu verdadero deseo.",
      "Humo denso y negro al principio: Está quemando negatividad estancada de forma acelerada. Espera a que se torne blanco grisáceo para concluir tu oración.",
    ],
  },
];
