export interface SubcategoryMeta {
  title: string;
  category: string;
  shortTag: string;
  image: string;
  introSummary: string;
  description: string;
  ritualUse: string;
  brujiTip?: string;
  iconName?: string;
}

export const SUBCATEGORY_DESCRIPTIONS: Record<string, SubcategoryMeta> = {
  // --- VELAS & VELONES ---
  "Velones de Propósito y Ritualizados": {
    title: "Velones de Propósito & Fuego Ritual",
    category: "velas-velones",
    shortTag: "Alta Magia & Peticiones",
    image: "https://images.pexels.com/photos/10837872/pexels-photo-10837872.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Cera teñida en masa y consagrada para sostener peticiones profundas de corte, protección y apertura de caminos.",
    description:
      "Los velones de propósito son faros de energía continua. A diferencia de las velas decorativas comunes, su cera vegetal está ungida con extractos botánicos, hierbas sagradas y aceites litúrgicos específicos. Cada color vibra con una frecuencia arquetípica destinada a manifestar, transmutar o limpiar densidades.",
    ritualUse:
      "Se utilizan en conjuros, novenas y rituales de sellado. Es imprescindible escribir tu intención desde la base hacia la mecha (para atraer) o de la mecha a la base (para alejar o cortar) y dejarlos consumir en un espacio seguro sin interrumpir su llama.",
    brujiTip:
      "Conságralo siempre con cerillas de madera y observa el llanto de la cera: un quemado limpio indica que tu petición fluye sin resistencias cósmicas.",
  },
  "Velas de Miel Natural": {
    title: "Velas de Miel Pura de Abeja",
    category: "velas-velones",
    shortTag: "Dulce Alquimia Solar",
    image: "https://images.pexels.com/photos/38489189/pexels-photo-38489189.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Enrolladas a mano con cera de opérculo 100% pura virgen. Endulzamiento natural, armonía en el hogar y prosperidad.",
    description:
      "Enrolladas a mano con láminas de cera pura virgen de opérculo, las velas de miel emanan un aroma cálido y dulce natural que eleva de inmediato la vibración de cualquier hogar. En la tradición ancestral, la miel es el símbolo máximo de la fecundidad, la abundancia y la reconciliación amorosa.",
    ritualUse:
      "Encendidas especialmente los días 11 y 22 de cada mes, activan la energía cósmica de la prosperidad y el endulzamiento de relaciones y vínculos afectivos.",
    brujiTip:
      "Al no contener parafinas derivadas del petróleo, el humo residual es completamente purificador y seguro para niños y mascotas.",
  },
  "Velas Aromáticas con Cristales": {
    title: "Velas Botánicas con Cristales Reales",
    category: "velas-velones",
    shortTag: "Gemo-Aromaterapia",
    image: "https://images.pexels.com/photos/30235380/pexels-photo-30235380.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Cera de soja infusionada con aceites botánicos puros y coronada con gemas naturales sin tratar.",
    description:
      "Velas artesanales elaboradas con cera de soja 100% natural infusionada con aceites esenciales puros y coronadas con auténticos cuarzos y flores secas. A medida que la cera se funde, el calor activa el campo piezoeléctrico del mineral, liberando su frecuencia curativa en el ambiente.",
    ritualUse:
      "Ideales para acompañar sesiones de yoga, meditación, lectura de tarot o baños de descarga energética.",
    brujiTip:
      "Una vez consumida la vela, rescata el cristal, lávalo suavemente con agua tibia y consérvalo como amuleto permanente en tu altar.",
  },
  "Velas de Colores y Formas": {
    title: "Velas de Altar & Formas Simbólicas",
    category: "velas-velones",
    shortTag: "Cromoterapia Mística",
    image: "https://images.pexels.com/photos/6931837/pexels-photo-6931837.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Canalización de energías a través de las frecuencias de color y formas arquetípicas consagradas.",
    description:
      "La cromoterapia mágica canaliza la vibración de cada longitud de onda de color: blanco para purificación y luz divina, rojo para vitalidad y pasión, verde para salud y finanzas, morado para transmutación y negro para absorción de densidades.",
    ritualUse:
      "Utilizadas como testigos en altares ceremoniales o para vestir rituales astrológicos lunares.",
    brujiTip:
      "Viste la vela con aceites litúrgicos específicos antes de encenderla para triplicar la fuerza de tu invocación.",
  },

  // --- HERRAMIENTAS MÍSTICAS & ADIVINACIÓN ---
  "Runas Sagradas & Adivinación": {
    title: "Runas Nórdicas & Futhark Antiguo",
    category: "herramientas-misticas",
    shortTag: "Oráculo de la Sabiduría Ancestral",
    image: "https://images.pexels.com/photos/30828554/pexels-photo-30828554.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "El alfabeto sagrado vikingo de 24 glifos. Arquetipos cósmicos del destino (Wyrd) para consejo intuitivo y protección.",
    description:
      "Las runas no son letras convencionales: son arquetipos cósmicos vivos originarios de las tradiciones nórdicas y germánicas. El Elder Futhark se compone de 24 símbolos tallados en piedras preciosas o madera de fresno sagrado, más la runa blanca de Odín. Cada trazo desvela fuerzas que operan en el tejido del destino, advirtiendo sobre obstáculos invisibles y señalando puertas de evolución consciente.",
    ritualUse:
      "Se extraen de su bolsa de terciopelo tras concentrar tu aliento en una pregunta clara. Se consultan en tiradas de 1 a 3 runas (pasado, presente, consejo) o se usan como amuletos de grabado en velas y madera para conjuros de protección y valor.",
    brujiTip:
      "Antes de realizar una lectura, agita suavemente las runas entre tus palmas transmitiéndoles el calor de tu aliento para sincronizarlas con tu campo energético.",
  },
  "Tarot & Oráculos": {
    title: "Barajas de Tarot & Cartas Oraculares",
    category: "herramientas-misticas",
    shortTag: "Arquetipos del Inconsciente",
    image: "https://images.pexels.com/photos/30828553/pexels-photo-30828553.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Espejos simbólicos del alma diseñados para canalizar sincronicidades y clarificar el camino interior.",
    description:
      "El Tarot es un mapa arquetípico del viaje del ser humano. A través de sus 78 arcanos, el simbolismo dialoga con tu intuición para desvelar aquello que la mente consciente aún no ha descifrado. Es una herramienta de crecimiento personal, no de fatalismo.",
    ritualUse:
      "Lecturas terapéuticas, meditación diaria con la 'carta del día' y consagración en el altar durante lunas nuevas.",
    brujiTip:
      "Guarda siempre tu baraja envuelta en un paño de terciopelo o seda con un cuarzo transparente encima para descargar cualquier residuo energético.",
  },
  "Péndulos de Radiestesia": {
    title: "Péndulos de Radiestesia & Geometría",
    category: "herramientas-misticas",
    shortTag: "Sensibilidad & Alineación de Chakras",
    image: "https://images.pexels.com/photos/7947728/pexels-photo-7947728.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Instrumentos de resonancia neuromuscular tallados en gemas nobles para diagnóstico y armonización de centros energéticos.",
    description:
      "Instrumentos de alta precisión que amplifican los micromovimientos neuromusculares inducidos por la intuición superior. Tallados en gemas nobles como amatista, cuarzo rosa o selenita con cadenas equilibradas.",
    ritualUse:
      "Diagnóstico y desbloqueo de los 7 centros energéticos (chakras), búsqueda oracular binaria (sí / no) y testeo de vibración de objetos o alimentos.",
    brujiTip:
      "Pide a tu péndulo que te muestre su movimiento para el 'SÍ' y para el 'NO' antes de cada consulta para calibrarlo.",
  },
  "Sonido Sagrado & Meditación": {
    title: "Cuencos Tibetanos & Campanas Ceremoniales",
    category: "herramientas-misticas",
    shortTag: "Frecuencias Curativas 432Hz",
    image: "https://images.pexels.com/photos/6766581/pexels-photo-6766581.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Ondas acústicas forjadas artesanalmente para disolver nudos de tensión y limpiar campos energéticos.",
    description:
      "Herramientas de vibración acústica forjadas artesanalmente. El sonido armónico produce ondas alfa en el cerebro que aquietan al instante la mente dispersa y barren campos electromagnéticos nocivos de cualquier estancia.",
    ritualUse:
      "Apertura y cierre de ceremonias, meditación profunda guiada y limpieza de piedras y cristales por resonancia acústica.",
    brujiTip:
      "Pasa la baqueta por el borde exterior con presión firme y constante para mantener la nota cantarina en el espacio.",
  },
  "Accesorios de Altar & Calderos": {
    title: "Calderos de Hierro & Paños de Altar",
    category: "herramientas-misticas",
    shortTag: "El Espacio Sagrado",
    image: "https://images.pexels.com/photos/31265605/pexels-photo-31265605.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Los cimientos físicos de tu práctica mágica: calderos de quema segura, morteros y tapetes geométricos.",
    description:
      "Los cimientos materiales de tu práctica mágica: calderos de hierro fundido para quemas seguras, morteros de piedra para triturar hierbas y paños con geometría sagrada que delimitan tu círculo de trabajo.",
    ritualUse:
      "Quema de peticiones, defumación con carbón vegetal y delimitación del microcosmos de tu altar.",
    brujiTip:
      "Coloca una capa de arena marina o tierra en el fondo del caldero antes de usar carbón para proteger la base del calor directo.",
  },

  // --- CUARZOS & MINERALES ---
  "Cantos Rodados (Piedras Pulidas)": {
    title: "Cantos Rodados & Gemas de Bolsillo",
    category: "cuarzos-minerales",
    shortTag: "Energía Portátil en Contacto con la Piel",
    image: "https://images.pexels.com/photos/38684711/pexels-photo-38684711.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Minerales pulidos al tacto para llevar contigo y beneficiarte de su resonancia a lo largo de tu jornada.",
    description:
      "Minerales seleccionados pulidos suavemente para tacto placentero. Al no tener aristas cortantes, conservan intacta la estructura cristalina natural permitiendo un intercambio energético óptimo al contacto prolongado con la piel.",
    ritualUse:
      "Llévalos en el bolsillo izquierdo para integrar su propiedad (amatista para serenidad, citrino para optimismo, turmalina para repeler miradas pesadas) o sostenlos durante meditaciones.",
    brujiTip:
      "Límpialos periódicamente dejándolos reposar sobre una placa de selenita o pasándoles humo de palo santo.",
  },
  "Minerales en Bruto & Drusas": {
    title: "Drusas Vivas & Minerales en Bruto",
    category: "cuarzos-minerales",
    shortTag: "Poder de la Tierra en Estado Puro",
    image: "https://images.pexels.com/photos/38684710/pexels-photo-38684710.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Formaciones intactas extraídas con respeto para armonizar estancias y recargar otras piezas minerales.",
    description:
      "Piezas sin tallar ni pulir que conservan la potencia telúrica original con la que crecieron en el interior de la Tierra durante millones de años. Sus múltiples puntas y racimos emiten una vibración multidireccional que armoniza salas completas.",
    ritualUse:
      "Puntos focales de transmutación en el hogar, recarga de joyas y cantos rodados, y estabilizadores de geopatías.",
    brujiTip:
      "Coloca una drusa de amatista en el salón o dormitorio para disolver cualquier tensión en el aire.",
  },
  "Placas y Cuencos de Selenita": {
    title: "Selenita Marroquí Pura & Cargadores",
    category: "cuarzos-minerales",
    shortTag: "Luz Blanca Inalterable & Autolimpiable",
    image: "https://images.pexels.com/photos/38684711/pexels-photo-38684711.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Gema de altísima vibración que nunca acumula densidad y limpia automáticamente cualquier mineral sobre ella.",
    description:
      "La selenita es uno de los minerales más sublimes: su frecuencia vibratoria es tan elevada que no acumula negatividad ni requiere ser limpiada. Actúa como un purificador instantáneo para cualquier otro cristal que se pose sobre ella.",
    ritualUse:
      "Deposita tus pulseras, anillos de plata y cantos rodados sobre la placa durante la noche para tenerlos purificados y listos cada mañana.",
    brujiTip:
      "¡Atención! La selenita es un yeso cristalino hidrosoluble: jamás debe entrar en contacto con agua líquida.",
  },
  "Joyería en Minerales (Plata 925)": {
    title: "Amuletos & Joyería Energética en Plata de Ley",
    category: "cuarzos-minerales",
    shortTag: "Protección Continua con Belleza",
    image: "https://images.pexels.com/photos/38684710/pexels-photo-38684710.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Gemas auténticas engarzadas en Plata 925 lunar para protección áurica y equilibrio permanente.",
    description:
      "Gemas naturales auténticas engarzadas en Plata de Ley 925. La plata es el metal alquímico regido por la Luna: amplifica las propiedades de las piedras y actúa como escudo psíquico reflectante.",
    ritualUse:
      "Protección áurica diaria y alineación del chakra corazón o garganta mediante colgantes y anillos conscientes.",
    brujiTip:
      "No compartas tu amuleto personal con otras personas para mantener sintonizada tu frecuencia vibratoria.",
  },

  // --- INCIENSOS & AROMATERAPIA ---
  "Inciensos Naturales & Varillas Masala": {
    title: "Varillas de Incienso Masala 100% Botánico",
    category: "inciensos-aromaterapia",
    shortTag: "Vapor Sagrado & Elevación",
    image: "https://images.pexels.com/photos/17840021/pexels-photo-17840021.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Enrolladas a mano con resinas puras, polvos de madera sagrada y flores. Sin tóxicos ni carbón artificial.",
    description:
      "Inciensos enrollados a mano con pastas tradicionales de resinas nobles, polvos de sándalo, flores prensadas y aceites esenciales. Libres de carbones tóxicos y aromas químicos sintéticos que irritan las mucosas.",
    ritualUse:
      "Sahumado previo a cualquier práctica espiritual, purificación de la casa y ambientación aromática de calma profunda.",
    brujiTip:
      "Enciende la punta con cerilla, deja que arda 5 segundos y apaga la llama de un suave soplido para que el humo fluya en danza mística.",
  },
  "Palo Santo & Atados de Salvia": {
    title: "Atados de Salvia Blanca & Palo Santo Ético",
    category: "inciensos-aromaterapia",
    shortTag: "Corte Profundo & Purificación Ancestral",
    image: "https://images.pexels.com/photos/8436503/pexels-photo-8436503.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Plantas maestras de medicina ancestral para despojar energías pesadas y consagrar nuevos comienzos.",
    description:
      "Plantas sagradas de medicina tradicional americana cosechadas de forma sostenible de ramas caídas naturalmente (en el caso del Palo Santo de Perú) y salvia apiana silvestre.",
    ritualUse:
      "Limpiezas profundas de mudanzas, cierres de ciclo o tras discusiones o visitas densas. Sahuma las 4 esquinas de cada habitación con las ventanas entreabiertas.",
    brujiTip:
      "El humo blanco y denso indica que el espacio se está limpiando; cuando se vuelva fino y grisáceo, el lugar ya está consagrado.",
  },
  "Conos & Conos de Reflujo": {
    title: "Conos de Humo Descendente & Fuentes Zen",
    category: "inciensos-aromaterapia",
    shortTag: "Cascada Visual de Paz",
    image: "https://images.pexels.com/photos/17840021/pexels-photo-17840021.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Cascadas hipnóticas de humo aromático que descienden sobre cerámica para serenar la mente.",
    description:
      "Conos perforados en su base que permiten que el humo, más denso que el aire, descienda en una hipnótica corriente acuática sobre fuentes de cerámica.",
    ritualUse:
      "Meditación zen contemplativa y relajación sensorial para calmar la agitación mental y el estrés acumulado.",
    brujiTip:
      "Evita las corrientes de aire para disfrutar de la cascada continua de humo sin turbulencias.",
  },

  // --- KITS RITUALES ---
  "Kit de Limpieza Energética": {
    title: "Kits de Limpieza & Purificación Áurica",
    category: "kits-rituales",
    shortTag: "Renovación Total del Hogar",
    image: "https://images.pexels.com/photos/38684710/pexels-photo-38684710.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    introSummary: "Protocolo elemental completo con ingredientes sagrados y guía paso a paso para resetear tu hogar.",
    description:
      "Un protocolo completo con todos los ingredientes necesarios: carbones, salvia, palo santo, velón de ruda y guía explicada para resetear por completo la vibración de tu espacio vital.",
    ritualUse:
      "Recomendado en cambios de estación, solsticios, lunas menguantes o tras etapas de enfermedad o estrés.",
    brujiTip:
      "Sigue los pasos numerados de la guía incluida para mantener el orden elemental (Tierra, Aire, Fuego y Agua).",
  },
};

export function getSubcategoryMeta(subcategoryName: string): SubcategoryMeta | null {
  if (!subcategoryName) return null;
  if (SUBCATEGORY_DESCRIPTIONS[subcategoryName]) {
    return SUBCATEGORY_DESCRIPTIONS[subcategoryName];
  }
  const lower = subcategoryName.toLowerCase();
  for (const [key, meta] of Object.entries(SUBCATEGORY_DESCRIPTIONS)) {
    if (
      key.toLowerCase() === lower ||
      lower.includes(key.toLowerCase()) ||
      key.toLowerCase().includes(lower) ||
      (lower.includes("runa") && key.toLowerCase().includes("runa")) ||
      (lower.includes("velon") && key.toLowerCase().includes("velon")) ||
      (lower.includes("miel") && key.toLowerCase().includes("miel")) ||
      (lower.includes("soja") && key.toLowerCase().includes("soja")) ||
      (lower.includes("cuarzo") && key.toLowerCase().includes("cuarzo")) ||
      (lower.includes("tarot") && key.toLowerCase().includes("tarot")) ||
      (lower.includes("pendulo") && key.toLowerCase().includes("péndulo"))
    ) {
      return meta;
    }
  }
  return null;
}
