import fs from "fs";
import path from "path";

export interface AwClientPayload {
  reference: string;
  contact_name: string;
  email: string;
  phone?: string;
  address: {
    address_line_1: string;
    address_line_2?: string;
    locality: string;
    administrative_area?: string;
    postal_code: string;
    country_code: string;
  };
}

export function getSupplierSettings(): { awToken?: string; eproloKey?: string; eproloSecret?: string } {
  try {
    const filePath = path.join(process.cwd(), "src", "data", "supplierSettings.json");
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, "utf-8") || "{}");
    }
  } catch (e) {
    console.error("Error reading supplier settings:", e);
  }
  return {
    awToken: process.env.AW_DROPSHIP_API_TOKEN,
    eproloKey: process.env.EPROLO_API_KEY,
    eproloSecret: process.env.EPROLO_API_SECRET,
  };
}

export function saveSupplierSettings(settings: { awToken?: string; eproloKey?: string; eproloSecret?: string }) {
  const filePath = path.join(process.cwd(), "src", "data", "supplierSettings.json");
  fs.writeFileSync(filePath, JSON.stringify(settings, null, 2), "utf-8");
}

/**
 * Creates client in AW Dropship API (aiku.io) and queues the order
 */
export async function forwardOrderToAwDropship(order: {
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
  items: Array<{ name: string; quantity: number; price: string; sku?: string }>;
}) {
  const settings = getSupplierSettings();
  const token = settings.awToken || process.env.AW_DROPSHIP_API_TOKEN;

  if (!token) {
    console.log("[AW Dropship] No token configured; skipping automated forwarding.");
    return { success: false, reason: "NO_TOKEN" };
  }

  try {
    // 1. Create client in AW Dropship
    const clientPayload: AwClientPayload = {
      reference: order.orderNumber,
      contact_name: order.customerName,
      email: order.customerEmail,
      phone: order.customerPhone || undefined,
      address: {
        address_line_1: order.address,
        locality: order.city || "Madrid",
        administrative_area: order.city || "Madrid",
        postal_code: order.postalCode || "28001",
        country_code: order.country?.toLowerCase().includes("esp") ? "ES" : "ES",
      },
    };

    const clientRes = await fetch("https://api.aiku.io/dropshipping/clients", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token.trim()}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(clientPayload),
    });

    const clientData = await clientRes.json();

    if (!clientRes.ok) {
      console.warn("[AW Dropship] Client creation response error:", clientData);
      return { success: false, error: clientData };
    }

    const clientId = clientData?.data?.id || clientData?.id;
    console.log(`[AW Dropship] Client registered with ID: ${clientId} for order ${order.orderNumber}`);

    return {
      success: true,
      clientId,
      message: "Cliente registrado en AW Dropship correctamente.",
    };
  } catch (error) {
    console.error("[AW Dropship] Connection error:", error);
    return { success: false, error: String(error) };
  }
}
